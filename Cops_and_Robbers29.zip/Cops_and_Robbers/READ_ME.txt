bim.copsAndRobbers.testing.RoadFrame
Build a grid of intersections and calculate a path between intersections and the time it takes to traverse path.
Most of the algorithms are in bim.copsAndRobbers.testing.BIMIntersection including the static function "findFastestPath"
that initiates a recursive function for calculating path and time.
Left click near an intersection for options related to that intersection.
Right click near an intersection for calculating a route between intersections.

bim.copsAndRobbers.testing.RoadsGenerateFrame
Auto generates a grid for you to test bim.copsAndRobbers.testing.RoadFrame

bim.copsAndRobbers.testing.ShooterFrame
Auto generates shooters and targets on a canvas. Click the canvas to add a player to the canvas then click again
to move the player to the click location. Use up and down arrows to fire bullets from player and use left and
right arrows to change the direction of gun fire. Targets are green, shooters are red, and player is blue.