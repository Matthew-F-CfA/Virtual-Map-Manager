package bim.copsAndRobbers.testing;

class BIMPointDouble
implements Comparable, Cloneable {
  Double dblX=new Double(0.0d);
  Double dblY=new Double(0.0d);

  BIMPointDouble(double dblX0, double dblY0) {
    this.dblX=new Double(dblX0);
    this.dblY=new Double(dblY0);
  }

  public double getX() {
    return dblX.doubleValue();
  }

  public double getY() {
    return dblY.doubleValue();
  }

  public int compareTo(Object obj) {
    BIMPointDouble objPnt=(BIMPointDouble)obj;

    if(getY()<objPnt.getY()) {
      return -1;
    }
    else if(getY()>objPnt.getY()) {
      return 1;
    }
    else {
      if(getX()<objPnt.getX()) {
        return -1;
      }
      else if(getX()>objPnt.getX()) {
        return 1;
      }
    }

    return 0;
  }

  public Object clone() {
    BIMPointDouble objClone=new BIMPointDouble(dblX.doubleValue(), dblY.doubleValue());

    return objClone;
  }
}