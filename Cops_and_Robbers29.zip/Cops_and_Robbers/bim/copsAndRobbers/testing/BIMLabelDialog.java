package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;

class BIMLabelDialog extends Dialog
implements ActionListener {
  Button btnOkay=new Button("Okay");

  BIMLabelDialog(Frame parent, String strTitle, String strText) {
    super(parent, strTitle, true);

    setLayout(new BorderLayout());

    add("Center", new Label(strText));

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnOkay);
    btnOkay.addActionListener(this);

    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnOkay) {
      dispose();
    }
  }
}