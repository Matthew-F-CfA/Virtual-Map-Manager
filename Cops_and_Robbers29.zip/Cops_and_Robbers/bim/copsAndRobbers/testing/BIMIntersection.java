package bim.copsAndRobbers.testing;

import java.util.Vector;
import java.util.TreeMap;
import java.util.Map;
import java.util.Iterator;

class BIMIntersection
implements Cloneable {
  String strName="";
  BIMPoint pnt=null;
  Vector vecDestinations=new Vector();
  TreeMap mapMajorIntersections=new TreeMap();
  Double dblLatitude=new Double(-1.0d);
  Double dblLongitude=new Double(-1.0d);

  static TreeMap hshTraffic=new TreeMap(); //keys are BIMRoad and values are adjusted speed limit

  BIMIntersection(double dblLatitude0, double dblLongitude0) {
    this.dblLatitude=new Double(dblLatitude0);
    this.dblLongitude=new Double(dblLongitude0);
  }

  BIMIntersection(BIMPoint pnt, double dblLatitude0, double dblLongitude0) {
    this.pnt=pnt;
    this.dblLatitude=new Double(dblLatitude0);
    this.dblLongitude=new Double(dblLongitude0);
  }

  BIMIntersection(String strName, BIMPoint pnt) {
    this.strName=strName;
    this.pnt=pnt;
  }

  BIMIntersection(String strName, BIMPoint pnt, double dblLatitude0, double dblLongitude0) {
    this.strName=strName;
    this.pnt=pnt;
    this.dblLatitude=new Double(dblLatitude0);
    this.dblLongitude=new Double(dblLongitude0);
  }

  public double getLatitude() {
    return dblLatitude.doubleValue();
  }

  public void setLatitude(double dblLatitude0) {
    this.dblLatitude=new Double(dblLatitude0);
  }

  public double getLongitude() {
    return dblLongitude.doubleValue();
  }

  public void setLongitude(double dblLongitude0) {
    this.dblLongitude=new Double(dblLongitude0);
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public BIMPoint getPoint() {
    return pnt;
  }

  public void setPoint(int intX, int intY) {
    this.pnt=new BIMPoint(intX, intY);
  }

  public Vector getDestinations() {
    return vecDestinations;
  }

  public void setDestinations(Vector vecDestinations) {
    this.vecDestinations=vecDestinations;
  }

  public void addDestination(BIMRoad bimRoad) {
    BIMIntersection intersection=bimRoad.getTo();

    int intIndex=0;
    for(;intIndex<vecDestinations.size();intIndex++) {
      BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(intIndex);

      BIMIntersection intersectionNext=roadNext.getTo();

      if(intersection.getPoint().getX()==intersectionNext.getPoint().getX() & intersection.getPoint().getY()==intersectionNext.getPoint().getY())
        return;
    }

    vecDestinations.addElement(bimRoad);
  }

  public TreeMap getMajorIntersections() {
    return mapMajorIntersections;
  }

  public void setMajorIntersections(TreeMap mapMajorIntersections) {
    this.mapMajorIntersections=mapMajorIntersections;
  }

  public void addMajorIntersection(BIMIntersection bimIntersection, Vector vecRoads, double dblPathTime) {
    mapMajorIntersections.put(bimIntersection.getPoint(), new BIMIntersectionPath(bimIntersection, vecRoads, dblPathTime));
  }

  public static void recalculateMajorIntersections(TreeMap hshIntersections, TreeMap hshIntersectionsMilesView, TreeMap hshMajorIntersections) throws Exception {
    TreeMap hshMajorIntersectionsCopy=new TreeMap();

    Iterator iter=hshMajorIntersections.entrySet().iterator();

    Vector vecMajorIntersections=new Vector();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pnt=(BIMPoint)mEntry.getKey();
      BIMIntersection intersection=(BIMIntersection)mEntry.getValue();

      hshMajorIntersectionsCopy.put(pnt.clone(), intersection.clone());

      vecMajorIntersections.addElement(mEntry.getValue());
    }

    hshMajorIntersections.clear();

    try {
      for(int i=0;i<vecMajorIntersections.size();i++) {
        BIMIntersection bimIntersectionNext=(BIMIntersection)vecMajorIntersections.elementAt(i);

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, bimIntersectionNext);
      }
    }
    catch(Exception ex) {
      hshMajorIntersections.clear();

      iter=hshMajorIntersectionsCopy.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        hshMajorIntersections.put(mEntry.getKey(), intersectionNext);

        hshIntersections.put(mEntry.getKey(), intersectionNext);

        hshIntersectionsMilesView.put(new BIMPointDouble(intersectionNext.getLongitude(), intersectionNext.getLatitude()), intersectionNext);
      }

      throw ex;
    }
  }

  public static void connectMajorIntersection(TreeMap hshIntersections, TreeMap hshIntersectionsMilesView, TreeMap hshMajorIntersections, BIMIntersection bimIntersection) throws Exception {
    TreeMap hshMajorIntersectionsCopy=new TreeMap();

    Iterator iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pnt=(BIMPoint)mEntry.getKey();
      BIMIntersection intersection=(BIMIntersection)mEntry.getValue();

      hshMajorIntersectionsCopy.put(pnt.clone(), intersection.clone());
    }


    iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMIntersection bimIntersectionNext=(BIMIntersection)mEntry.getValue();

      Vector vecRoads=new Vector();

      try {
        vecRoads=BIMIntersection.findFastestPath(bimIntersection, bimIntersectionNext, 3, 12);
      }
      catch(Exception ex) {
        if(ex.toString().equals("Unable to find path between intersections.")) {
          Vector vecRoadsMajorFrom=new Vector();

          BIMIntersection majorFrom=BIMIntersection.findClosestMajorIntersection(bimIntersection, hshMajorIntersections, vecRoadsMajorFrom);

          if(majorFrom==null) {
            continue;

/*
            hshMajorIntersections.clear();

            iter=hshMajorIntersectionsCopy.entrySet().iterator();

            while(iter.hasNext()) {
              Map.Entry mEntryZ=(Map.Entry)iter.next();

              hshMajorIntersections.put(mEntryZ.getKey(), mEntryZ.getValue());

              hshIntersections.put(mEntryZ.getKey(), mEntryZ.getValue());
            }

            throw new Exception("Unable to find path between major intersections.");
*/
          }

          BIMIntersection majorTo=bimIntersectionNext;

          BIMIntersectionPath bimIntersectionPath=(BIMIntersectionPath)majorFrom.mapMajorIntersections.get(majorTo.getPoint());

          if(bimIntersectionPath==null)
            continue;

          Vector vecRoadsMajorFrom2=bimIntersectionPath.getRoads();

          vecRoads=vecRoadsMajorFrom;

          for(int i=0;i<vecRoadsMajorFrom2.size();i++)
            vecRoads.addElement(vecRoadsMajorFrom2.elementAt(i));
        }
      }

      double dblPathTime=0.0d;

      Vector vecRoadsReverse=new Vector();

      for(int i=vecRoads.size()-1;i>=0;i--) {
        BIMRoad bimRoadNext=(BIMRoad)vecRoads.elementAt(i);

        BIMRoad bimRoadNext2=new BIMRoad(bimRoadNext.getTo(), bimRoadNext.getFrom(), bimRoadNext.getSpeedLimit());

        vecRoadsReverse.addElement(bimRoadNext2);

        dblPathTime=dblPathTime+bimRoadNext.getLength()/bimRoadNext.getSpeedLimit();
      }

      bimIntersection.addMajorIntersection(bimIntersectionNext, vecRoads, dblPathTime);

      bimIntersectionNext.addMajorIntersection(bimIntersection, vecRoadsReverse, dblPathTime);
    }

    hshMajorIntersections.put(bimIntersection.getPoint(), bimIntersection);
  }

  public static void disconnectMajorIntersection(TreeMap hshIntersections, TreeMap hshIntersectionsMilesView, TreeMap hshMajorIntersections, BIMIntersection bimIntersection) throws Exception {
    TreeMap hshMajorIntersectionsCopy=new TreeMap();

    Iterator iter=hshMajorIntersections.entrySet().iterator();

    Vector vecMajorIntersections=new Vector();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pnt=(BIMPoint)mEntry.getKey();
      BIMIntersection intersection=(BIMIntersection)mEntry.getValue();

      hshMajorIntersectionsCopy.put(pnt.clone(), intersection.clone());

      if(pnt.getX()!=bimIntersection.getPoint().getX() | pnt.getY()!=bimIntersection.getPoint().getY())
        vecMajorIntersections.addElement(mEntry.getValue());
    }

//    hshMajorIntersections.remove(bimIntersection.getPoint());

    hshMajorIntersections.clear();

    try {
      for(int i=0;i<vecMajorIntersections.size();i++) {
        BIMIntersection bimIntersectionNext=(BIMIntersection)vecMajorIntersections.elementAt(i);

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, bimIntersectionNext);
      }
    }
    catch(Exception ex) {
      hshMajorIntersections.clear();

      iter=hshMajorIntersectionsCopy.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        hshMajorIntersections.put(mEntry.getKey(), intersectionNext);

        hshIntersections.put(mEntry.getKey(), intersectionNext);

        hshIntersectionsMilesView.put(new BIMPointDouble(intersectionNext.getLongitude(), intersectionNext.getLatitude()), intersectionNext);
      }

      throw ex;
    }
  }

  public static void deleteIntersection(TreeMap hshIntersections, TreeMap hshIntersectionsMilesView, TreeMap hshMajorIntersections, BIMIntersection bimIntersection) throws Exception {
    TreeMap hshIntersectionsCopy=new TreeMap();

    Iterator iter=hshIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pnt=(BIMPoint)mEntry.getKey();
      BIMIntersection intersection=(BIMIntersection)mEntry.getValue();

      hshIntersectionsCopy.put(pnt.clone(), intersection.clone());
    }


    TreeMap hshMajorIntersectionsCopy=new TreeMap();

    iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pnt=(BIMPoint)mEntry.getKey();
      BIMIntersection intersection=(BIMIntersection)mEntry.getValue();

      hshMajorIntersectionsCopy.put(pnt.clone(), intersection.clone());
    }


    Vector vecDestinationsCopy=new Vector();

    BIMPoint bimPoint=bimIntersection.getPoint();

    Vector vecDestinations=bimIntersection.getDestinations();

    for(int i=0;i<vecDestinations.size();i++) {
      BIMRoad bimRoadNext=(BIMRoad)vecDestinations.elementAt(i);

      Vector vecDestinationsCopy2=new Vector();

      BIMIntersection bimIntersectionNext=bimRoadNext.getTo();

      Vector vecDestinations2=bimIntersectionNext.getDestinations();

      for(int ia=0;ia<vecDestinations2.size();ia++) {
        BIMRoad bimRoadNext2=(BIMRoad)vecDestinations2.elementAt(ia);

        vecDestinationsCopy2.addElement(bimRoadNext2.clone());

        BIMIntersection bimIntersectionNext2=bimRoadNext2.getTo();

        BIMPoint bimPoint2=bimIntersectionNext2.getPoint();

        if(bimPoint.getX()==bimPoint2.getX() & bimPoint.getY()==bimPoint2.getY()) {
          vecDestinations2.removeElementAt(ia);
        }
      }

      vecDestinationsCopy.addElement(vecDestinationsCopy2);
    }

    hshIntersections.remove(bimPoint);
    hshIntersectionsMilesView.remove(new BIMPointDouble(bimIntersection.getLongitude(), bimIntersection.getLatitude()));
    hshMajorIntersections.remove(bimPoint);


    Vector vecMajorIntersections=new Vector();

    iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      vecMajorIntersections.addElement(mEntry.getValue());
    }

    hshMajorIntersections.clear();

    try {
      for(int i=0;i<vecMajorIntersections.size();i++) {
        BIMIntersection bimIntersectionNext=(BIMIntersection)vecMajorIntersections.elementAt(i);

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, bimIntersectionNext);
      }
    }
    catch(Exception ex) {
      for(int i=0;i<vecDestinations.size();i++) {
        Vector vecDestinationsCopy2=(Vector)vecDestinationsCopy.elementAt(i);

        BIMRoad bimRoadNext=(BIMRoad)vecDestinations.elementAt(i);

        BIMIntersection bimIntersectionNext=bimRoadNext.getTo();

        Vector vecDestinations2=bimIntersectionNext.getDestinations();

        vecDestinations2.removeAllElements();

        for(int ia=0;ia<vecDestinationsCopy2.size();ia++) {
          vecDestinations2.addElement(vecDestinationsCopy2.elementAt(ia));
        }
      }


      hshIntersections.clear();

      hshIntersectionsMilesView.clear();

      hshMajorIntersections.clear();

      iter=hshIntersectionsCopy.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        hshIntersections.put(mEntry.getKey(), intersectionNext);

        hshIntersectionsMilesView.put(new BIMPointDouble(intersectionNext.getLongitude(), intersectionNext.getLatitude()), intersectionNext);

        if(hshMajorIntersectionsCopy.containsKey(mEntry.getKey())) {
          hshMajorIntersections.put(mEntry.getKey(), intersectionNext);
        }
      }


/*
      hshMajorIntersections.clear();

      iter=hshMajorIntersectionsCopy.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        hshMajorIntersections.put(mEntry.getKey(), mEntry.getValue());
      }
*/

      throw ex;
    }
  }

  public static String[] findFastestPathStrings(TreeMap hshMajorIntersections, BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, BIMDouble dblReturnFastestTime) throws Exception {
    BIMRoad bimRoads[]=new BIMRoad[0];

    BIMRoad bimRoads0[]=new BIMRoad[0];

    BIMDouble dblReturnFastestTime0=new BIMDouble(Double.MAX_VALUE-5.0d);

    Exception exMajor=null;

    try {
      bimRoads0=BIMIntersection.findFastestPathWithMajorIntersections(hshMajorIntersections, bimIntersectionFrom, bimIntersectionTo, dblReturnFastestTime0);
    }
    catch(Exception ex) {
      exMajor=ex;
    }


    BIMRoad bimRoads1[]=new BIMRoad[0];

    BIMDouble dblReturnFastestTime1=new BIMDouble(Double.MAX_VALUE-5.0d);

    Exception exDirect=null;

    try {
      bimRoads1=findFastestPathDirect(bimIntersectionFrom, bimIntersectionTo, dblReturnFastestTime1);
    }
    catch(Exception ex) {
      exDirect=ex;
    }

    if(exMajor!=null & exDirect!=null) {
//exDirect.printStackTrace();

      throw new Exception(exMajor.toString()+" and "+exDirect.toString());
    }

    if(dblReturnFastestTime0.getDouble()==(Double.MAX_VALUE-5.0d) & dblReturnFastestTime1.getDouble()==(Double.MAX_VALUE-5.0d)) {
      throw new Exception("Unable to find directions from \""+bimIntersectionFrom.getName()+"\" to \""+bimIntersectionTo.getName()+"\"");
    }

    if(dblReturnFastestTime0.getDouble()<dblReturnFastestTime1.getDouble()) {
      bimRoads=bimRoads0;
      dblReturnFastestTime.setDouble(dblReturnFastestTime0.getDouble());
    }
    else {
      bimRoads=bimRoads1;
      dblReturnFastestTime.setDouble(dblReturnFastestTime1.getDouble());
    }

    String strIntersections[]=new String[bimRoads.length+1];

    strIntersections[0]=bimRoads[0].getFrom().getName();

    for(int i=0;i<bimRoads.length;i++) {
      strIntersections[i+1]=bimRoads[i].getTo().getName();
    }

    return strIntersections;
  }

  public static BIMRoad[] findFastestPathWithMajorIntersections(TreeMap hshMajorIntersections, BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, BIMDouble dblReturnFastestTime) throws Exception {
    double dblLatitudeFrom=bimIntersectionFrom.getLatitude();
    double dblLongitudeFrom=bimIntersectionFrom.getLongitude();

    double dblLatitudeTo=bimIntersectionTo.getLatitude();
    double dblLongitudeTo=bimIntersectionTo.getLongitude();

    double dblDistanceBetweenFromAndTo=Math.sqrt(Math.pow((dblLongitudeFrom-dblLongitudeTo), 2.0d)+Math.pow((dblLatitudeFrom-dblLatitudeTo), 2.0d));

    Vector vecFastestRoadsFromToNext=new Vector();

    double dblFastestTimeFromToNext=Double.MAX_VALUE-5.0d;

//    if(hshMajorIntersections.containsKey(bimIntersectionFrom.getPoint())) {
//      dblFastestTimeFromToNext=0.0d;
//    }
//    else {
      Iterator iter=hshMajorIntersections.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        BIMIntersectionPath intersectionPathFTN=(BIMIntersectionPath)bimIntersectionFrom.mapMajorIntersections.get(intersectionNext.getPoint());

        if(intersectionPathFTN!=null) {
          if(intersectionPathFTN.getPathTime()<dblFastestTimeFromToNext) {
            Vector vecMajorRoads=intersectionPathFTN.getRoads();

            vecFastestRoadsFromToNext=vecMajorRoads;

            dblFastestTimeFromToNext=intersectionPathFTN.getPathTime();
          }

          continue;
        }

        double dblLatitudeNext=intersectionNext.getLatitude();
        double dblLongitudeNext=intersectionNext.getLongitude();

        double dblDistanceBetweenNextAndTo=Math.sqrt(Math.pow((dblLongitudeNext-dblLongitudeTo), 2.0d)+Math.pow((dblLatitudeNext-dblLatitudeTo), 2.0d));

        if(dblDistanceBetweenNextAndTo>dblDistanceBetweenFromAndTo) {
          continue;
        }

        BIMDouble dblTime=new BIMDouble(-1.0d);

        try {
          Vector vecRoads=BIMIntersection.findFastestPath(bimIntersectionFrom, intersectionNext, dblTime, 3, 10);

          if(dblTime.getDouble()<dblFastestTimeFromToNext) {
            dblFastestTimeFromToNext=dblTime.getDouble();

            vecFastestRoadsFromToNext=vecRoads;
          }
        }
        catch(Exception ex) {
//          System.out.println(ex.toString());
        }
      }

      if(vecFastestRoadsFromToNext.size()==0) {
        throw new Exception("Unable to find path from intersection from to major intersection.");
      }
//    }


    Vector vecFastestRoadsNextToTo=new Vector();

    double dblFastestTimeNextToTo=Double.MAX_VALUE-5.0d;

//    if(hshMajorIntersections.containsKey(bimIntersectionTo.getPoint())) {
//      dblFastestTimeNextToTo=0.0d;
//    }
//    else {
      iter=hshMajorIntersections.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        BIMIntersectionPath intersectionPathNTT=(BIMIntersectionPath)intersectionNext.mapMajorIntersections.get(bimIntersectionTo.getPoint());

        if(intersectionPathNTT!=null) {
          if(intersectionPathNTT.getPathTime()<dblFastestTimeNextToTo) {
            Vector vecMajorRoads=intersectionPathNTT.getRoads();

            vecFastestRoadsNextToTo=vecMajorRoads;

            dblFastestTimeNextToTo=intersectionPathNTT.getPathTime();
          }

          continue;
        }

        double dblLatitudeNext=intersectionNext.getLatitude();
        double dblLongitudeNext=intersectionNext.getLongitude();

        double dblDistanceBetweenNextAndFrom=Math.sqrt(Math.pow((dblLongitudeNext-dblLongitudeFrom), 2.0d)+Math.pow((dblLatitudeNext-dblLatitudeFrom), 2.0d));

        if(dblDistanceBetweenNextAndFrom>dblDistanceBetweenFromAndTo) {
          continue;
        }

        BIMDouble dblTime=new BIMDouble(-1.0d);

        try {
          Vector vecRoads=BIMIntersection.findFastestPath(intersectionNext, bimIntersectionTo, dblTime, 3, 10);

          if(dblTime.getDouble()<dblFastestTimeNextToTo) {
            dblFastestTimeNextToTo=dblTime.getDouble();

            vecFastestRoadsNextToTo=vecRoads;
          }
        }
        catch(Exception ex) {
//          System.out.println(ex.toString());
        }
      }

      if(vecFastestRoadsNextToTo.size()==0) {
        throw new Exception("Unable to find path from intersection from to major intersection.");
      }
//    }

    Vector vecRoadsNextToNext=new Vector();
    double dblTime=0.0d;

    BIMIntersection bimIntersectionNext=((BIMRoad)vecFastestRoadsFromToNext.elementAt(vecFastestRoadsFromToNext.size()-1)).getTo();

    BIMIntersection bimIntersectionNext2=((BIMRoad)vecFastestRoadsNextToTo.elementAt(0)).getFrom();

//System.out.println("before");
    if(bimIntersectionNext.getPoint().getX()!=bimIntersectionNext2.getPoint().getX() | bimIntersectionNext.getPoint().getY()!=bimIntersectionNext2.getPoint().getY()) {
//System.out.println("if0");
      BIMIntersectionPath bimIntersectionPath=(BIMIntersectionPath)bimIntersectionNext.mapMajorIntersections.get(bimIntersectionNext2.getPoint());

      if(bimIntersectionPath==null) {
//System.out.println("if1");
        try {
//System.out.println("try0");
          bimIntersectionPath=BIMIntersection.findMajorIntersectionsPaths(hshMajorIntersections, bimIntersectionNext, bimIntersectionNext2);
//System.out.println("try1");
        }
        catch(Exception ex) {
          throw new Exception("Unable to find path between major intersections.");
        }
      }

      vecRoadsNextToNext=bimIntersectionPath.getRoads();

      dblTime=bimIntersectionPath.getPathTime();
    }

    dblReturnFastestTime.setDouble(dblFastestTimeFromToNext+dblTime+dblFastestTimeNextToTo);
//System.out.println("return fastest time: "+dblReturnFastestTime.getDouble());

    Vector vecReturn=new Vector();

    for(int i=0;i<vecFastestRoadsFromToNext.size();i++) {
      vecReturn.addElement(vecFastestRoadsFromToNext.elementAt(i));
    }

    for(int i=0;i<vecRoadsNextToNext.size();i++) {
      vecReturn.addElement(vecRoadsNextToNext.elementAt(i));
    }

    for(int i=0;i<vecFastestRoadsNextToTo.size();i++) {
      vecReturn.addElement(vecFastestRoadsNextToTo.elementAt(i));
    }


    BIMRoad roads[]=new BIMRoad[vecReturn.size()];

    for(int i=0;i<roads.length;i++)
      roads[i]=(BIMRoad)vecReturn.elementAt(i);

    return roads;
  }

  public static BIMRoad[] findFastestPathDirect(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, BIMDouble dblReturnFastestTime) throws Exception {
//System.out.println("direct before");
    Vector vecRoads=findFastestPath(bimIntersectionFrom, bimIntersectionTo, dblReturnFastestTime, 3, 10);

//for(int i=0;i<vecRoads.size();i++) {
//BIMRoad roadNext=(BIMRoad)vecRoads.elementAt(i);
//BIMIntersection toNext=roadNext.getTo();
//System.out.println(toNext.getPoint().getX()+", "+toNext.getPoint().getY());
//}
//System.out.println("direct after");

    BIMRoad roads[]=new BIMRoad[vecRoads.size()];

    for(int i=0;i<roads.length;i++)
      roads[i]=(BIMRoad)vecRoads.elementAt(i);

    return roads;
  }

  public static Vector findFastestPath(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, int intAttempts, int intMaxBranches) throws Exception {
    return BIMIntersection.findFastestPath(bimIntersectionFrom, bimIntersectionTo, new BIMDouble(0.0d), intAttempts, intMaxBranches);
  }

  public static Vector findFastestPath(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, BIMDouble dblReturnFastestTime, int intAttempts, int intMaxBranches) throws Exception {
    return BIMIntersection.findFastestPath(bimIntersectionFrom, bimIntersectionTo, dblReturnFastestTime, intAttempts, intMaxBranches, 1.0d);
  }

  public static Vector findFastestPath(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, BIMDouble dblReturnFastestTime, int intAttempts, int intMaxBranches, double dblPercentageOfSpeedLimit) throws Exception {
    Vector vecRoads=new Vector();

    if(bimIntersectionFrom.getPoint().getX()==bimIntersectionTo.getPoint().getX() & bimIntersectionFrom.getPoint().getY()==bimIntersectionTo.getPoint().getY()) {
      dblReturnFastestTime.setDouble(0.0d);

      return vecRoads;
    }

    BIMIntersection bimIntersectionFromNew=bimIntersectionFrom;

//    int intAttempts=5;

    BIMIntersection intersectionClosest=new BIMIntersection("null", new BIMPoint(-1, -1));
    Vector vecIntersectionClosestRoads=new Vector();

    BIMDouble dblFastestTime=new BIMDouble(Double.MAX_VALUE-5.0d);

    double dblTotalClosestTime=0.0d;
    BIMDouble dblCurrentClosestTime=new BIMDouble(Double.MAX_VALUE);

    Vector vecRoadsClosest=new Vector();

    while(intAttempts>-1) {
//System.out.println("attempts: "+intAttempts);
      BIMIntersection.cycleThroughDestinations(bimIntersectionFromNew, bimIntersectionTo, intMaxBranches, 0, dblFastestTime, 0.0d, dblCurrentClosestTime, intersectionClosest, vecIntersectionClosestRoads, new Vector(), vecRoads, dblPercentageOfSpeedLimit);

      if(dblFastestTime.getDouble()<(Double.MAX_VALUE-5.0d))
        break;

//      if(vecRoads.size()>0)
//        break;

      dblTotalClosestTime=dblTotalClosestTime+dblCurrentClosestTime.getDouble();

      BIMRoad roadClosest=(BIMRoad)vecIntersectionClosestRoads.elementAt(vecIntersectionClosestRoads.size()-1);

      bimIntersectionFromNew=roadClosest.getTo();

      for(int i=0;i<vecIntersectionClosestRoads.size();i++)
        vecRoadsClosest.addElement(vecIntersectionClosestRoads.elementAt(i));

      vecIntersectionClosestRoads.removeAllElements();

      intersectionClosest.setName("null");
      intersectionClosest.setPoint(-1, -1);

      dblCurrentClosestTime.setDouble(Double.MAX_VALUE);

      --intAttempts;
    }

    if(intAttempts==-1)
      throw new Exception("Unable to find path between intersections.");

    for(int i=vecRoadsClosest.size()-1;i>=0;i--)
      vecRoads.insertElementAt(vecRoadsClosest.elementAt(i), 0);    

    dblReturnFastestTime.setDouble(dblTotalClosestTime+dblFastestTime.getDouble());

//System.out.println("return fastest time: "+dblReturnFastestTime.getDouble());

    return vecRoads;
  }

//BIMIntersection bimIntersectionFrom
//BIMIntersection bimIntersectionTo
//int intMaxBranches
//int intCurrentBranch
//BIMDouble dblFastestTime
//double dblCurrentTime
//BIMDouble dblCurrentClosestTime
//BIMIntersection bimIntersectionClosest
//Vector vecIntersectionClosestRoads
//Vector vecRoads
//Vector vecRoadsFastest
//double dblPercentageOfSpeedLimit
//returns fastest time
  public static void cycleThroughDestinations(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, int intMaxBranches, int intCurrentBranch, BIMDouble dblFastestTime, double dblCurrentTime, BIMDouble dblCurrentClosestTime, BIMIntersection bimIntersectionClosest, Vector vecIntersectionClosestRoads, Vector vecRoads, Vector vecRoadsFastest, double dblPercentageOfSpeedLimit) {
//    double dblXTo=new Integer(bimIntersectionTo.getPoint().getX()).doubleValue();
//    double dblYTo=new Integer(bimIntersectionTo.getPoint().getY()).doubleValue();

    Vector vecDestinations=bimIntersectionFrom.getDestinations();

    for(int i=0;i<vecDestinations.size();i++) {
      BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

      double dblLengthNext=roadNext.getLength();

      double dblSpeedLimitNext=0.0d;

      double dblSpeedLimitRoad=roadNext.getSpeedLimit();

      dblSpeedLimitRoad=dblSpeedLimitRoad*dblPercentageOfSpeedLimit;

      Double dblSpeedLimitTraffic=(Double)BIMIntersection.hshTraffic.get(roadNext);

      if(dblSpeedLimitTraffic==null) {
        dblSpeedLimitNext=dblSpeedLimitRoad;

//if(dblSpeedLimitNext==0.0d) {
//System.out.println("speed0");
//}
      }
      else {
        double dblSpeedLimitTraffic0=dblSpeedLimitTraffic.doubleValue();

        if(dblSpeedLimitTraffic0<dblSpeedLimitRoad) {
          dblSpeedLimitNext=dblSpeedLimitTraffic0;

//if(dblSpeedLimitNext==0.0d) {
//System.out.println("speed1");
//}
        }
        else {
          dblSpeedLimitNext=dblSpeedLimitRoad;

//if(dblSpeedLimitNext==0.0d) {
//System.out.println("speed2");
//}
        }
      }

//System.out.println("here0");

      double dblTimeNext=dblLengthNext/dblSpeedLimitNext;

//System.out.println("here1");

      double dblTimeTotalNext=dblCurrentTime+dblTimeNext;

      if(dblTimeTotalNext>=dblFastestTime.getDouble())
        continue;

      BIMIntersection intersectionNext=roadNext.getTo();

      vecRoads.addElement(roadNext);

      double dblDistanceNext=BIMIntersection.lengthFromHaversine(intersectionNext, bimIntersectionTo);

/*
      double dblXNext=new Integer(intersectionNext.getPoint().getX()).doubleValue();
      double dblYNext=new Integer(intersectionNext.getPoint().getY()).doubleValue();

      double dblDistanceNext=Math.sqrt(Math.pow((dblXTo-dblXNext), 2.0d)+Math.pow((dblYTo-dblYNext), 2.0d));
*/

      double dblDistanceClosest=Double.MAX_VALUE-5.0d;

      if(bimIntersectionClosest.getPoint().getX()!=-1 & bimIntersectionClosest.getPoint().getY()!=-1) {
        dblDistanceClosest=BIMIntersection.lengthFromHaversine(bimIntersectionClosest, bimIntersectionTo);
      }

/*
      if(bimIntersectionClosest.getPoint().getX()!=-1 & bimIntersectionClosest.getPoint().getY()!=-1) {
        double dblXClosest=new Integer(bimIntersectionClosest.getPoint().getX()).doubleValue();
        double dblYClosest=new Integer(bimIntersectionClosest.getPoint().getY()).doubleValue();

        dblDistanceClosest=Math.sqrt(Math.pow((dblXTo-dblXClosest), 2.0d)+Math.pow((dblYTo-dblYClosest), 2.0d));
      }
*/

      if(dblDistanceNext<dblDistanceClosest) {
        bimIntersectionClosest.setName(intersectionNext.getName());
        bimIntersectionClosest.setPoint(intersectionNext.getPoint().getX(), intersectionNext.getPoint().getY());
        bimIntersectionClosest.setLatitude(intersectionNext.getLatitude());
        bimIntersectionClosest.setLongitude(intersectionNext.getLongitude());
        bimIntersectionClosest.setDestinations(intersectionNext.getDestinations());
        bimIntersectionClosest.setMajorIntersections(intersectionNext.getMajorIntersections());

        vecIntersectionClosestRoads.removeAllElements();

        for(int ia=0;ia<vecRoads.size();ia++) {
          vecIntersectionClosestRoads.addElement(vecRoads.elementAt(ia));
        }

        dblCurrentClosestTime.setDouble(dblTimeTotalNext);
      }
      else if(dblDistanceNext<(dblDistanceClosest+1.0d)) {
        if(dblTimeTotalNext<dblCurrentClosestTime.getDouble()) {
          bimIntersectionClosest.setName(intersectionNext.getName());
          bimIntersectionClosest.setPoint(intersectionNext.getPoint().getX(), intersectionNext.getPoint().getY());
          bimIntersectionClosest.setLatitude(intersectionNext.getLatitude());
          bimIntersectionClosest.setLongitude(intersectionNext.getLongitude());
          bimIntersectionClosest.setDestinations(intersectionNext.getDestinations());
          bimIntersectionClosest.setMajorIntersections(intersectionNext.getMajorIntersections());

          vecIntersectionClosestRoads.removeAllElements();

          for(int ia=0;ia<vecRoads.size();ia++) {
            vecIntersectionClosestRoads.addElement(vecRoads.elementAt(ia));
          }

          dblCurrentClosestTime.setDouble(dblTimeTotalNext);
        }
      }

/*
      if(dblDistanceNext<(dblDistanceClosest-2.0d)) {
        bimIntersectionClosest.setName(intersectionNext.getName());
        bimIntersectionClosest.setPoint(intersectionNext.getPoint().getX(), intersectionNext.getPoint().getY());
        bimIntersectionClosest.setLatitude(intersectionNext.getLatitude());
        bimIntersectionClosest.setLongitude(intersectionNext.getLongitude());
        bimIntersectionClosest.setDestinations(intersectionNext.getDestinations());
        bimIntersectionClosest.setMajorIntersections(intersectionNext.getMajorIntersections());

        vecIntersectionClosestRoads.removeAllElements();

        for(int ia=0;ia<vecRoads.size();ia++) {
          vecIntersectionClosestRoads.addElement(vecRoads.elementAt(ia));
        }

        dblCurrentClosestTime.setDouble(dblTimeTotalNext);
      }
      else if(dblDistanceNext<=dblDistanceClosest) {
        if(dblTimeTotalNext<dblCurrentClosestTime.getDouble()) {
          bimIntersectionClosest.setName(intersectionNext.getName());
          bimIntersectionClosest.setPoint(intersectionNext.getPoint().getX(), intersectionNext.getPoint().getY());
          bimIntersectionClosest.setLatitude(intersectionNext.getLatitude());
          bimIntersectionClosest.setLongitude(intersectionNext.getLongitude());
          bimIntersectionClosest.setDestinations(intersectionNext.getDestinations());
          bimIntersectionClosest.setMajorIntersections(intersectionNext.getMajorIntersections());

          vecIntersectionClosestRoads.removeAllElements();

          for(int ia=0;ia<vecRoads.size();ia++) {
            vecIntersectionClosestRoads.addElement(vecRoads.elementAt(ia));
          }

          dblCurrentClosestTime.setDouble(dblTimeTotalNext);
        }
      }
*/

      if(intersectionNext.getPoint().getX()==bimIntersectionTo.getPoint().getX() & intersectionNext.getPoint().getY()==bimIntersectionTo.getPoint().getY()) {
        if(dblTimeTotalNext<dblFastestTime.getDouble()) {
          dblFastestTime.setDouble(dblTimeTotalNext);

          vecRoadsFastest.removeAllElements();

          for(int ia=0;ia<vecRoads.size();ia++) {
            vecRoadsFastest.addElement(vecRoads.elementAt(ia));
          }
        }

        vecRoads.removeElementAt(vecRoads.size()-1);

        return;
      }

      boolean blnMustContinue=false;

      for(int ia=0;ia<vecRoads.size()-1;ia++) {
        BIMRoad roadNext2=(BIMRoad)vecRoads.elementAt(ia);

        BIMIntersection intersectionNext2=roadNext2.getTo();

        if(intersectionNext2.getPoint().getX()==intersectionNext.getPoint().getX() & intersectionNext2.getPoint().getY()==intersectionNext.getPoint().getY()) {
          blnMustContinue=true;

          break;
        }
      }

      if(blnMustContinue) {
        vecRoads.removeElementAt(vecRoads.size()-1);

        continue;
      }

      if(intMaxBranches!=intCurrentBranch) {
        BIMIntersection.cycleThroughDestinations(intersectionNext, bimIntersectionTo, intMaxBranches, intCurrentBranch+1, dblFastestTime, dblTimeTotalNext, dblCurrentClosestTime, bimIntersectionClosest, vecIntersectionClosestRoads, vecRoads, vecRoadsFastest, dblPercentageOfSpeedLimit);
      }

      vecRoads.removeElementAt(vecRoads.size()-1);
    }
  }

  public static BIMIntersection findClosestMajorIntersection(BIMIntersection bimIntersection, TreeMap hshMajorIntersections, Vector vecRoadsMajorFrom) throws Exception {
    BIMIntersection intersectionReturn=null;

    double dblFastestTime=Double.MAX_VALUE-5.0d;

    Iterator iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMIntersection bimIntersectionNext=(BIMIntersection)mEntry.getValue();

      BIMDouble dblCurrentTime=new BIMDouble(-1.0d);

      try {
        Vector vecRoads=BIMIntersection.findFastestPath(bimIntersection, bimIntersectionNext, dblCurrentTime, 3, 12);

        if(dblCurrentTime.getDouble()<dblFastestTime) {
          dblFastestTime=dblCurrentTime.getDouble();

          vecRoadsMajorFrom.removeAllElements();

          for(int i=0;i<vecRoads.size();i++)
            vecRoadsMajorFrom.addElement(vecRoads.elementAt(i));

          intersectionReturn=bimIntersectionNext;
        }
      }
      catch(Exception ex) {
//        System.out.println(ex.toString());
      }
    }

    return intersectionReturn;
  }

  public static BIMIntersectionPath findMajorIntersectionsPaths(TreeMap hshMajorIntersections, BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo) throws Exception {
    Vector vecIntersectionsPath=new Vector();

    BIMIntersection.findMajorIntersectionsPaths(hshMajorIntersections, bimIntersectionFrom, bimIntersectionTo, new Vector(), vecIntersectionsPath);

    if(vecIntersectionsPath.size()==0) {
      throw new Exception("Unable to find path to major intersection.");
    }
    else {
      BIMRoad roadFinal=(BIMRoad)vecIntersectionsPath.elementAt(vecIntersectionsPath.size()-1);

      BIMIntersection intersectionFinal=roadFinal.getTo();

      if(intersectionFinal.getPoint().getX()!=bimIntersectionTo.getPoint().getX() | intersectionFinal.getPoint().getY()!=bimIntersectionTo.getPoint().getY()) {
        throw new Exception("Unable to find path to major intersection.");
      }
    }

    double dblPathTime=0.0d;

    for(int i=0;i<vecIntersectionsPath.size();i++) {
      BIMRoad roadNext=(BIMRoad)vecIntersectionsPath.elementAt(i);

      dblPathTime=dblPathTime+roadNext.getLength()/roadNext.getSpeedLimit();
    }

    BIMIntersectionPath pathReturn=new BIMIntersectionPath(bimIntersectionTo, vecIntersectionsPath, dblPathTime);

    return pathReturn;
  }

  public static void findMajorIntersectionsPaths(TreeMap hshMajorIntersections, BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, Vector vecIntersectionsChecked, Vector vecIntersectionsPath) throws Exception {
//y1
    double dblLatitudeFrom=bimIntersectionFrom.getLatitude();
//x1
    double dblLongitudeFrom=bimIntersectionFrom.getLongitude();

    double dblLatitudeTo=bimIntersectionTo.getLatitude();
    double dblLongitudeTo=bimIntersectionTo.getLongitude();


    double dblDistanceBetweenFromAndTo=Math.sqrt(Math.pow((dblLongitudeFrom-dblLongitudeTo), 2.0d)+Math.pow((dblLatitudeFrom-dblLatitudeTo), 2.0d));


//m
    double dblSlope=(dblLatitudeTo-dblLatitudeFrom)/(dblLongitudeTo-dblLongitudeFrom);

//mP
    double dblPerpendicularSlope=-1.0d/dblSlope;

// y - y1 = m ( x - x1 )
// y = m*x - m*x1 + y1

// mP*x - mP*x3 + y3 = m*x - m*x1 + y1
// (mP - m)*x = mP*x3 - y3 - m*x1 + y1
// x = (mP*x3 - y3 - m*x1 + y1) / (mP - m)

    double dblDistanceClosest=Double.MAX_VALUE-5.0d;
    BIMIntersection intersectionClosest=null;
    BIMRoad roadsClosest[]=new BIMRoad[0];

    Iterator iter=hshMajorIntersections.entrySet().iterator();

    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

      if(intersectionNext.getPoint().getX()==bimIntersectionFrom.getPoint().getX() & intersectionNext.getPoint().getY()==bimIntersectionFrom.getPoint().getY())
        continue;

      boolean blnMustContinue=false;

      for(int i=0;i<vecIntersectionsChecked.size();i++) {
        BIMIntersection intersectionCheck=(BIMIntersection)vecIntersectionsChecked.elementAt(i);

        if(intersectionNext.getPoint().getX()==intersectionCheck.getPoint().getX() & intersectionNext.getPoint().getY()==intersectionCheck.getPoint().getY()) {
          blnMustContinue=true;

          break;
        }
      }

      if(blnMustContinue)
        continue;

//y3
      double dblLatitudeNext=intersectionNext.getLatitude();
//x3
      double dblLongitudeNext=intersectionNext.getLongitude();

      double dblDistanceBetweenNextAndTo=Math.sqrt(Math.pow((dblLongitudeNext-dblLongitudeTo), 2.0d)+Math.pow((dblLatitudeNext-dblLatitudeTo), 2.0d));

      if(dblDistanceBetweenNextAndTo>dblDistanceBetweenFromAndTo) {
        vecIntersectionsChecked.addElement(intersectionNext);

        continue;
      }

      double dblDistanceBetweenNextAndFrom=Math.sqrt(Math.pow((dblLongitudeNext-dblLongitudeFrom), 2.0d)+Math.pow((dblLatitudeNext-dblLatitudeFrom), 2.0d));

      if(dblDistanceBetweenNextAndFrom>dblDistanceBetweenFromAndTo) {
        vecIntersectionsChecked.addElement(intersectionNext);

        continue;
      }

      double dblX=(dblPerpendicularSlope*dblLongitudeNext - dblLatitudeNext - dblSlope*dblLongitudeFrom + dblLatitudeFrom)/(dblPerpendicularSlope-dblSlope);

      double dblY=dblSlope*dblX - dblSlope*dblLongitudeFrom + dblLatitudeFrom;

      double dblDistanceNext=Math.sqrt(Math.pow((dblLongitudeNext-dblX), 2.0d)+Math.pow((dblLatitudeNext-dblY), 2.0d));

      if(dblDistanceNext<dblDistanceClosest) {
        try {
          roadsClosest=BIMIntersection.findFastestPathDirect(bimIntersectionFrom, intersectionNext, new BIMDouble(-1.0d));

          dblDistanceClosest=dblDistanceNext;

          intersectionClosest=intersectionNext;
        }
        catch(Exception ex) {
//          System.out.println(ex.toString());
        }
      }
    }

    if(intersectionClosest!=null) {
      for(int i=0;i<roadsClosest.length;i++) {
        vecIntersectionsPath.addElement(roadsClosest[i]);
      }

      BIMIntersection roadsLastTo=roadsClosest[roadsClosest.length-1].getTo();

      if(roadsLastTo.getPoint().getX()==bimIntersectionTo.getPoint().getX() & roadsLastTo.getPoint().getY()==bimIntersectionTo.getPoint().getY()) {
        return;
      }
      else {
        try {
          BIMRoad roadsFinal[]=BIMIntersection.findFastestPathDirect(intersectionClosest, bimIntersectionTo, new BIMDouble(-1.0d));

          for(int i=0;i<roadsFinal.length;i++) {
            vecIntersectionsPath.addElement(roadsFinal[i]);
          }
        }
        catch(Exception ex) {
          BIMIntersection.findMajorIntersectionsPaths(hshMajorIntersections, intersectionClosest, bimIntersectionTo, vecIntersectionsChecked, vecIntersectionsPath);
        }
      }
    }
  }

//1 degree latitude is 69 miles
//1 degree longitude is 54.6 miles
  public static double lengthFromHaversine(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo) {
// distance between latitudes and longitudes

    double lat1=bimIntersectionFrom.getLatitude();
    double lon1=bimIntersectionFrom.getLongitude();

    double lat2=bimIntersectionTo.getLatitude();
    double lon2=bimIntersectionTo.getLongitude();

    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);
  
// convert to radians 
    lat1 = Math.toRadians(lat1);
    lat2 = Math.toRadians(lat2);
  
// apply formulae 
    double a = Math.pow(Math.sin(dLat / 2), 2) + Math.pow(Math.sin(dLon / 2), 2) * Math.cos(lat1) * Math.cos(lat2);
    double rad = 6371.0d * 0.621371d;
    double c = 2 * Math.asin(Math.sqrt(a));

    return rad * c;
  }

  public Object clone() {
    BIMIntersection objClone=new BIMIntersection(strName.toString(), new BIMPoint(pnt.getX(), pnt.getY()), dblLatitude.doubleValue(), dblLongitude.doubleValue());

    Vector vecDClone=new Vector();
    for(int i=0;i<vecDestinations.size();i++) {
      BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

      vecDClone.addElement(roadNext);
//      vecDClone.addElement(roadNext.clone());
    }
    objClone.setDestinations(vecDClone);

    TreeMap mapMajorIntersectionsClone=new TreeMap();
    Iterator iter=mapMajorIntersections.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();

      BIMPoint pntNext=(BIMPoint)mEntry.getKey();
      BIMIntersectionPath intersectionPathNext=(BIMIntersectionPath)mEntry.getValue();

      mapMajorIntersectionsClone.put(pntNext.clone(), intersectionPathNext);
//      mapMajorIntersectionsClone.put(pntNext.clone(), intersectionPathNext.clone());
    }
    objClone.setMajorIntersections(mapMajorIntersectionsClone);

    return objClone;
  }
}