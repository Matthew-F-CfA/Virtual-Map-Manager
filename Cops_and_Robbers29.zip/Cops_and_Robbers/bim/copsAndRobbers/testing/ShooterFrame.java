package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class ShooterFrame extends Frame
implements ActionListener {
  volatile ShooterCanvas sCanv=null;

  volatile MyKeyEventDispatcher keyEventDispatcher=new MyKeyEventDispatcher();

  volatile Button btnReset=new Button("Reset");


  public static void main(String args[]) {
    if(args.length!=2) {
      System.out.println("Usage:");
      System.out.println("  java bim.copsAndRobbers.testing.ShooterFrame <# of shooters> <# of targets>");

      return;
    }

    int intShootersCount=Integer.parseInt(args[0]);
    int intTargetsCount=Integer.parseInt(args[1]);

    ShooterFrame sFrame=new ShooterFrame(intShootersCount, intTargetsCount);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    sFrame.setSize(dimScreen.width, dimScreen.height-50);
    sFrame.setVisible(true);

    sFrame.sCanv.reset();

    new Thread(sFrame.sCanv).start();
  }

  public ShooterFrame(int intShootersCount, int intTargetsCount) {
    super("Shooter Frame");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    sCanv=new ShooterCanvas(intShootersCount, intTargetsCount);

    add("Center", sCanv);
    sCanv.addMouseListener(sCanv);

    KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    manager.addKeyEventDispatcher(keyEventDispatcher);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnReset);
    btnReset.addActionListener(this);

    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnReset) {
      sCanv.reset();
    }
  }

  class ShooterCanvas extends Canvas
  implements Runnable, MouseListener {
    volatile int intShootersCount=0;
    volatile Vector vecShooters=new Vector();

    volatile int intTargetsCount=0;
    volatile Vector vecTargets=new Vector();

    volatile Object syncBullets=new Object();
    volatile Vector vecBullets=new Vector();

    volatile Player player=null;

    ShooterCanvas(int intShootersCount, int intTargetsCount) {
      super();

      this.intShootersCount=intShootersCount;
      this.intTargetsCount=intTargetsCount;
    }

    public void reset() {
      Dimension dimCanvas=getSize();

      int intUpperLeftX=0;
      int intUpperLeftY=0;
      int intLowerRightX=dimCanvas.width;
      int intLowerRightY=dimCanvas.height;

      double dblWidth=new Integer(dimCanvas.width).doubleValue();
      double dblHeight=new Integer(dimCanvas.height).doubleValue();

      vecShooters.removeAllElements();
      vecTargets.removeAllElements();

      for(int i=0;i<intTargetsCount;i++) {
        double dblX=Math.random()*dblWidth;
        double dblY=Math.random()*dblHeight;

        dblX=Math.floor(dblX);
        dblY=Math.floor(dblY);

        int intX=(int)dblX;
        int intY=(int)dblY;

        Target target=new Target(15, 15, intX, intY, 5.0d);

        target.chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

        vecTargets.addElement(target);
      }

      for(int i=0;i<intShootersCount;i++) {
        double dblX=Math.random()*dblWidth;
        double dblY=Math.random()*dblHeight;

        dblX=Math.floor(dblX);
        dblY=Math.floor(dblY);

        int intX=(int)dblX;
        int intY=(int)dblY;

        Shooter shooter=new Shooter(15, 15, intX, intY, 10.0d);

        shooter.setDoChooseNewDestination(false);

        shooter.chooseNewDestination(vecTargets);

        vecShooters.addElement(shooter);
      }
    }

    public void run() {
      int intUpperLeftX=0;
      int intUpperLeftY=0;
      int intLowerRightX=sCanv.getSize().width;
      int intLowerRightY=sCanv.getSize().height;

      while(true) {
        repaint();

        try {
          Thread.sleep(100l);
        }
        catch(Exception ex) {
        }

        intLowerRightX=sCanv.getSize().width;
        intLowerRightY=sCanv.getSize().height;

        Vector vecMovementPathShooter=new Vector();

        Vector vecShotShooters=new Vector();

        for(int i=0;i<vecShooters.size();i++) {
          VectorMovementObject vObj=(VectorMovementObject)vecShooters.elementAt(i);

          Shooter sNext=(Shooter)vObj;

          Vector vecMovementPathShooter0=new Vector();

          sNext.move(1.0d, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecMovementPathShooter0);

          vecMovementPathShooter.addElement(vecMovementPathShooter0);

          if(((Target)vObj).isShot())
            vecShotShooters.addElement(new Boolean(true));
          else
            vecShotShooters.addElement(new Boolean(false));

          sNext.lngCooldown=sNext.lngCooldown-100l;

          if(sNext.lngCooldown<=0l) {
            sNext.lngCooldown=sNext.lngResetCooldown;

//            if(sNext.vTarget==null) {
//System.out.println("isNull");
//            }
            if(sNext.vTarget!=null) {
//              if(sNext.vTarget.isShot()) {
//System.out.println("isShot");
//              }
              if(!sNext.vTarget.isShot()) {
                double dblShooterX=new Integer(vObj.getX()).doubleValue();
                double dblShooterY=new Integer(vObj.getY()).doubleValue();

                double dblTargetX=new Integer(sNext.vTarget.getX()).doubleValue();
                double dblTargetY=new Integer(sNext.vTarget.getY()).doubleValue();

                double dblAngle=Math.PI/2.0d;
                int intQuadrant=0;

                if(dblTargetX==dblShooterX) {
                  if(dblTargetY>dblShooterY) {
//
                  }
                  if(dblTargetY<dblShooterY) {
                    intQuadrant=3;
                  }
                  else {
                    sNext.vTarget.setIsShot(true);

                    continue;
                  }
                }
                else {
                  dblAngle=Math.atan((dblTargetY-dblShooterY)/(dblTargetX-dblShooterX));

                  dblAngle=Math.abs(dblAngle);

                  if(dblTargetY>dblShooterY) {
                    if(dblTargetX>dblShooterX) {
                      intQuadrant=0;
                    }
                    else if(dblTargetX<dblShooterX) {
                      intQuadrant=1;
                    }
                    else {
//
                    }
                  }
                  else if(dblTargetY<dblShooterY) {
                    if(dblTargetX>dblShooterX) {
                      intQuadrant=3;
                    }
                    else if(dblTargetX<dblShooterX) {
                      intQuadrant=2;
                    }
                    else {
//
                    }
                  }
                  else {
                    if(dblTargetX>dblShooterX) {
                      intQuadrant=0;
                    }
                    else if(dblTargetX<dblShooterX) {
                      intQuadrant=1;
                    }
                    else {
//
                    }
                  }
                }


                double dblX=new Integer(vObj.getX()).doubleValue();
                double dblY=new Integer(vObj.getY()).doubleValue();

                double dblUpperLeftX=0.0d;
                double dblUpperLeftY=0.0d;
                double dblLowerRightX=new Integer(intLowerRightX).doubleValue();
                double dblLowerRightY=new Integer(intLowerRightY).doubleValue();

                double dblDestination[]=VectorMovementObject.chooseNewDestination(dblAngle, intQuadrant, dblX, dblY, dblUpperLeftX, dblUpperLeftY, dblLowerRightX, dblLowerRightY);

                int intXDestination=(int)Math.rint(dblDestination[0]);
                int intYDestination=(int)Math.rint(dblDestination[1]);

                Bullet bObj=new Bullet((Target)vObj, 7, 7, vObj.getX(), vObj.getY(), 50.0d, dblAngle, intQuadrant, intXDestination, intYDestination);

synchronized(sCanv.syncBullets) {

                vecBullets.addElement(bObj);

}

              }
            }
          }
        }

        Vector vecMovementPath=new Vector();

        Vector vecShotTargets=new Vector();

        for(int i=0;i<vecTargets.size();i++) {
          VectorMovementObject vObj=(VectorMovementObject)vecTargets.elementAt(i);

          Vector vecMovementPath0=new Vector();

          vObj.move(1.0d, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecMovementPath0);

          vecMovementPath.addElement(vecMovementPath0);

/*
for(int ia=0;ia<vecMovementPath0.size();ia++) {
System.out.println(vecMovementPath0.elementAt(ia).toString());
}
*/

          if(((Target)vObj).isShot())
            vecShotTargets.addElement(new Boolean(true));
          else
            vecShotTargets.addElement(new Boolean(false));
        }

        Vector vecMovementPathPlayer=new Vector();

        boolean blnShotPlayer=false;

        if(player!=null) {
          player.move(1.0d, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecMovementPathPlayer);

          if(player.isShot())
            blnShotPlayer=true;
          else
            blnShotPlayer=false;
        }

synchronized(sCanv.syncBullets) {

        Vector vecFinishedBullets=new Vector();

        Vector vecShotBullets=new Vector();

        for(int i=0;i<vecBullets.size();i++) {
          vecFinishedBullets.addElement(new Boolean(false));
          vecShotBullets.addElement(new Boolean(false));
        }

        for(int i=0;i<vecBullets.size();i++) {
          VectorMovementObject vObj=(VectorMovementObject)vecBullets.elementAt(i);

          int intXBefore=vObj.getX();
          int intYBefore=vObj.getY();

          Bullet bullet=(Bullet)vObj;

          Vector vecMovementPath0=new Vector();

          vObj.move(1.0d, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecMovementPath0);

          int intXAfter=vObj.getX();
          int intYAfter=vObj.getY();

          if(vecMovementPath0.size()==0 || (intXBefore==intXAfter & intYBefore==intYAfter)) {
//System.out.println("0 movement path:"+System.currentTimeMillis());
            for(int ia=0;ia<vecTargets.size();ia++) {
              Target target=(Target)vecTargets.elementAt(ia);

              if(vObj.getX()==target.getX() & vObj.getY()==target.getY()) {
                vecShotTargets.setElementAt(new Boolean(true), ia);

                vecShotBullets.setElementAt(new Boolean(true), i);
              }
            }

            vecFinishedBullets.setElementAt(new Boolean(true), i);

            continue;
          }

//System.out.println("bullet vec size:"+vecMovementPath0.size()+", "+System.currentTimeMillis());

          for(int ia=0;ia<vecMovementPath0.size();ia++) {
            MovementPath mPath=(MovementPath)vecMovementPath0.elementAt(ia);

//System.out.println("bullet:"+mPath.toString());

            
            if(bullet.getTargetShooter()!=player) {
              for(int iz=0;iz<vecMovementPathPlayer.size();iz++) {
                MovementPath mPathT=(MovementPath)vecMovementPathPlayer.elementAt(iz);

                if(VectorMovementObject.checkCollision(mPath, mPathT)) {

                  blnShotPlayer=true;

                  vecShotBullets.setElementAt(new Boolean(true), i);
                }
              }
            }

            for(int iz=0;iz<vecMovementPath.size();iz++) {
              Vector vecMovementPathT=(Vector)vecMovementPath.elementAt(iz);

              for(int izz=0;izz<vecMovementPathT.size();izz++) {
                MovementPath mPathT=(MovementPath)vecMovementPathT.elementAt(izz);

//System.out.println("target:"+mPathT.toString());

                if(VectorMovementObject.checkCollision(mPath, mPathT)) {
                  
                  vecShotTargets.setElementAt(new Boolean(true), iz);

                  vecShotBullets.setElementAt(new Boolean(true), i);
                }
              }
            }

            for(int iz=0;iz<vecMovementPathShooter.size();iz++) {
              Vector vecMovementPathT=(Vector)vecMovementPathShooter.elementAt(iz);

              Target targetNext=(Target)vecShooters.elementAt(iz);

              if(bullet.getTargetShooter()!=targetNext) {
                for(int izz=0;izz<vecMovementPathT.size();izz++) {
                  MovementPath mPathT=(MovementPath)vecMovementPathT.elementAt(izz);

//System.out.println("shooter:"+mPathT.toString());

                  if(VectorMovementObject.checkCollision(mPath, mPathT)) {
                  
                    vecShotShooters.setElementAt(new Boolean(true), iz);

                    vecShotBullets.setElementAt(new Boolean(true), i);
                  }
                }
              }
            }

          }
        }

        if(player!=null) {
          if(blnShotPlayer) {
            player.setIsShot(true);

            player=null;
          }
        }

        for(int i=vecShooters.size()-1;i>=0;i--) {
          boolean blnShot=((Boolean)vecShotShooters.elementAt(i)).booleanValue();

          if(blnShot) {
//System.out.println("target shot");
            Target tObj=(Target)vecShooters.elementAt(i);

            tObj.setIsShot(true);

            vecShooters.removeElementAt(i);
          }
        }

        for(int i=vecTargets.size()-1;i>=0;i--) {
          boolean blnShot=((Boolean)vecShotTargets.elementAt(i)).booleanValue();

          if(blnShot) {
//System.out.println("target shot");
            Target tObj=(Target)vecTargets.elementAt(i);

            tObj.setIsShot(true);

            vecTargets.removeElementAt(i);
          }
        }

        for(int i=vecBullets.size()-1;i>=0;i--) {
          boolean blnShot=((Boolean)vecShotBullets.elementAt(i)).booleanValue();

          if(blnShot) {
//System.out.println("bullet shot");
            vecBullets.removeElementAt(i);
          }
        }

        for(int i=vecBullets.size()-1;i>=0;i--) {
          boolean blnFinished=((Boolean)vecFinishedBullets.elementAt(i)).booleanValue();

          if(blnFinished)
            vecBullets.removeElementAt(i);
        }

}

      }
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      int intX=me.getX();
      int intY=me.getY();

      if(player==null) {
        Player player0=new Player(15, 15, intX, intY, 15.0d);

        player0.setDoChooseNewDestination(false);

        player0.chooseNewDestination(intX, intY, -1, -1);

        player=player0;

        repaint();
      }
      else {
        player.chooseNewDestination(intX, intY, -1, -1);
      }
    }

    public void paint(Graphics graph) {
      graph.setColor(Color.red);

      for(int i=0;i<vecShooters.size();i++) {
        VectorMovementObject vObj=(VectorMovementObject)vecShooters.elementAt(i);

        graph.fillOval(vObj.getX()-vObj.getWidth()/2, vObj.getY()-vObj.getHeight()/2, vObj.getWidth(), vObj.getHeight());
      }

      graph.setColor(Color.green);

      for(int i=0;i<vecTargets.size();i++) {
        VectorMovementObject vObj=(VectorMovementObject)vecTargets.elementAt(i);

        graph.fillOval(vObj.getX()-vObj.getWidth()/2, vObj.getY()-vObj.getHeight()/2, vObj.getWidth(), vObj.getHeight());
      }

      graph.setColor(Color.black);

      for(int i=0;i<vecBullets.size();i++) {
        VectorMovementObject vObj=(VectorMovementObject)vecBullets.elementAt(i);

        graph.fillOval(vObj.getX()-vObj.getWidth()/2, vObj.getY()-vObj.getHeight()/2, vObj.getWidth(), vObj.getHeight());
      }

      Player player0=player;

      if(player0!=null) {
        graph.setColor(Color.blue);

        graph.fillOval(player0.getX()-player0.getWidth()/2, player0.getY()-player0.getHeight()/2, player0.getWidth(), player0.getHeight());

        double dblAimAngle=player0.dblAimAngle;
        int intAimQuadrant=player0.intAimQuadrant;

        double dblXDisp=Math.cos(dblAimAngle);
        double dblYDisp=Math.sin(dblAimAngle);

        if(intAimQuadrant==0) {
//
        }
        else if(intAimQuadrant==1) {
          dblXDisp=-dblXDisp;
        }
        else if(intAimQuadrant==2) {
          dblXDisp=-dblXDisp;
          dblYDisp=-dblYDisp;
        }
        else if(intAimQuadrant==3) {
          dblYDisp=-dblYDisp;
        }

        dblXDisp=dblXDisp*new Integer(player0.getWidth()/2).doubleValue();
        dblYDisp=dblYDisp*new Integer(player0.getHeight()/2).doubleValue();

        int intXDisp=(int)Math.rint(dblXDisp);
        int intYDisp=(int)Math.rint(dblYDisp);

        graph.fillOval(player0.getX()+intXDisp-3, player0.getY()+intYDisp-3, 7, 7);
      }
    }
  }

  class Shooter extends Target {
    volatile long lngResetCooldown=2000l;
    volatile long lngCooldown=0l;
    volatile Target vTarget=null;

    Shooter(int intWidth, int intHeight, int intX, int intY, double dblSpeed) {
      super(intWidth, intHeight, intX, intY, dblSpeed);
    }

    public void move(double dblTime, int intUpperLeftX, int intUpperLeftY, int intLowerRightX, int intLowerRightY, Vector vecReturnMP) {
      chooseNewDestination(sCanv.vecTargets);

/*
      if(intX==intXDestination & intY==intYDestination) {
        chooseNewDestination(sCanv.vecTargets);

        if(intX==intXDestination & intY==intYDestination)
          return;
      }
      else {
        if(vTarget.isShot()) {
          vTarget=null;

          chooseNewDestination(sCanv.vecTargets);

          if(intX==intXDestination & intY==intYDestination)
            return;
        }
      }
*/

      super.move(dblTime, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
    }

    public VectorMovementObject chooseNewDestination(Vector vecTargets) {
      double dblX=new Integer(getX()).doubleValue();
      double dblY=new Integer(getY()).doubleValue();

      double dblCloseDistance=Double.MAX_VALUE;
      int intCloseIndex=-1;

      for(int i=0;i<vecTargets.size();i++) {
        VectorMovementObject vObj=(VectorMovementObject)vecTargets.elementAt(i);

        double dblNextX=new Integer(vObj.getX()).doubleValue();
        double dblNextY=new Integer(vObj.getY()).doubleValue();

        double dblNextDistance=Math.sqrt(Math.pow((dblX-dblNextX), 2.0d)+Math.pow((dblY-dblNextY), 2.0d));

        if(dblNextDistance<dblCloseDistance) {
          dblCloseDistance=dblNextDistance;

          intCloseIndex=i;
        }
      }

      VectorMovementObject vObj=null;

      if(intCloseIndex==-1) {
        if(sCanv.player!=null) {
          vObj=sCanv.player;
        }
      }
      else {
        if(sCanv.player==null) {
          vObj=(VectorMovementObject)vecTargets.elementAt(intCloseIndex);
        }
        else {
          double dblNextX=new Integer(sCanv.player.getX()).doubleValue();
          double dblNextY=new Integer(sCanv.player.getY()).doubleValue();

          double dblNextDistance=Math.sqrt(Math.pow((dblX-dblNextX), 2.0d)+Math.pow((dblY-dblNextY), 2.0d));

          if(dblNextDistance<dblCloseDistance) {
            vObj=sCanv.player;
          }
          else {
            vObj=(VectorMovementObject)vecTargets.elementAt(intCloseIndex);
          }
        }
      }

      if(vObj==null) {
        setXDestination(getX());
        setYDestination(getY());

        vTarget=null;
      }
      else {
        int intVObjX=vObj.getX();
        int intVObjY=vObj.getY();

        double dblVObjX=new Integer(intVObjX).doubleValue();
        double dblVObjY=new Integer(intVObjY).doubleValue();

        double dblReferenceAngle0=Math.atan((dblVObjY-dblY)/(dblVObjX-dblX));

        dblReferenceAngle0=Math.abs(dblReferenceAngle0);

        int intQuadrant0=0;

        if(intX<=intVObjX) {
          if(intY<=intVObjY) {
            intQuadrant0=0;
          }
          else {
            intQuadrant0=3;
          }
        }
        else {
          if(intY<=intVObjY) {
            intQuadrant0=1;
          }
          else {
            intQuadrant0=2;
          }
        }

        setQuadrant(intQuadrant0);

        setReferenceAngle(dblReferenceAngle0);

        setXDestination(intVObjX);
        setYDestination(intVObjY);

//System.out.println("d:"+vObj.getX()+", "+vObj.getY());

        vTarget=(Target)vObj;
      }

      return vTarget;
    }
  }

  class Target extends VectorMovementObject {
    volatile boolean blnShot=false;

    Target(int intWidth, int intHeight, int intX, int intY, double dblSpeed) {
      super(intWidth, intHeight, intX, intY, dblSpeed);
    }

    public boolean isShot() {
      return blnShot;
    }

    public void setIsShot(boolean blnShot) {
      this.blnShot=blnShot;
    }
  }

  class Player extends Target {
    volatile boolean blnShot=false;

    volatile double dblAimAngle=0.0d;
    volatile int intAimQuadrant=0;

    Player(int intWidth, int intHeight, int intX, int intY, double dblSpeed) {
      super(intWidth, intHeight, intX, intY, dblSpeed);
    }

    public boolean isShot() {
      return blnShot;
    }

    public void setIsShot(boolean blnShot) {
      this.blnShot=blnShot;
    }

    public void chooseNewDestination(int intDX, int intDY, int intInvalid1, int intInvalid2) {
      if(intDX==intX & intDY==intY) {
        setQuadrant(0);

        setReferenceAngle(0.0d);

        setXDestination(intDX);
        setYDestination(intDY);

        return;
      }

      double dblX=new Integer(intX).doubleValue();
      double dblY=new Integer(intY).doubleValue();

      int intVObjX=intDX;
      int intVObjY=intDY;

      double dblVObjX=new Integer(intVObjX).doubleValue();
      double dblVObjY=new Integer(intVObjY).doubleValue();

      double dblReferenceAngle0=Math.atan((dblVObjY-dblY)/(dblVObjX-dblX));

      dblReferenceAngle0=Math.abs(dblReferenceAngle0);

      int intQuadrant0=0;

      if(intX<=intVObjX) {
        if(intY<=intVObjY) {
          intQuadrant0=0;
        }
        else {
          intQuadrant0=3;
        }
      }
      else {
        if(intY<=intVObjY) {
          intQuadrant0=1;
        }
        else {
          intQuadrant0=2;
        }
      }

      setQuadrant(intQuadrant0);

      setReferenceAngle(dblReferenceAngle0);

      setXDestination(intVObjX);
      setYDestination(intVObjY);
    }
  }

  class Bullet extends VectorMovementObject {
    Target targetShooter=null;

    Bullet(Target targetShooter, int intWidth, int intHeight, int intX, int intY, double dblSpeed, double dblReferenceAngle, int intQuadrant, int intXDestination, int intYDestination) {
      super(intWidth, intHeight, intX, intY, dblSpeed, dblReferenceAngle, intQuadrant, intXDestination, intYDestination);

      this.targetShooter=targetShooter;
    }

    public Target getTargetShooter() {
      return targetShooter;
    }
  }

  class MyKeyEventDispatcher
  implements KeyEventDispatcher {
    public boolean dispatchKeyEvent(KeyEvent e) {
      Player player=sCanv.player;
      if(player==null)
        return false;

      switch (e.getID()) {
        case KeyEvent.KEY_PRESSED:
//          Input.press(e.getKeyChar() + "");
          break;
        case KeyEvent.KEY_RELEASED:
          int keyCode=e.getKeyCode();
          if(keyCode==KeyEvent.VK_UP) {
            VectorMovementObject vObj=player;

            double dblX=new Integer(vObj.getX()).doubleValue();
            double dblY=new Integer(vObj.getY()).doubleValue();

            double dblUpperLeftX=0.0d;
            double dblUpperLeftY=0.0d;
            double dblLowerRightX=new Integer(sCanv.getSize().width).doubleValue();
            double dblLowerRightY=new Integer(sCanv.getSize().height).doubleValue();

            double dblDestination[]=VectorMovementObject.chooseNewDestination(player.dblAimAngle, player.intAimQuadrant, dblX, dblY, dblUpperLeftX, dblUpperLeftY, dblLowerRightX, dblLowerRightY);

            int intXDestination=(int)Math.rint(dblDestination[0]);
            int intYDestination=(int)Math.rint(dblDestination[1]);

//System.out.println("destination: "+intXDestination+", "+intYDestination);

//if(intXDestination!=sCanv.getSize().width) {
//System.out.println("destination: "+intXDestination+", "+intYDestination);
//System.out.println("canvas size: "+sCanv.getSize().width+", "+sCanv.getSize().height);
//}

            Bullet bObj=new Bullet((Target)player, 7, 7, vObj.getX(), vObj.getY(), 50.0d, player.dblAimAngle, player.intAimQuadrant, intXDestination, intYDestination);

synchronized(sCanv.syncBullets) {

            sCanv.vecBullets.addElement(bObj);

}
          }
          else if(keyCode==KeyEvent.VK_DOWN) {
            double dblAngle0=player.dblAimAngle;

            if(player.intAimQuadrant==0) {
              dblAngle0=dblAngle0+Math.PI;
            }
            else if(player.intAimQuadrant==1) {
              dblAngle0=Math.PI-dblAngle0;

              dblAngle0=dblAngle0+Math.PI;
            }
            else if(player.intAimQuadrant==2) {
              dblAngle0=Math.PI+dblAngle0;

              dblAngle0=dblAngle0-Math.PI;
            }
            else if(player.intAimQuadrant==3) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              dblAngle0=dblAngle0-Math.PI;
            }

            int intQuadrant0=0;

            if(dblAngle0>=0.0d & dblAngle0<=(Math.PI/2.0d)) {
              dblAngle0=dblAngle0;

              intQuadrant0=0;
            }
            else if(dblAngle0>(Math.PI/2.0d) & dblAngle0<Math.PI) {
              dblAngle0=Math.PI-dblAngle0;

              intQuadrant0=1;
            }
            else if(dblAngle0>=Math.PI & dblAngle0<(Math.PI*3.0d/2.0d)) {
              dblAngle0=dblAngle0-Math.PI;

              intQuadrant0=2;
            }
            else if(dblAngle0>=(Math.PI*3.0d/2.0d) & dblAngle0<=(Math.PI*2.0d)) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              intQuadrant0=3;
            }


            VectorMovementObject vObj=player;

            double dblX=new Integer(vObj.getX()).doubleValue();
            double dblY=new Integer(vObj.getY()).doubleValue();

            double dblUpperLeftX=0.0d;
            double dblUpperLeftY=0.0d;
            double dblLowerRightX=new Integer(sCanv.getSize().width).doubleValue();
            double dblLowerRightY=new Integer(sCanv.getSize().height).doubleValue();

            double dblDestination[]=VectorMovementObject.chooseNewDestination(dblAngle0, intQuadrant0, dblX, dblY, dblUpperLeftX, dblUpperLeftY, dblLowerRightX, dblLowerRightY);

            int intXDestination=(int)Math.rint(dblDestination[0]);
            int intYDestination=(int)Math.rint(dblDestination[1]);

            Bullet bObj=new Bullet((Target)player, 7, 7, vObj.getX(), vObj.getY(), 50.0d, dblAngle0, intQuadrant0, intXDestination, intYDestination);

synchronized(sCanv.syncBullets) {

            sCanv.vecBullets.addElement(bObj);

}
          }
          else if(keyCode==KeyEvent.VK_RIGHT) {
            double dblAngle0=player.dblAimAngle;

            double dblIncrement=Math.PI/20.0d;

            if(player.intAimQuadrant==0) {
              dblAngle0=dblAngle0+dblIncrement;
            }
            else if(player.intAimQuadrant==1) {
              dblAngle0=Math.PI-dblAngle0;

              dblAngle0=dblAngle0+dblIncrement;
            }
            else if(player.intAimQuadrant==2) {
              dblAngle0=Math.PI+dblAngle0;

              dblAngle0=dblAngle0+dblIncrement;
            }
            else if(player.intAimQuadrant==3) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              dblAngle0=dblAngle0+dblIncrement;
            }

            dblAngle0=(Math.PI*2.0d+dblAngle0)%(Math.PI*2.0d);

            int intQuadrant0=0;

            if(dblAngle0>=0.0d & dblAngle0<=(Math.PI/2.0d)) {
              dblAngle0=dblAngle0;

              intQuadrant0=0;
            }
            else if(dblAngle0>(Math.PI/2.0d) & dblAngle0<Math.PI) {
              dblAngle0=Math.PI-dblAngle0;

              intQuadrant0=1;
            }
            else if(dblAngle0>=Math.PI & dblAngle0<(Math.PI*3.0d/2.0d)) {
              dblAngle0=dblAngle0-Math.PI;

              intQuadrant0=2;
            }
            else if(dblAngle0>=(Math.PI*3.0d/2.0d) & dblAngle0<=(Math.PI*2.0d)) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              intQuadrant0=3;
            }

            player.dblAimAngle=dblAngle0;
            player.intAimQuadrant=intQuadrant0;
          }
          else if(keyCode==KeyEvent.VK_LEFT) {
            double dblAngle0=player.dblAimAngle;

            double dblIncrement=Math.PI/20.0d;

            if(player.intAimQuadrant==0) {
              dblAngle0=dblAngle0-dblIncrement;
            }
            else if(player.intAimQuadrant==1) {
              dblAngle0=Math.PI-dblAngle0;

              dblAngle0=dblAngle0-dblIncrement;
            }
            else if(player.intAimQuadrant==2) {
              dblAngle0=Math.PI+dblAngle0;

              dblAngle0=dblAngle0-dblIncrement;
            }
            else if(player.intAimQuadrant==3) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              dblAngle0=dblAngle0-dblIncrement;
            }

            dblAngle0=(dblAngle0+Math.PI*2.0d)%(Math.PI*2.0d);

            int intQuadrant0=0;

            if(dblAngle0>=0.0d & dblAngle0<=(Math.PI/2.0d)) {
              dblAngle0=dblAngle0;

              intQuadrant0=0;
            }
            else if(dblAngle0>(Math.PI/2.0d) & dblAngle0<Math.PI) {
              dblAngle0=Math.PI-dblAngle0;

              intQuadrant0=1;
            }
            else if(dblAngle0>=Math.PI & dblAngle0<(Math.PI*3.0d/2.0d)) {
              dblAngle0=dblAngle0-Math.PI;

              intQuadrant0=2;
            }
            else if(dblAngle0>=(Math.PI*3.0d/2.0d) & dblAngle0<=(Math.PI*2.0d)) {
              dblAngle0=Math.PI*2.0d-dblAngle0;

              intQuadrant0=3;
            }

            player.dblAimAngle=dblAngle0;
            player.intAimQuadrant=intQuadrant0;
          }

          break;
        default:
          break;
      }

      return false;
    }
  }
}