package bim.copsAndRobbers.testing;

import java.awt.*;
import java.util.Vector;

class CornerTurnTestFrame extends Frame {
  TurnCanvas tCanv=new TurnCanvas();
  TurnThread tThr=new TurnThread();
  static int mobDiameter=15;

  public static void main(String args[]) {
    CornerTurnTestFrame cFrame=new CornerTurnTestFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    cFrame.setSize(dimScreen.width, dimScreen.height-40);
    cFrame.setVisible(true);

    cFrame.tCanv.initCanvas();
    cFrame.tThr.initMobs();
    cFrame.tThr.start();
  }

  CornerTurnTestFrame() {
    super("Corner Turn Test");

    add("Center", tCanv);
  }

  class TurnCanvas extends Canvas {
    int intTurnTopY=-1;
    int intTurnBottomY=-1;
    int intTurnLeftX=-1;
    int intTurnRightX=-1;
    int intVerticalPathWidth=-1;
    int intHorizontalPathHeight=-1;
    boolean blnInitd=false;

    TurnCanvas() {
      super();
    }

    public void initCanvas() {
      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

      intTurnLeftX=dimScreen.width/10;
      intTurnTopY=dimScreen.height/10;

      intTurnRightX=dimScreen.width/3;
      intTurnBottomY=dimScreen.height/3;

      intVerticalPathWidth=intTurnRightX-intTurnLeftX;
      intHorizontalPathHeight=intTurnBottomY-intTurnTopY;

      blnInitd=true;
    }

    public void paint(Graphics graph) {
      if(!blnInitd)
        return;

      graph.drawLine(intTurnLeftX, intTurnTopY, intTurnLeftX, getSize().height);
      graph.drawLine(intTurnLeftX, intTurnTopY, getSize().width, intTurnTopY);
      graph.drawLine(intTurnRightX, intTurnBottomY, intTurnRightX, getSize().height);
      graph.drawLine(intTurnRightX, intTurnBottomY, getSize().width, intTurnBottomY);

      graph.fillOval(tThr.mobOne.intX, tThr.mobOne.intY, mobDiameter, mobDiameter);
      graph.fillOval(tThr.mobTwo.intX, tThr.mobTwo.intY, mobDiameter, mobDiameter);
      graph.fillOval(tThr.mobThree.intX, tThr.mobThree.intY, mobDiameter, mobDiameter);
    }
  }

  class TurnThread extends Thread {
    Mobile mobOne=new Mobile();
    Mobile mobTwo=new Mobile();
    Mobile mobThree=new Mobile();

    long lngDelay=100l;

    TurnThread() {
      super();
    }

    public void initMobs() {
      mobOne.vecDependents.addElement(mobTwo);
      mobOne.vecDependents.addElement(mobThree);
      mobTwo.vecDependents.addElement(mobOne);
      mobTwo.vecDependents.addElement(mobThree);
      mobThree.vecDependents.addElement(mobOne);
      mobThree.vecDependents.addElement(mobTwo);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

      TravelPath tPath=new TravelPath();

      int xDisp=tCanv.intVerticalPathWidth/3;
      int yDisp=tCanv.intHorizontalPathHeight/3;

      int intOneX=tCanv.intTurnLeftX+xDisp;
      int intTwoX=tCanv.intTurnLeftX+tCanv.intVerticalPathWidth/2;
      int intThreeX=tCanv.intTurnLeftX+xDisp*2;

      int intOneY=tCanv.intTurnTopY+yDisp;
      int intTwoY=tCanv.intTurnTopY+tCanv.intHorizontalPathHeight/2;
      int intThreeY=tCanv.intTurnTopY+yDisp*2;

      double dblLine[]=calculateLine(0.66d);

      double dblY=dblLine[0]*new Integer(intOneX).doubleValue()+dblLine[1];
      int intY=(int)Math.rint(dblY);

      Vector vecPoints=convertLineToPoints(intOneX, tCanv.getSize().height, intOneX, intY);
      tThr.mobOne.tPath1.vecPoints=vecPoints;

      double dblX=(new Integer(intOneY).doubleValue()-dblLine[1])/dblLine[0];

      vecPoints=convertLineToPoints(dblLine, new Integer(intOneX).doubleValue(), dblX);
      tThr.mobOne.tPath2.vecPoints=vecPoints;

      vecPoints=convertLineToPoints((int)Math.rint(dblX), intOneY, tCanv.getSize().width, intOneY);
      tThr.mobOne.tPath3.vecPoints=vecPoints;


      dblLine=calculateLine(0.5d);

      dblY=dblLine[0]*new Integer(intTwoX).doubleValue()+dblLine[1];
      intY=(int)Math.rint(dblY);

      vecPoints=convertLineToPoints(intTwoX, tCanv.getSize().height, intTwoX, intY);
      tThr.mobTwo.tPath1.vecPoints=vecPoints;

      dblX=(new Integer(intTwoY).doubleValue()-dblLine[1])/dblLine[0];

      vecPoints=convertLineToPoints(dblLine, new Integer(intTwoX).doubleValue(), dblX);
      tThr.mobTwo.tPath2.vecPoints=vecPoints;

      vecPoints=convertLineToPoints((int)Math.rint(dblX), intTwoY, tCanv.getSize().width, intTwoY);
      tThr.mobTwo.tPath3.vecPoints=vecPoints;


      dblLine=calculateLine(0.33d);

      dblY=dblLine[0]*new Integer(intThreeX).doubleValue()+dblLine[1];
      intY=(int)Math.rint(dblY);

      vecPoints=convertLineToPoints(intThreeX, tCanv.getSize().height, intThreeX, intY);
      tThr.mobThree.tPath1.vecPoints=vecPoints;

      dblX=(new Integer(intThreeY).doubleValue()-dblLine[1])/dblLine[0];

      vecPoints=convertLineToPoints(dblLine, new Integer(intThreeX).doubleValue(), dblX);
      tThr.mobThree.tPath2.vecPoints=vecPoints;

      vecPoints=convertLineToPoints((int)Math.rint(dblX), intThreeY, tCanv.getSize().width, intThreeY);
      tThr.mobThree.tPath3.vecPoints=vecPoints;
    }


/* Not used
//y1-y2 = m(x1-x2)
//y1-y2 = 1(x1-x2)
//y1-intOneY = 1(intOneX-x2)
//y1 = intOneX - x2 + intOneY


//y1-y2 = m(x1-x2)
//y1-tCanv.intTurnBottomY = -1(x1-tCanv.intTurnRightX)
//y1 = -x1 + tCanv.intTurnRightX + tCanv.intTurnBottomY


//d1 = Math.sqrt( Math.pow(x1-tCanv.intTurnRightX, 2.0d) + Math.pow(y1-tCanv.intTurnBottomY, 2.0d) )
*/

    public double[] calculateLine(double dblDiagonalDistance) {
//d = Math.sqrt( Math.pow(x1-x2, 2.0d) + Math.pow(y1-y2, 2.0d) )
//d = Math.sqrt( Math.pow(tCanv.intTurnLeftX - tCanv.intTurnRightX, 2.0d) + Math.pow(tCanv.intTurnTopY - tCanv.intTurnBottomY, 2.0d) )
//d1 = d*2.0d/3.0d
//theta = arctan(-1/1)
//theta = -Math.PI/4.0d
//x = d1 * Math.cos( theta )
//y = d1 * Math.sin( theta )
//xBetween = tCanv.intTurnRightX - x
//yBetween = tCanv.intTurnBottomY - y
//y1-y2 = m(x1-x2)
//y1 - yBetween = -1(x1 - xBetween)
//y1 = -x1 + xBetween + yBetween

      double d=Math.sqrt( Math.pow(new Integer(tCanv.intTurnLeftX).doubleValue() - new Integer(tCanv.intTurnRightX).doubleValue(), 2.0d) + Math.pow(new Integer(tCanv.intTurnTopY).doubleValue() - new Integer(tCanv.intTurnBottomY).doubleValue(), 2.0d) );
      double d1=d*dblDiagonalDistance;
      double theta=Math.PI/4.0d;
      double x=d1*Math.cos(theta);
      double y=d1*Math.sin(theta);
      double xBetween=new Integer(tCanv.intTurnRightX).doubleValue()-x;
      double yBetween=new Integer(tCanv.intTurnBottomY)-y;

      double m=-1.0d;
      double yIntercept=yBetween+xBetween;

      double dblRet[]=new double[2];

      dblRet[0]=m;
      dblRet[1]=yIntercept;

      return dblRet;
    }
 
    public Vector convertLineToPoints(int intStartX, int intStartY, int intEndX, int intEndY) {
      Vector vecRet=new Vector();

      int intSpace=10;

      if(intStartX==intEndX) {
        if(intEndY>intStartY) {
          int intJump=(intEndY-intStartY)/intSpace;

          int intNextX=intStartX;
          int intNextY=intStartY;

          for(int i=0;i<intJump;i++) {
            int intNextPoint[]=new int[2];

            intNextPoint[0]=intNextX;
            intNextPoint[1]=intNextY;

            vecRet.addElement(intNextPoint);

            intNextY+=intSpace;
          }
        }
        else {
          int intJump=(intStartY-intEndY)/intSpace;

          int intNextX=intStartX;
          int intNextY=intStartY;

          for(int i=0;i<intJump;i++) {
            int intNextPoint[]=new int[2];

            intNextPoint[0]=intNextX;
            intNextPoint[1]=intNextY;

            vecRet.addElement(intNextPoint);

            intNextY-=intSpace;
          }
        }
      }
      else if(intStartY==intEndY) {
        if(intEndX>intStartX) {
          int intJump=(intEndX-intStartX)/intSpace;

          int intNextX=intStartX;
          int intNextY=intStartY;

          for(int i=0;i<intJump;i++) {
            int intNextPoint[]=new int[2];

            intNextPoint[0]=intNextX;
            intNextPoint[1]=intNextY;

            vecRet.addElement(intNextPoint);

            intNextX+=intSpace;
          }
        }
        else {
          int intJump=(intStartX-intEndX)/intSpace;

          int intNextX=intStartX;
          int intNextY=intStartY;

          for(int i=0;i<intJump;i++) {
            int intNextPoint[]=new int[2];

            intNextPoint[0]=intNextX;
            intNextPoint[1]=intNextY;

            vecRet.addElement(intNextPoint);

            intNextX-=intSpace;
          }
        }
      }

      return vecRet;
    }

    public Vector convertLineToPoints(double dblLine[], double dblStartX, double dblEndX) {
      Vector vecRet=new Vector();

      double dblSpace=10.0d;

      if(dblEndX>dblStartX) {
        double dblJump=(dblEndX-dblStartX)/dblSpace;

        int intJump=(int)Math.rint(dblJump);

        double dblNextX=dblStartX;
        double dblNextY=dblLine[0]*dblNextX+dblLine[1];

        for(int i=0;i<intJump;i++) {
          int intNextPoint[]=new int[2];

          intNextPoint[0]=(int)Math.rint(dblNextX);
          intNextPoint[1]=(int)Math.rint(dblNextY);

          vecRet.addElement(intNextPoint);

          dblNextX+=dblSpace;
          dblNextY=dblLine[0]*dblNextX+dblLine[1];
        }
      }
      else {
        double dblJump=(dblStartX-dblEndX)/dblSpace;

        int intJump=(int)Math.rint(dblJump);

        double dblNextX=dblStartX;
        double dblNextY=dblLine[0]*dblNextX+dblLine[1];

        for(int i=0;i<intJump;i++) {
          int intNextPoint[]=new int[2];

          intNextPoint[0]=(int)Math.rint(dblNextX);
          intNextPoint[1]=(int)Math.rint(dblNextY);

          vecRet.addElement(intNextPoint);

          dblNextX-=dblSpace;
          dblNextY=dblLine[0]*dblNextX+dblLine[1];
        }
      }

      return vecRet;
    }

    public void run() {
      while(true) {
        try {
          Thread.sleep(lngDelay);
        }
        catch(Exception ex) {
        }

        mobOne.travel();
        mobTwo.travel();
        mobThree.travel();

        tCanv.repaint();
      }
    }
  }

  class Mobile {
    int intX=-1;
    int intY=-1;

    TravelPath tPath=new TravelPath();

    TravelPath tPath1=new TravelPath();
    TravelPath tPath2=new TravelPath();
    TravelPath tPath3=new TravelPath();
    int inttPathIndex=0;

    Vector vecDependents=new Vector();

    Mobile() {
      tPath=tPath1;
    }

    Mobile(int intX, int intY) {
      this.intX=intX;
      this.intY=intY;

      tPath=tPath1;
    }

    public void travel() {
      int intRet[]=tPath.travel();

      if(intRet[0]==-1 & intRet[1]==-1) {
        boolean blnMustWait=false;

        int i=0;
        for(;i<vecDependents.size();i++) {
          Mobile mobD=(Mobile)vecDependents.elementAt(i);

          if(inttPathIndex==2) {
            if((mobD.inttPathIndex!=0) & mobD.tPath.intIndex<mobD.tPath.vecPoints.size()) {
              blnMustWait=true;
              break;
            }
          }
          else {
            if((mobD.inttPathIndex!=(inttPathIndex+1)) & mobD.tPath.intIndex<mobD.tPath.vecPoints.size()) {
              blnMustWait=true;
              break;
            }
          }
        }

        if(blnMustWait) {
          intRet[0]=intX;
          intRet[1]=intY;
        }
        else {
          ++inttPathIndex;

          if(inttPathIndex==3) {
            inttPathIndex=0;
          }

          if(inttPathIndex==0)
            tPath=tPath1;
          else if(inttPathIndex==1)
            tPath=tPath2;
          else if(inttPathIndex==2)
            tPath=tPath3;

          tPath.intIndex=0;

          intRet=tPath.travel();
        }
      }

      intX=intRet[0];
      intY=intRet[1];
    }
  }

  class TravelPath {
    Vector vecPoints=new Vector();
    int intIndex=0;

    TravelPath() {
    }

    public int[] travel() {
      int intRet[]=new int[2];

      if(intIndex>=vecPoints.size()) {
        intRet[0]=-1;
        intRet[1]=-1;

        return intRet;
      }

      intRet=(int[])vecPoints.elementAt(intIndex);      

      ++intIndex;

      return intRet;
    }
  }
}