package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class PathRoamTestFrame extends Frame
implements MouseListener {
  volatile Object syncDeviate=new Object();

  volatile Vector vecMobiles=new Vector();
  volatile Vector vecPaths=new Vector();

  volatile PathRoamCanvas pCanv=new PathRoamCanvas();

  volatile RoamThread rThr=new RoamThread();

  volatile Vector vecGlobalTravelPaths=new Vector();

  public static void main(String args[]) {
    PathRoamTestFrame pFrame=new PathRoamTestFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    pFrame.setSize(dimScreen.width, dimScreen.height-40);
    pFrame.setVisible(true);

    pFrame.pCanv.initCanvas();
    pFrame.rThr.start();
  }

  PathRoamTestFrame() {
    super("Path Roam Test Frame");

    add("Center", pCanv);
    pCanv.addMouseListener(this);
  }

  public void mouseEntered(MouseEvent me) {
  }

  public void mouseExited(MouseEvent me) {
  }

  public void mousePressed(MouseEvent me) {
  }

  public void mouseReleased(MouseEvent me) {
  }

  public void mouseClicked(MouseEvent me) {
    Point pnt=me.getPoint();

synchronized(syncDeviate) {

    rThr.mob.intDeviateX=pnt.x;
    rThr.mob.intDeviateY=pnt.y;

//System.out.println(rThr.mob.intDeviateX);
//System.out.println(rThr.mob.intDeviateY);

    rThr.mob.blnDeviate=true;
    rThr.mob.blnDeviateReturning=false;
    rThr.mob.blnDeviatePathChosen=false;

}

  }

  class PathRoamCanvas extends Canvas {
    volatile boolean blnInitd=false;

    PathRoamCanvas() {
      super();
    }

    public void initCanvas() {
      blnInitd=true;
    }

    public void paint(Graphics graph) {
      if(!blnInitd)
        return;

      graph.fillOval(rThr.mob.intX, rThr.mob.intY, 15, 15);
    }
  }

  class RoamThread extends Thread {
    volatile Mobile mob=new Mobile();

    volatile long lngDelay=100l;

    RoamThread() {
      super();
    }

    public void run() {
//      TravelPath tPath=new TravelPath(0.0d, 100.0d, 100, 100, 500, 500);
      TravelPath tPath=new TravelPath(0.0d, 100.0d, 100, 100, 500, 100);

      mob.intX=100;
      mob.intY=100;
//      mob.intX=500;
//      mob.intY=100;
      mob.dblX=new Integer(mob.intX).doubleValue();
      mob.dblY=new Integer(mob.intY).doubleValue();

      TravelPath tPath2=new TravelPath(Double.NaN, 100.0d, 500, 100, 500, 500);

      mob.tPath=tPath;
      mob.choTowards=(ChoicePoint)mob.tPath.vecChoicePoints.elementAt(1);

//System.out.println(((ChoicePoint)tPath.vecChoicePoints.elementAt(0)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath.vecChoicePoints.elementAt(1)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath2.vecChoicePoints.elementAt(0)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath2.vecChoicePoints.elementAt(1)).vecTravelPaths.size());

      tPath.connect(tPath2);

//System.out.println(((ChoicePoint)tPath.vecChoicePoints.elementAt(0)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath.vecChoicePoints.elementAt(1)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath2.vecChoicePoints.elementAt(0)).vecTravelPaths.size());
//System.out.println(((ChoicePoint)tPath2.vecChoicePoints.elementAt(1)).vecTravelPaths.size());

      vecGlobalTravelPaths.addElement(tPath);
      vecGlobalTravelPaths.addElement(tPath2);

      while(true) {
        try {
          Thread.sleep(lngDelay);
        }
        catch(Exception ex) {
        }

        mob.travel();

        pCanv.repaint();
      }
    }
  }

  class Mobile {
    volatile int intX=-1;
    volatile int intY=-1;
    volatile double dblX=0.0d;
    volatile double dblY=0.0d;

    volatile double d=10.0d;

    volatile TravelPath tPath=null;
    volatile ChoicePoint choTowards=null;
    volatile boolean blnNeverBacktrack=false;

    volatile Vector vecDependents=new Vector();

    volatile int intDeviateX=-1;
    volatile int intDeviateY=-1;
    volatile boolean blnDeviate=false;
    volatile boolean blnDeviateReturning=false;
    volatile boolean blnDeviatePathChosen=false;
    volatile TravelPath tPathDeviateReturning=null;
    volatile ChoicePoint choPointDeviateReturning=null;

    Mobile() {
    }

    public void travel() {
      if(tPath==null)
        return;

synchronized(syncDeviate) {

      if(blnDeviate) {
        if(!blnDeviatePathChosen) {
          double dblShortestDistance=Double.MAX_VALUE;          

          for(int i=0;i<vecGlobalTravelPaths.size();i++) {
            TravelPath tPathG=(TravelPath)vecGlobalTravelPaths.elementAt(i);

            for(int ia=0;ia<tPathG.vecChoicePoints.size();ia++) {
              ChoicePoint choPoint=(ChoicePoint)tPathG.vecChoicePoints.elementAt(ia);

              int intCPX=choPoint.intX;
              int intCPY=choPoint.intY;

              double dblCPX=new Integer(intCPX).doubleValue();
              double dblCPY=new Integer(intCPY).doubleValue();

              double dblDeviateX=new Integer(intDeviateX).doubleValue();
              double dblDeviateY=new Integer(intDeviateY).doubleValue();

              double dblDistance=Math.sqrt(Math.pow(dblCPX-dblDeviateX, 2.0d)+Math.pow(dblCPY-dblDeviateY, 2.0d));
              if(dblDistance<dblShortestDistance) {
                tPathDeviateReturning=tPathG;
                choPointDeviateReturning=choPoint;
                dblShortestDistance=dblDistance;
              }
            }
          }

          blnDeviatePathChosen=true;
        }

        double dblDeviateX=new Integer(intDeviateX).doubleValue();
        double dblDeviateY=new Integer(intDeviateY).doubleValue();

        double dblTowardsX=dblDeviateX;
        double dblTowardsY=dblDeviateY;

        double dblRun=dblTowardsX-dblX;

        double m=(dblTowardsY-dblY)/dblRun;


        double dblLX=dblTowardsX;

        if(!Double.isNaN(m) & !Double.isInfinite(m)) {
          if(intDeviateX>intX) {
            dblLX=Math.sqrt( (Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(m*dblX, 2.0d))/(1.0d+Math.pow(m, 2.0d))+Math.pow(dblX, 2.0d) )+dblX;
//            dblLX=Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d)+1.0d/4.0d*Math.pow((-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d), 2.0d)) - 1.0d/2.0d*(-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d);
          }
          else {
            dblLX=-Math.sqrt( (Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(m*dblX, 2.0d))/(1.0d+Math.pow(m, 2.0d))+Math.pow(dblX, 2.0d) )+dblX;
//            dblLX=-Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d)+1.0d/4.0d*Math.pow((-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d), 2.0d)) - 1.0d/2.0d*(-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d);
          }
        }


        if(!Double.isNaN(m) & !Double.isInfinite(m)) {
          if(Double.isNaN(dblLX)) {
            if(blnDeviateReturning) {
              tPath=tPathDeviateReturning;
              choTowards=choPointDeviateReturning;

              changeDirection();

              blnDeviate=false;
            }
            else {
//System.out.println("return1");
              intDeviateX=choPointDeviateReturning.intX;
              intDeviateY=choPointDeviateReturning.intY;

              blnDeviateReturning=true;
            }

            return;
          }
        }
        else {
          if(intY==intDeviateY) {
            if(blnDeviateReturning) {
              tPath=tPathDeviateReturning;
              choTowards=choPointDeviateReturning;

              changeDirection();

              blnDeviate=false;
            }
            else {
//System.out.println("return2");
              intDeviateX=choPointDeviateReturning.intX;
              intDeviateY=choPointDeviateReturning.intY;

              blnDeviateReturning=true;
            }

            return;
          }
        }






        double dblLY=dblY;

        if(!Double.isNaN(m) & !Double.isInfinite(m)) {
          dblLY=m*dblLX-m*dblX+dblY;
        }
        else {
          if(dblTowardsY>dblY)
            dblLY+=d;
          else
            dblLY-=d;
        }

        dblX=dblLX;
        dblY=dblLY;

        int intLX=(int)Math.rint(dblX);
        int intLY=(int)Math.rint(dblY);

        int intTowardsX=intDeviateX;
        int intTowardsY=intDeviateY;

//        int intTowardsX=choTowards.intX;
//        int intTowardsY=choTowards.intY;


        double dblTowardsX2=new Integer(intTowardsX).doubleValue();
        double dblTowardsY2=new Integer(intTowardsY).doubleValue();

        double dblGap=Math.sqrt(Math.pow(dblTowardsX2-dblX, 2.0d)+Math.pow(dblTowardsY2-dblY, 2.0d));

        if(dblGap<=(d+1.1d)) {
          intX=intTowardsX;
          intY=intTowardsY;
          dblX=new Integer(intX).doubleValue();
          dblY=new Integer(intY).doubleValue();

          if(blnDeviateReturning) {
            tPath=tPathDeviateReturning;
            choTowards=choPointDeviateReturning;

            changeDirection();

            blnDeviate=false;
          }
          else {
            intDeviateX=choPointDeviateReturning.intX;
            intDeviateY=choPointDeviateReturning.intY;

            blnDeviateReturning=true;
          }

          return;
        }

/*
        if(Double.isNaN(m) || Double.isInfinite(m)) {
          if(intY>intTowardsY) {
            if(intLY<intTowardsY) {
              intLX=intTowardsX;
              intLY=intTowardsY;
              dblX=new Integer(intLX).doubleValue();
              dblY=new Integer(intLY).doubleValue();

//              intLY=intTowardsY;
//              dblY=new Integer(intLY).doubleValue();

//              intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

              if(blnDeviateReturning) {
                tPath=tPathDeviateReturning;
                choTowards=choPointDeviateReturning;

                changeDirection();

                blnDeviate=false;
              }
              else {
//System.out.println("return3");
                intDeviateX=choPointDeviateReturning.intX;
                intDeviateY=choPointDeviateReturning.intY;

                blnDeviateReturning=true;
              }
            }
          }
          else {
            if(intLY>intTowardsY) {
              intLX=intTowardsX;
              intLY=intTowardsY;
              dblX=new Integer(intLX).doubleValue();
              dblY=new Integer(intLY).doubleValue();

//              intLY=intTowardsY;
//              dblY=new Integer(intLY).doubleValue();

//              intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

              if(blnDeviateReturning) {
                tPath=tPathDeviateReturning;
                choTowards=choPointDeviateReturning;

                changeDirection();

                blnDeviate=false;
              }
              else {
//System.out.println("return4");
                intDeviateX=choPointDeviateReturning.intX;
                intDeviateY=choPointDeviateReturning.intY;

                blnDeviateReturning=true;
              }
            }
          }
        }
        else {
          if(intX>intTowardsX) {
            if(intLX<intTowardsX) {
              intLX=intTowardsX;
              intLY=intTowardsY;
              dblX=new Integer(intLX).doubleValue();
              dblY=new Integer(intLY).doubleValue();

//              intLX=intTowardsX;
//              dblX=new Integer(intLX).doubleValue();
//              intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);


              if(blnDeviateReturning) {
                tPath=tPathDeviateReturning;
                choTowards=choPointDeviateReturning;

                changeDirection();

                blnDeviate=false;
              }
              else {
//System.out.println("return5");
                intDeviateX=choPointDeviateReturning.intX;
                intDeviateY=choPointDeviateReturning.intY;

                blnDeviateReturning=true;
              }
            }
          }
          else {
            if(intLX>intTowardsX) {
              intLX=intTowardsX;
              intLY=intTowardsY;
              dblX=new Integer(intLX).doubleValue();
              dblY=new Integer(intLY).doubleValue();

//              intLX=intTowardsX;
//              dblX=new Integer(intLX).doubleValue();
//              intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);


              if(blnDeviateReturning) {
                tPath=tPathDeviateReturning;
                choTowards=choPointDeviateReturning;

                changeDirection();

                blnDeviate=false;
              }
              else {
//System.out.println("return6");
                intDeviateX=choPointDeviateReturning.intX;
                intDeviateY=choPointDeviateReturning.intY;

                blnDeviateReturning=true;
              }
            }
          }
        }
*/

        intX=intLX;
        intY=intLY;


        return;
      }

      double dblTowardsX=new Integer(choTowards.intX).doubleValue();
      double dblTowardsY=new Integer(choTowards.intY).doubleValue();

//System.out.println("x: "+dblX+", y: "+dblY);
//System.out.println("x: "+dblTowardsX+", y: "+dblTowardsY);

      double dblRun=dblTowardsX-dblX;

//      if(dblRun==0.0d)
//        dblRun+=0.000001d;

      double m=(dblTowardsY-dblY)/dblRun;

//System.out.println("slope: "+m);

//y2-y1=m(x2-x1)
//y2=m*x2-m*x1+y1



//d=Math.sqrt(Math.pow(dblX-x, 2.0d)+Math.pow(dblY-(m*x-m*dblX+dblY), 2.0d));
//d=Math.sqrt(Math.pow(dblX-x, 2.0d)+Math.pow(dblY-m*x+m*dblX-dblY, 2.0d));
//d^2=dblX^2-2*dblX*x+x^2 + dblY^2-m*dblY*x+m*dblX*dblY-dblY^2 - m*dblY*x+m^2*x^2-m^2*dblX*x+m*dblY*x + m*dblX*dblY-m^2*dblX*x-m*dblX*dblY - dblY^2+m*dblY*x-m*dblX*dblY+dblY^2
//d^2-dblX^2-dblY^2-m*dblX*dblY+dblY^2-m*dblX*dblY+m*dblX*dblY+dblY^2+m*dblX*dblY-dblY^2=[m^2 +1]*x^2 + [-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]*x 
//(d^2-dblX^2-dblY^2-m*dblX*dblY+dblY^2-m*dblX*dblY+m*dblX*dblY+dblY^2+m*dblX*dblY-dblY^2)/(m^2+1) = x^2 + [-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]/(m^2+1)*x
//Math.sqrt((d^2-dblX^2-dblY^2-m*dblX*dblY+dblY^2-m*dblX*dblY+m*dblX*dblY+dblY^2+m*dblX*dblY-dblY^2)/(m^2+1) + 1/4*([-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]/(m^2+1))^2) = x + 1/2*[-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]/(m^2+1)
//x=Math.sqrt((d^2-dblX^2-dblY^2-m*dblX*dblY+dblY^2-m*dblX*dblY+m*dblX*dblY+dblY^2+m*dblX*dblY-dblY^2)/(m^2+1) + 1/4*([-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]/(m^2+1))^2) - 1/2*[-2*dblX -m*dblY -m*dblY -m^2*dblX +m*dblY -m^2*dblX +m*dblY]/(m^2+1)
//x=Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d) + 1.0d/4.0d*([-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY]/(Math.pow(m, 2.0d)+1.0d))^2) - 1.0d/2.0d*[-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY]/(Math.pow(m, 2.0d)+1.0d)
//x=Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d) + 1.0d/4.0d*Math.pow([-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY]/(Math.pow(m, 2.0d)+1.0d), 2.0d)) - 1.0d/2.0d*[-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY]/(Math.pow(m, 2.0d)+1.0d)

//x=Math.sqrt( (Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(m*dblX, 2.0d))/(1.0d+Math.pow(m, 2.0d))+Math.pow(dblX, 2.0d) )+dblX

      double dblLX=dblTowardsX;
//System.out.println("dblLX: "+dblLX);

      if(!Double.isNaN(m) & !Double.isInfinite(m)) {
        if(choTowards.intX>intX) {
          dblLX=Math.sqrt( (Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(m*dblX, 2.0d))/(1.0d+Math.pow(m, 2.0d))+Math.pow(dblX, 2.0d) )+dblX;
//          dblLX=Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d)+1.0d/4.0d*Math.pow((-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d), 2.0d)) - 1.0d/2.0d*(-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d);
        }
        else {
          dblLX=-Math.sqrt( (Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(m*dblX, 2.0d))/(1.0d+Math.pow(m, 2.0d))+Math.pow(dblX, 2.0d) )+dblX;
//          dblLX=-Math.sqrt((Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)-m*dblX*dblY+m*dblX*dblY+Math.pow(dblY, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d))/(Math.pow(m, 2.0d)+1.0d)+1.0d/4.0d*Math.pow((-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d), 2.0d)) - 1.0d/2.0d*(-2.0d*dblX -m*dblY -m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY -Math.pow(m, 2.0d)*dblX +m*dblY)/(Math.pow(m, 2.0d)+1.0d);
        }
      }

//System.out.println("dblLX2: "+dblLX);

//System.out.println("LX: "+dblLX);
//System.exit(0);

/*
//d=Math.sqrt(Math.pow(dblX-x, 2.0d)+Math.pow(dblY-(m*x-m*dblX+dblY), 2.0d));
//Math.pow(d, 2.0d)=(dblX-x)*(dblX-x)+(dblY-(m*x-m*dblX+dblY))*(dblY-(m*x-m*dblX+dblY))
//Math.pow(d, 2.0d)=Math.pow(dblX, 2.0d)-dblX*x-dblX*x+Math.pow(x, 2.0d)+Math.pow(dblY, 2.0d)-dblY*(m*x-m*dblX+dblY)-dblY*(m*x-m*dblX+dblY)+Math.pow(m*x-m*dblX+dblY, 2.0d)

//z=Math.pow(m*x, 2.0d)-m*x*m*dblX+m*x*dblY-m*x*m*dblX+m*dblX*m*dblX-m*x*dblY+m*x*dblY-m*dblX*dblY+Math.pow(dblY, 2.0d)
//z=Math.pow(m*x, 2.0d)-2*x*dblX*Math.pow(m, 2.0d)+m*x*dblY+Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)

//z=Math.pow(m, 2.0d)*Math.pow(x, 2.0d)-2*dblX*Math.pow(m, 2.0d)*x+m*dblY*x+Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)
//z=Math.pow(m, 2.0d)*Math.pow(x, 2.0d)+(m*dblY-2*dblX*Math.pow(m, 2.0d))*x+Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)


//Math.pow(d, 2.0d)=Math.pow(dblX, 2.0d)-2*dblX*x+Math.pow(x, 2.0d)+Math.pow(dblY, 2.0d)-2*dblY*(m*x-m*dblX+dblY)+z
//Math.pow(d, 2.0d)=Math.pow(x, 2.0d)-2*dblX*x+Math.pow(dblX, 2.0d)+Math.pow(dblY, 2.0d)-2*dblY*(m*x-m*dblX+dblY)+z
//Math.pow(d, 2.0d)=Math.pow(x, 2.0d)-2*dblX*x+Math.pow(dblX, 2.0d)+Math.pow(dblY, 2.0d)-2*m*dblY*x+2*m*dblX*dblY-2*Math.pow(dblY, 2.0d)+z
//Math.pow(d, 2.0d)=Math.pow(x, 2.0d)-(2*dblX+2*m*dblY)*x+Math.pow(dblX, 2.0d)+Math.pow(dblY, 2.0d)+2*m*dblX*dblY-2*Math.pow(dblY, 2.0d)+z

//Math.pow(d, 2.0d)=(Math.pow(m, 2.0d)+1)*Math.pow(x, 2.0d)+(m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))*x+Math.pow(dblX, 2.0d)+Math.pow(dblY, 2.0d)+2*m*dblX*dblY-2*Math.pow(dblY, 2.0d)+Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)-m*dblX*dblY+Math.pow(dblY, 2.0d)
//Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)=(Math.pow(m, 2.0d)+1)*Math.pow(x, 2.0d)+(m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))*x
//(  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  )=Math.pow(x, 2.0d)+(  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  )*x

//b=(  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  )
//Math.pow(b/2, 2.0d)=1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)

//(  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)   =    Math.pow(x, 2.0d)+(  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  )*x  +  1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)
//(  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)   =    Math.pow(x+ (  ((m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY)))/(Math.pow(m, 2.0d)+1)  )/2, 2.0d)
//Math.sqrt(  (  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)  )  =  x + (  ((m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY)))/(Math.pow(m, 2.0d)+1)  )/2
//Math.sqrt(  (  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)  )  - (  ((m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY)))/(Math.pow(m, 2.0d)+1)  )/2 =  x
//x = Math.sqrt(  (  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2*m*dblX*dblY+2*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY))  )/(  Math.pow(m, 2.0d)+1)  ), 2.0d)  )  - (  ((m*dblY-2*dblX*Math.pow(m, 2.0d)-(2*dblX+2*m*dblY)))/(Math.pow(m, 2.0d)+1)  )/2
//x = Math.sqrt(  (  Math.pow(d, 2.0d)-Math.pow(dblX, 2.0d)-Math.pow(dblY, 2.0d)-2.0d*m*dblX*dblY+2.0d*Math.pow(dblY, 2.0d)-Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)+m*dblX*dblY-Math.pow(dblY, 2.0d)  )/(  Math.pow(m, 2.0d)+1.0d)  ) + 1.0d/4.0d*Math.pow( (  (m*dblY-2.0d*dblX*Math.pow(m, 2.0d)-(2.0d*dblX+2.0d*m*dblY))  )/(  Math.pow(m, 2.0d)+1.0d)  ), 2.0d)  )  - (  ((m*dblY-2.0d*dblX*Math.pow(m, 2.0d)-(2.0d*dblX+2.0d*m*dblY)))/(Math.pow(m, 2.0d)+1.0d)  )/2.0d
*/

/*
      double dblLX= Math.sqrt(
  (
Math.pow(d, 2.0d)
-
Math.pow(dblX, 2.0d)
-
Math.pow(dblY, 2.0d)
-
2.0d*m*dblX*dblY
+
2.0d*Math.pow(dblY, 2.0d)
-
Math.pow(m, 2.0d)*Math.pow(dblX, 2.0d)
+
m*dblX*dblY
-
Math.pow(dblY, 2.0d)
  )
/
  (
Math.pow(m, 2.0d)
+
1.0d
  )
)
+
1.0d/4.0d*Math.pow(
  (
    (
m*dblY-2.0d*dblX*Math.pow(m, 2.0d)-
      (
2.0d*dblX+2.0d*m*dblY
      )
    )
  )
/
  (
Math.pow(m, 2.0d)
+
1.0d
  )
, 2.0d)
-
(  ((m*dblY-2.0d*dblX*Math.pow(m, 2.0d)-(2.0d*dblX+2.0d*m*dblY)))/(Math.pow(m, 2.0d)+1.0d)  )/2.0d;
*/

       if(!Double.isNaN(m) & !Double.isInfinite(m)) {
         if(Double.isNaN(dblLX)) {
//System.out.println("change1");
           changeDirection();

           return;
         }
       }
       else {
         if(intY==choTowards.intY) {
           changeDirection();

           return;
         }
       }

//System.out.println("x:"+dblLX);

      double dblLY=dblY;

      if(!Double.isNaN(m) & !Double.isInfinite(m)) {
        dblLY=m*dblLX-m*dblX+dblY;
      }
      else {
        if(dblTowardsY>dblY)
          dblLY+=d;
        else
          dblLY-=d;
      }

//System.out.println("x1:"+dblX);
//System.out.println("x2:"+dblLX);

      dblX=dblLX;
      dblY=dblLY;

      int intLX=(int)Math.rint(dblX);
      int intLY=(int)Math.rint(dblY);

      int intTowardsX=choTowards.intX;
      int intTowardsY=choTowards.intY;


      double dblTowardsX2=new Integer(intTowardsX).doubleValue();
      double dblTowardsY2=new Integer(intTowardsY).doubleValue();

      double dblGap=Math.sqrt(Math.pow(dblTowardsX2-dblX, 2.0d)+Math.pow(dblTowardsY2-dblY, 2.0d));

      if(dblGap<=(d+1.1d)) {
        intX=intTowardsX;
        intY=intTowardsY;
        dblX=new Integer(intX).doubleValue();
        dblY=new Integer(intY).doubleValue();

        changeDirection();

        return;
      }








/*
      if(Double.isNaN(m) || Double.isInfinite(m)) {
        if(intY>intTowardsY) {
          if(intLY<intTowardsY) {
            intLY=intTowardsY;
            dblY=new Integer(intLY).doubleValue();
//            intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

//System.out.println("change2");

            changeDirection();
          }
        }
        else {
          if(intLY>intTowardsY) {
            intLY=intTowardsY;
            dblY=new Integer(intLY).doubleValue();
//            intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

//System.out.println("change3");

            changeDirection();
          }
        }
      }
      else {
        if(intX>intTowardsX) {
          if(intLX<intTowardsX) {
            intLX=intTowardsX;
            dblX=new Integer(intLX).doubleValue();
            intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

//System.out.println("change4");

            changeDirection();
          }
        }
        else {
          if(intLX>intTowardsX) {
            intLX=intTowardsX;
            dblX=new Integer(intLX).doubleValue();
            intLY=(int)Math.rint(m*dblLX-m*dblX+dblY);

//System.out.println("change5");

            changeDirection();
          }
        }
      }
*/

      intX=intLX;
      intY=intLY;

}

    }

    public void changeDirection() {
         if(blnNeverBacktrack) {
           Vector vecChoices=new Vector();

//System.out.println(choTowards.vecTravelPaths.size());

           for(int i=0;i<choTowards.vecTravelPaths.size();i++) {
             TravelPath travelPath=(TravelPath)choTowards.vecTravelPaths.elementAt(i);

             if(travelPath==tPath)
               continue;

             vecChoices.addElement(travelPath);
           }

           double dblRandom=Math.random()*new Integer(vecChoices.size()).doubleValue();

           dblRandom=Math.floor(dblRandom);

           int intRandom=(int)Math.rint(dblRandom);

           TravelPath newPath=(TravelPath)vecChoices.elementAt(intRandom);

           vecChoices.removeAllElements();

           for(int i=0;i<newPath.vecChoicePoints.size();i++) {
             ChoicePoint choPoint=(ChoicePoint)newPath.vecChoicePoints.elementAt(i);

             if(choPoint==choTowards)
               continue;

             vecChoices.addElement(choPoint);
           }

           dblRandom=Math.random()*new Integer(vecChoices.size()).doubleValue();

           dblRandom=Math.floor(dblRandom);

           intRandom=(int)Math.rint(dblRandom);

           ChoicePoint newPoint=(ChoicePoint)vecChoices.elementAt(intRandom);

           tPath=newPath;

           choTowards=newPoint;
         }
         else {
           double dblRandom=Math.random()*new Integer(choTowards.vecTravelPaths.size()).doubleValue();

           dblRandom=Math.floor(dblRandom);

           int intRandom=(int)Math.rint(dblRandom);

           TravelPath newPath=(TravelPath)choTowards.vecTravelPaths.elementAt(intRandom);

           Vector vecChoices=new Vector();

           for(int i=0;i<newPath.vecChoicePoints.size();i++) {
             ChoicePoint choPoint=(ChoicePoint)newPath.vecChoicePoints.elementAt(i);

             if(choPoint==choTowards)
               continue;

             vecChoices.addElement(choPoint);
           }

           dblRandom=Math.random()*new Integer(vecChoices.size()).doubleValue();

           dblRandom=Math.floor(dblRandom);

           intRandom=(int)Math.rint(dblRandom);

           ChoicePoint newPoint=(ChoicePoint)vecChoices.elementAt(intRandom);

           tPath=newPath;

           choTowards=newPoint;
         }
    }
  }

  class TravelPath {
    volatile double dblLine[]=new double[2];
    volatile Vector vecChoicePoints=new Vector();

    TravelPath(double dblSlope, double dblYIntercept, int intX1, int intY1, int intX2, int intY2) {
      this(dblSlope, dblYIntercept, intX1, intY1, intX2, intY2, true);
    }

    TravelPath(double dblSlope, double dblYIntercept, int intX1, int intY1, int intX2, int intY2, boolean blnAddEndPoints) {
      dblLine[0]=dblSlope;
      dblLine[1]=dblYIntercept;

      if(blnAddEndPoints) {
        ChoicePoint choPoint=new ChoicePoint(this, intX1, intY1);
        ChoicePoint choPoint2=new ChoicePoint(this, intX2, intY2);

        vecChoicePoints.addElement(choPoint);
        vecChoicePoints.addElement(choPoint2);
      }
    }

    public void connect(TravelPath tPath) {
      for(int i=0;i<vecChoicePoints.size();i++) {
        ChoicePoint choPoint=(ChoicePoint)vecChoicePoints.elementAt(i);

        int intX1=choPoint.intX;
        int intY1=choPoint.intY;

        for(int ia=0;ia<tPath.vecChoicePoints.size();ia++) {
          ChoicePoint choPoint2=(ChoicePoint)tPath.vecChoicePoints.elementAt(ia);

          int intX2=choPoint2.intX;
          int intY2=choPoint2.intY;

          if(intX1==intX2 & intY1==intY2) {
            choPoint.vecTravelPaths.addElement(tPath);

            tPath.vecChoicePoints.setElementAt(choPoint, ia);

            return;
          }          
        }
      }
    }
  }

  class ChoicePoint {
    volatile int intX=-1;
    volatile int intY=-1;
    volatile Vector vecTravelPaths=new Vector();

    ChoicePoint(TravelPath tPath, int intX, int intY) {
      this.intX=intX;
      this.intY=intY;

      vecTravelPaths.addElement(tPath);
    }
  }
}