package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.geom.AffineTransform;
import java.util.Vector;

class CompassTestFrame extends Frame {
  CompassCanvas cCanv=null;
//  CompassCanvas cCanv2=null;

  CompassKeyEventDispatcher keyEventDispatcher=new CompassKeyEventDispatcher();

  public static void main(String args[]) {
    Vector vecTravelPaths=CompassTestFrame.generateMap();

    CompassTestFrame cFrame=new CompassTestFrame(vecTravelPaths);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    cFrame.setSize(dimScreen.width, dimScreen.height-40);
    cFrame.setVisible(true);
  }

  public static Vector generateMap() {
    Vector vecTravelPaths=new Vector();

//    int intConnectorWidth=20;

    int intNumberOfPaths=20;

//    double dblNumberOfPaths=Math.random()*10.0d;
//    int intNumberOfPaths=(int)Math.rint(dblNumberOfPaths);

    int intPathWidths[]={20, 40, 80};
    double dblPathWidthsPercentages[]={1.0d, 0.9d, 1.0d};
//    double dblPathWidthsPercentages[]={0.7d, 0.9d, 1.0d};

    int intLastDirection=2; //0=north, 1=east, 2=south, 3=west

    CompassTestFrame.TravelPath tPath=new CompassTestFrame.TravelPath(100, 100, 20, 100);

    vecTravelPaths.addElement(tPath);

    int intLastTPX=100;
    int intLastTPY=100;
    int intLastTPWidth=20;
    int intLastTPHeight=100;



//    Vector vecDirections=new Vector();
//    vecDirections.addElement(new Integer(3));
//    vecDirections.addElement(new Integer(2));




//    for(int i=0;i<vecDirections.size();i++) {
    for(int i=0;i<intNumberOfPaths;i++) {
      double dblPathLength=Math.random()*25.0d+25.0d;
      int intPathLength=(int)Math.rint(dblPathLength);

      double dblPathWidthRandom=Math.random();

      int intPathWidth=-1;

      if(dblPathWidthRandom<dblPathWidthsPercentages[0]) {
        intPathWidth=intPathWidths[0];
      }
      else if(dblPathWidthRandom<dblPathWidthsPercentages[1]) {
        intPathWidth=intPathWidths[1];
      }
      else if(dblPathWidthRandom<dblPathWidthsPercentages[2]) {
        intPathWidth=intPathWidths[2];
      }

//      int intDirection=((Integer)vecDirections.elementAt(i)).intValue();

      double dblDirection=Math.random()*3.0d;
      dblDirection=Math.floor(dblDirection);
      int intDirection=new Double(dblDirection).intValue();

//      int intDirections[]=new int[3];

      if(intLastDirection==0) {
        if(intDirection==0) {
          intDirection=0;
        }
        else if(intDirection==1) {
          intDirection=1;
        }
        else if(intDirection==2) {
          intDirection=3;
        }
      }
      else if(intLastDirection==1) {
        if(intDirection==0) {
          intDirection=0;
        }
        else if(intDirection==1) {
          intDirection=1;
        }
        else if(intDirection==2) {
          intDirection=2;
        }
      }
      else if(intLastDirection==2) {
        if(intDirection==0) {
          intDirection=1;
        }
        else if(intDirection==1) {
          intDirection=2;
        }
        else if(intDirection==2) {
          intDirection=3;
        }
      }
      else if(intLastDirection==3) {
        if(intDirection==0) {
          intDirection=0;
        }
        else if(intDirection==1) {
          intDirection=2;
        }
        else if(intDirection==2) {
          intDirection=3;
        }
      }

      int intMidX=-1;
      int intMidY=-1;
      int intNextTPX=-1;
      int intNextTPY=-1;
      int intNextTPWidth=-1;
      int intNextTPHeight=-1;

      if(intDirection==0) {
        if(intLastDirection==0) {
          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intMidX-intPathWidth/2;
          intNextTPY=intLastTPY-intPathLength;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
        else if(intLastDirection==1) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX+intLastTPWidth;
          intNextTPY=intLastTPY+intLastTPHeight-intPathLength;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
        else if(intLastDirection==2) {
//
        }
        else if(intLastDirection==3) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX-intPathWidth;
          intNextTPY=intLastTPY+intLastTPHeight-intPathLength;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
      }
      else if(intDirection==1) {
        if(intLastDirection==0) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX;
          intNextTPY=intLastTPY-intPathWidth;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
        else if(intLastDirection==1) {
          intMidY=intLastTPY+intLastTPHeight/2;
          intNextTPX=intLastTPX+intLastTPWidth;
          intNextTPY=intMidY-intPathWidth/2;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
        else if(intLastDirection==2) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX;
          intNextTPY=intLastTPY+intLastTPHeight;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
        else if(intLastDirection==3) {
//
        }
      }
      else if(intDirection==2) {
        if(intLastDirection==0) {
//
        }
        else if(intLastDirection==1) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX+intLastTPWidth;
          intNextTPY=intLastTPY;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
        else if(intLastDirection==2) {
          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intMidX-intPathWidth/2;
          intNextTPY=intLastTPY+intLastTPHeight;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
        else if(intLastDirection==3) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX-intPathWidth;
          intNextTPY=intLastTPY;
          intNextTPWidth=intPathWidth;
          intNextTPHeight=intPathLength;
        }
      }
      else if(intDirection==3) {
        if(intLastDirection==0) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX+intLastTPWidth-intPathLength;
          intNextTPY=intLastTPY-intPathWidth;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
        else if(intLastDirection==1) {
//
        }
        else if(intLastDirection==2) {
//          intMidX=intLastTPX+intLastTPWidth/2;
          intNextTPX=intLastTPX+intLastTPWidth-intPathLength;
          intNextTPY=intLastTPY+intLastTPHeight;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
        else if(intLastDirection==3) {
          intMidY=intLastTPY+intLastTPHeight/2;
          intNextTPX=intLastTPX-intPathLength;
          intNextTPY=intMidY-intPathWidth/2;
          intNextTPWidth=intPathLength;
          intNextTPHeight=intPathWidth;
        }
      }

      CompassTestFrame.TravelPath tPath2=new CompassTestFrame.TravelPath(intNextTPX, intNextTPY, intNextTPWidth, intNextTPHeight);

      vecTravelPaths.addElement(tPath2);

      intLastTPX=intNextTPX;
      intLastTPY=intNextTPY;
      intLastTPWidth=intNextTPWidth;
      intLastTPHeight=intNextTPHeight;

      intLastDirection=intDirection;
    }

    return vecTravelPaths;
  }

  CompassTestFrame(Vector vecTravelPaths) {
    super("Compass Test Frame");

    cCanv=new CompassCanvas(vecTravelPaths);

    add("Center", cCanv);

    KeyboardFocusManager manager=KeyboardFocusManager.getCurrentKeyboardFocusManager();
    manager.addKeyEventDispatcher(keyEventDispatcher);


/*
    cCanv=new CompassCanvas(vecTravelPaths, 1.0d, 1.0d);
    cCanv2=new CompassCanvas(vecTravelPaths, 5.0d, 5.0d);

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new GridLayout(1, 2));
    pnlTemp.add(cCanv);
    pnlTemp.add(cCanv2);

    add("Center", pnlTemp);
*/
  }

  class CompassCanvas extends Canvas {
    Vector vecTravelPaths=new Vector();
    BufferedImage bufImage=null;

    int intX=0;
    int intY=0;

    double dblViewportPercentageX=0.1d;
    double dblViewportPercentageY=0.1d;

    double dblViewportPercentageX2=0.025d;
    double dblViewportPercentageY2=0.025d;

    CompassCanvas(Vector vecTravelPaths) {
      super();
      this.vecTravelPaths=vecTravelPaths;
    }

    public void paint(Graphics graph) {
      if(bufImage==null) {
        bufImage=new BufferedImage(getSize().width, getSize().height, BufferedImage.TYPE_INT_RGB);

        Graphics bufGraph=bufImage.getGraphics();

        bufGraph.setColor(Color.white);
        bufGraph.fillRect(0, 0, getSize().width, getSize().height);

        bufGraph.setColor(Color.black);

        for(int i=0;i<vecTravelPaths.size();i++) {
          CompassTestFrame.TravelPath tPath=(CompassTestFrame.TravelPath)vecTravelPaths.elementAt(i);

          bufGraph.fillRect(tPath.intX, tPath.intY, tPath.intWidth, tPath.intHeight);
        }
      }



      double dblViewportWidth=new Integer(getSize().width).doubleValue()*dblViewportPercentageX2;
      int intViewportWidth=(int)Math.rint(dblViewportWidth);
      double dblViewportHeight=new Integer(getSize().height).doubleValue()*dblViewportPercentageY2;
      int intViewportHeight=(int)Math.rint(dblViewportHeight);

      int intViewportX=intX-intViewportWidth/2;
      if(intViewportX<0)
        intViewportX=0;
      else if((intViewportX+intViewportWidth)>getSize().width)
        intViewportX=getSize().width-intViewportWidth;

      int intViewportY=intY-intViewportHeight/2;
      if(intViewportY<0)
        intViewportY=0;
      else if((intViewportY+intViewportHeight)>getSize().height)
        intViewportY=getSize().height-intViewportHeight;

      BufferedImage bufSub=bufImage.getSubimage(intViewportX, intViewportY, intViewportWidth, intViewportHeight);

      BufferedImage bufMain=getScaledImage(bufSub, bufSub.getWidth(), bufSub.getHeight(), getSize().width, getSize().height);



      dblViewportWidth=new Integer(getSize().width).doubleValue()*dblViewportPercentageX;
      intViewportWidth=(int)Math.rint(dblViewportWidth);
      dblViewportHeight=new Integer(getSize().height).doubleValue()*dblViewportPercentageY;
      intViewportHeight=(int)Math.rint(dblViewportHeight);

      intViewportX=intX-intViewportWidth/2;
      if(intViewportX<0)
        intViewportX=0;
      else if((intViewportX+intViewportWidth)>getSize().width)
        intViewportX=getSize().width-intViewportWidth;

      intViewportY=intY-intViewportHeight/2;
      if(intViewportY<0)
        intViewportY=0;
      else if((intViewportY+intViewportHeight)>getSize().height)
        intViewportY=getSize().height-intViewportHeight;

      bufSub=bufImage.getSubimage(intViewportX, intViewportY, intViewportWidth, intViewportHeight);

      BufferedImage bufCorner=getScaledImage(bufSub, bufSub.getWidth(), bufSub.getHeight(), (int)Math.rint(new Integer(getSize().width).doubleValue()*0.25d), (int)Math.rint(new Integer(getSize().height).doubleValue()*0.25d));


      graph.drawImage(bufMain, 0, 0, this);

      Color clr=graph.getColor();
      graph.setColor(Color.green);
      graph.fillRect(getSize().width-bufCorner.getWidth()-5, getSize().height-bufCorner.getHeight()-5, bufCorner.getWidth()+5, bufCorner.getHeight()+5);
      graph.setColor(clr);

      graph.drawImage(bufCorner, getSize().width-bufCorner.getWidth(), getSize().height-bufCorner.getHeight(), this);
    }

    public BufferedImage getScaledImage(BufferedImage bImage, int intOrigWidth, int intOrigHeight, int intScaledWidth, int intScaledHeight) {
      BufferedImage bufRet=new BufferedImage(intScaledWidth, intScaledHeight, BufferedImage.TYPE_INT_RGB);

      double dblScaleX=new Integer(intScaledWidth).doubleValue()/new Integer(intOrigWidth).doubleValue();
      double dblScaleY=new Integer(intScaledHeight).doubleValue()/new Integer(intOrigHeight).doubleValue();

      Graphics2D graph=(Graphics2D)bufRet.getGraphics();
      graph.scale(dblScaleX, dblScaleY);

      graph.drawImage(bImage, 0, 0, null);

      graph.dispose();

      return bufRet;
    }

  }

/*
  class CompassCanvas extends Canvas {
    Vector vecTravelPaths=new Vector();
    double dblScaleX=0.0d;
    double dblScaleY=0.0d;

    CompassCanvas(Vector vecTravelPaths, double dblScaleX, double dblScaleY) {
      super();
      this.vecTravelPaths=vecTravelPaths;
      this.dblScaleX=dblScaleX;
      this.dblScaleY=dblScaleY;
    }

    public void paint(Graphics graph) {
      AffineTransform aTransform=AffineTransform.getScaleInstance(dblScaleX, dblScaleY);

      ((Graphics2D)graph).transform(aTransform);

      for(int i=0;i<vecTravelPaths.size();i++) {
        CompassTestFrame.TravelPath tPath=(CompassTestFrame.TravelPath)vecTravelPaths.elementAt(i);

        graph.fillRect(tPath.intX, tPath.intY, tPath.intWidth, tPath.intHeight);
      }
    }
  }
*/

  class CompassKeyEventDispatcher
  implements KeyEventDispatcher {

    CompassKeyEventDispatcher() {
      super();
    }

    public boolean dispatchKeyEvent(KeyEvent e) {
      switch (e.getID()) {
        case KeyEvent.KEY_PRESSED:
          break;
        case KeyEvent.KEY_RELEASED:
          int intKeyCode=e.getKeyCode();

          int intTranslateVertical=0;
          int intTranslateHorizontal=0;

          if(intKeyCode==KeyEvent.VK_UP) {
            intTranslateVertical=-10;
          }
          else if(intKeyCode==KeyEvent.VK_DOWN) {
            intTranslateVertical=10;
          }
          else if(intKeyCode==KeyEvent.VK_LEFT) {
            intTranslateHorizontal=-10;
          }
          else if(intKeyCode==KeyEvent.VK_RIGHT) {
            intTranslateHorizontal=10;
          }

          cCanv.intX+=intTranslateHorizontal;
          cCanv.intY+=intTranslateVertical;

          if(cCanv.intX<0)
            cCanv.intX=0;
          else if(cCanv.intX>=cCanv.getSize().width)
            cCanv.intX=cCanv.getSize().width-1;

          if(cCanv.intY<0)
            cCanv.intY=0;
          else if(cCanv.intY>=cCanv.getSize().height)
            cCanv.intY=cCanv.getSize().height-1;

          cCanv.repaint();

          break;
        default:
          break;
      }

      return false;
    }
  }

  static class TravelPath {
    int intX=-1;
    int intY=-1;
    int intWidth=-1;
    int intHeight=-1;

    TravelPath(int intX, int intY, int intWidth, int intHeight) {
      this.intX=intX;
      this.intY=intY;
      this.intWidth=intWidth;
      this.intHeight=intHeight;
    }
  }
}