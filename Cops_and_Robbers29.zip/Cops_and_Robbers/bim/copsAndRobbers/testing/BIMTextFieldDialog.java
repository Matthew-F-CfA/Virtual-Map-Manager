package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;

class BIMTextFieldDialog extends Dialog
implements ActionListener {
  TextField txtTxt=new TextField(50);
  Button btnInput=new Button("Input");
  Button btnCancel=new Button("Cancel");

  String strText="";

  boolean cancelIt=false;


  BIMTextFieldDialog(Frame parent, String strTitle, String strText) {
    super(parent, strTitle, true);

    setLayout(new BorderLayout());

    Panel pnlTemp2=new Panel();
    pnlTemp2.add(new Label(strText));
    pnlTemp2.add(txtTxt);

    add("North", pnlTemp2);

    add("Center", new Label(""));

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnInput);
    btnInput.addActionListener(this);
    pnlTemp.add(btnCancel);
    btnCancel.addActionListener(this);

    add("South", pnlTemp);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(dimScreen.width/4, dimScreen.height/3);
    setSize(dimScreen.width/2, dimScreen.height/3);
  }

  public String getText() {
    return strText;
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnInput) {
      strText=txtTxt.getText();

      if(strText.length()==0)
        return;

      cancelIt=false;

      dispose();
    }
    else if(evSource==btnCancel) {
      cancelIt=true;

      dispose();
    }
  }
}