package bim.copsAndRobbers.testing;

  class MovementPath {
    volatile int intStartX=-1;
    volatile int intStartY=-1;
    volatile int intEndX=-1;
    volatile int intEndY=-1;

    volatile int intWidth=-1;
    volatile int intHeight=-1;

    MovementPath(int intStartX, int intStartY, int intEndX, int intEndY, int intWidth, int intHeight) {
      this.intStartX=intStartX;
      this.intStartY=intStartY;
      this.intEndX=intEndX;
      this.intEndY=intEndY;
      this.intWidth=intWidth;
      this.intHeight=intHeight;
    }

    public int getStartX() {
      return intStartX;
    }

    public void setStartX(int intStartX) {
      this.intStartX=intStartX;
    }

    public int getStartY() {
      return intStartY;
    }

    public void setStartY(int intStartY) {
      this.intStartY=intStartY;
    }

    public int getEndX() {
      return intEndX;
    }

    public void setEndX(int intEndX) {
      this.intEndX=intEndX;
    }

    public int getEndY() {
      return intEndY;
    }

    public void setEndY(int intEndY) {
      this.intEndY=intEndY;
    }

    public int getWidth() {
      return intWidth;
    }

    public void setWidth(int intWidth) {
      this.intWidth=intWidth;
    }

    public int getHeight() {
      return intHeight;
    }

    public void setHeight(int intHeight) {
      this.intHeight=intHeight;
    }

    public String toString() {
      return String.valueOf(intStartX)+", "+String.valueOf(intStartY)+" to "+String.valueOf(intEndX)+", "+String.valueOf(intEndY)+" W:"+String.valueOf(intWidth)+", H:"+String.valueOf(intHeight);
    }
  }