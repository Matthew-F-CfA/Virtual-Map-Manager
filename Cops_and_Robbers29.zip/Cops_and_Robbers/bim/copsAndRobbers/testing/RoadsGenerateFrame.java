package bim.copsAndRobbers.testing;

import java.awt.Toolkit;
import java.awt.Dimension;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map;
import java.util.Iterator;

class RoadsGenerateFrame {

  public static void main(String args[]) {
    if(args.length!=2) {
      System.out.println("Usage:");
      System.out.println("  java bim.copsAndRobbers.testing.RoadsGenerateFrame <number of intersections to remove from rectangle grid> <vehicles on grid>");

      return;
    }

    String strIntersectionRemoveCount=args[0];

    int intIntersectionRemoveCount=Integer.parseInt(strIntersectionRemoveCount);

    if(intIntersectionRemoveCount>50) {
      System.out.println("Intersection remove count can't exceed 50");

      return;
    }

    String strVehicleCount=args[1];

    int intVehicleCount=Integer.parseInt(strVehicleCount);

    RoadsFrame rFrame=new RoadsFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    rFrame.setSize(dimScreen.width, dimScreen.height-50);
    rFrame.setVisible(true);

    dimScreen=rFrame.mCanv.getSize();

    TreeMap hshIntersections=new TreeMap();
    TreeMap hshMajorIntersections=new TreeMap();

    double dblScreenWidth=new Integer(dimScreen.width).doubleValue();
    double dblScreenHeight=new Integer(dimScreen.height).doubleValue();

    int intWidthInterval=(dimScreen.width-40)/10;
    int intHeightInterval=(dimScreen.height-100)/10;

    int intNorthEdge=20;
    int intWestEdge=20;
    int intSouthEdge=intNorthEdge+9*intHeightInterval;
    int intEastEdge=intWestEdge+9*intWidthInterval;

    Vector vecIntersections=new Vector();


    double dblLatitudeStart=2.0d/69.0d;
    double dblLongitudeStart=2.0d/69.0d;

    double dblLatitudeInterval=1.0d/69.0d;
    double dblLongitudeInterval=1.0d/69.0d;
//    double dblLongitudeInterval=5.0d/54.6d;


//north

    double dblLatitudeIncrement=dblLatitudeStart;
    double dblLongitudeIncrement=dblLongitudeStart;

    for(int i=0;i<10;i++) {
      int intPointX=intWestEdge+i*intWidthInterval;
      int intPointY=intNorthEdge;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=new BIMIntersection(String.valueOf(intPointX)+", "+String.valueOf(intPointY), pointNext, dblLatitudeIncrement, dblLongitudeIncrement);

      dblLongitudeIncrement=dblLongitudeIncrement+dblLongitudeInterval;

      hshIntersections.put(pointNext, intersectionNext);
//      hshMajorIntersections.put(pointNext, intersectionNext);

      vecIntersections.addElement(intersectionNext);
    }

    for(int i=1;i<8;i++) {
      int intPointX=intWestEdge+i*intWidthInterval;
      int intPointY=intNorthEdge;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intWestEdge+(i+1)*intWidthInterval;
      intPointY=intNorthEdge;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 50.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 50.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 50.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 50.0d);

      intersectionNext2.addDestination(roadR);
    }


//south

    dblLatitudeIncrement=dblLatitudeStart+dblLatitudeInterval*9.0d;
    dblLongitudeIncrement=dblLongitudeStart;

    for(int i=0;i<10;i++) {
      int intPointX=intWestEdge+i*intWidthInterval;
      int intPointY=intSouthEdge;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=new BIMIntersection(String.valueOf(intPointX)+", "+String.valueOf(intPointY), pointNext, dblLatitudeIncrement, dblLongitudeIncrement);

      dblLongitudeIncrement=dblLongitudeIncrement+dblLongitudeInterval;      

      hshIntersections.put(pointNext, intersectionNext);
//      hshMajorIntersections.put(pointNext, intersectionNext);

      vecIntersections.addElement(intersectionNext);
    }

    for(int i=1;i<8;i++) {
      int intPointX=intWestEdge+i*intWidthInterval;
      int intPointY=intSouthEdge;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intWestEdge+(i+1)*intWidthInterval;
      intPointY=intSouthEdge;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 50.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 50.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 50.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 50.0d);

      intersectionNext2.addDestination(roadR);
    }


//west

    dblLatitudeIncrement=dblLatitudeStart;
    dblLongitudeIncrement=dblLongitudeStart;

    for(int i=0;i<10;i++) {
      int intPointX=intWestEdge;
      int intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=new BIMIntersection(String.valueOf(intPointX)+", "+String.valueOf(intPointY), pointNext, dblLatitudeIncrement, dblLongitudeIncrement);

      dblLatitudeIncrement=dblLatitudeIncrement+dblLatitudeInterval;

      hshIntersections.put(pointNext, intersectionNext);
//      hshMajorIntersections.put(pointNext, intersectionNext);

      vecIntersections.addElement(intersectionNext);
    }

    for(int i=1;i<8;i++) {
      int intPointX=intWestEdge;
      int intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intWestEdge;
      intPointY=intNorthEdge+(i+1)*intHeightInterval;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 50.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 50.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 50.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 50.0d);

      intersectionNext2.addDestination(roadR);
    }


//east

    dblLatitudeIncrement=dblLatitudeStart;
    dblLongitudeIncrement=dblLongitudeStart+dblLongitudeInterval*9.0d;

    for(int i=0;i<10;i++) {
      int intPointX=intEastEdge;
      int intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=new BIMIntersection(String.valueOf(intPointX)+", "+String.valueOf(intPointY), pointNext, dblLatitudeIncrement, dblLongitudeIncrement);

      dblLatitudeIncrement=dblLatitudeIncrement+dblLatitudeInterval;

      hshIntersections.put(pointNext, intersectionNext);
//      hshMajorIntersections.put(pointNext, intersectionNext);

      vecIntersections.addElement(intersectionNext);
    }

    for(int i=1;i<8;i++) {
      int intPointX=intEastEdge;
      int intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intEastEdge;
      intPointY=intNorthEdge+(i+1)*intHeightInterval;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 50.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 50.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 50.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 50.0d);

      intersectionNext2.addDestination(roadR);
    }


    BIMPoint pointNorthWest=new BIMPoint(intWestEdge, intNorthEdge);
    BIMIntersection intersectionNorthWest=(BIMIntersection)hshIntersections.get(pointNorthWest);

    BIMPoint pointNorthWestEast=new BIMPoint(intWestEdge+intWidthInterval, intNorthEdge);
    BIMIntersection intersectionNorthWestEast=(BIMIntersection)hshIntersections.get(pointNorthWestEast);

    BIMPoint pointNorthWestSouth=new BIMPoint(intWestEdge, intNorthEdge+intHeightInterval);
    BIMIntersection intersectionNorthWestSouth=(BIMIntersection)hshIntersections.get(pointNorthWestSouth);

    BIMRoad roadNWE=new BIMRoad(intersectionNorthWest, intersectionNorthWestEast, 50.0d);
//    BIMRoad roadNWE=new BIMRoad(intersectionNorthWest, intersectionNorthWestEast, 5.0d, 50.0d);
    intersectionNorthWest.addDestination(roadNWE);
    BIMRoad roadNWER=new BIMRoad(intersectionNorthWestEast, intersectionNorthWest, 50.0d);
//    BIMRoad roadNWER=new BIMRoad(intersectionNorthWestEast, intersectionNorthWest, 5.0d, 50.0d);
    intersectionNorthWestEast.addDestination(roadNWER);

    BIMRoad roadNWS=new BIMRoad(intersectionNorthWest, intersectionNorthWestSouth, 50.0d);
//    BIMRoad roadNWS=new BIMRoad(intersectionNorthWest, intersectionNorthWestSouth, 5.0d, 50.0d);
    intersectionNorthWest.addDestination(roadNWS);
    BIMRoad roadNWSR=new BIMRoad(intersectionNorthWestSouth, intersectionNorthWest, 50.0d);
//    BIMRoad roadNWSR=new BIMRoad(intersectionNorthWestSouth, intersectionNorthWest, 5.0d, 50.0d);
    intersectionNorthWestSouth.addDestination(roadNWSR);


    BIMPoint pointNorthEast=new BIMPoint(intEastEdge, intNorthEdge);
    BIMIntersection intersectionNorthEast=(BIMIntersection)hshIntersections.get(pointNorthEast);

    BIMPoint pointNorthEastWest=new BIMPoint(intEastEdge-intWidthInterval, intNorthEdge);
    BIMIntersection intersectionNorthEastWest=(BIMIntersection)hshIntersections.get(pointNorthEastWest);

    BIMPoint pointNorthEastSouth=new BIMPoint(intEastEdge, intNorthEdge+intHeightInterval);
    BIMIntersection intersectionNorthEastSouth=(BIMIntersection)hshIntersections.get(pointNorthEastSouth);

    BIMRoad roadNEW=new BIMRoad(intersectionNorthEast, intersectionNorthEastWest, 50.0d);
//    BIMRoad roadNEW=new BIMRoad(intersectionNorthEast, intersectionNorthEastWest, 5.0d, 50.0d);
    intersectionNorthEast.addDestination(roadNEW);
    BIMRoad roadNEWR=new BIMRoad(intersectionNorthEastWest, intersectionNorthEast, 50.0d);
//    BIMRoad roadNEWR=new BIMRoad(intersectionNorthEastWest, intersectionNorthEast, 5.0d, 50.0d);
    intersectionNorthEastWest.addDestination(roadNEWR);

    BIMRoad roadNES=new BIMRoad(intersectionNorthEast, intersectionNorthEastSouth, 50.0d);
//    BIMRoad roadNES=new BIMRoad(intersectionNorthEast, intersectionNorthEastSouth, 5.0d, 50.0d);
    intersectionNorthEast.addDestination(roadNES);
    BIMRoad roadNESR=new BIMRoad(intersectionNorthEastSouth, intersectionNorthEast, 50.0d);
//    BIMRoad roadNESR=new BIMRoad(intersectionNorthEastSouth, intersectionNorthEast, 5.0d, 50.0d);
    intersectionNorthEastSouth.addDestination(roadNESR);


    BIMPoint pointSouthWest=new BIMPoint(intWestEdge, intSouthEdge);
    BIMIntersection intersectionSouthWest=(BIMIntersection)hshIntersections.get(pointSouthWest);

    BIMPoint pointSouthWestEast=new BIMPoint(intWestEdge+intWidthInterval, intSouthEdge);
    BIMIntersection intersectionSouthWestEast=(BIMIntersection)hshIntersections.get(pointSouthWestEast);

    BIMPoint pointSouthWestNorth=new BIMPoint(intWestEdge, intSouthEdge-intHeightInterval);
    BIMIntersection intersectionSouthWestNorth=(BIMIntersection)hshIntersections.get(pointSouthWestNorth);

    BIMRoad roadSWE=new BIMRoad(intersectionSouthWest, intersectionSouthWestEast, 50.0d);
//    BIMRoad roadSWE=new BIMRoad(intersectionSouthWest, intersectionSouthWestEast, 5.0d, 50.0d);
    intersectionSouthWest.addDestination(roadSWE);
    BIMRoad roadSWER=new BIMRoad(intersectionSouthWestEast, intersectionSouthWest, 50.0d);
//    BIMRoad roadSWER=new BIMRoad(intersectionSouthWestEast, intersectionSouthWest, 5.0d, 50.0d);
    intersectionSouthWestEast.addDestination(roadSWER);

    BIMRoad roadSWN=new BIMRoad(intersectionSouthWest, intersectionSouthWestNorth, 50.0d);
//    BIMRoad roadSWN=new BIMRoad(intersectionSouthWest, intersectionSouthWestNorth, 5.0d, 50.0d);
    intersectionSouthWest.addDestination(roadSWN);
    BIMRoad roadSWNR=new BIMRoad(intersectionSouthWestNorth, intersectionSouthWest, 50.0d);
//    BIMRoad roadSWNR=new BIMRoad(intersectionSouthWestNorth, intersectionSouthWest, 5.0d, 50.0d);
    intersectionSouthWestNorth.addDestination(roadSWNR);


    BIMPoint pointSouthEast=new BIMPoint(intEastEdge, intSouthEdge);
    BIMIntersection intersectionSouthEast=(BIMIntersection)hshIntersections.get(pointSouthEast);

    BIMPoint pointSouthEastWest=new BIMPoint(intEastEdge-intWidthInterval, intSouthEdge);
    BIMIntersection intersectionSouthEastWest=(BIMIntersection)hshIntersections.get(pointSouthEastWest);

    BIMPoint pointSouthEastNorth=new BIMPoint(intEastEdge, intSouthEdge-intHeightInterval);
    BIMIntersection intersectionSouthEastNorth=(BIMIntersection)hshIntersections.get(pointSouthEastNorth);

    BIMRoad roadSEW=new BIMRoad(intersectionSouthEast, intersectionSouthEastWest, 50.0d);
//    BIMRoad roadSEW=new BIMRoad(intersectionSouthEast, intersectionSouthEastWest, 5.0d, 50.0d);
    intersectionSouthEast.addDestination(roadSEW);
    BIMRoad roadSEWR=new BIMRoad(intersectionSouthEastWest, intersectionSouthEast, 50.0d);
//    BIMRoad roadSEWR=new BIMRoad(intersectionSouthEastWest, intersectionSouthEast, 5.0d, 50.0d);
    intersectionSouthEastWest.addDestination(roadSEWR);

    BIMRoad roadSEN=new BIMRoad(intersectionSouthEast, intersectionSouthEastNorth, 50.0d);
//    BIMRoad roadSEN=new BIMRoad(intersectionSouthEast, intersectionSouthEastNorth, 5.0d, 50.0d);
    intersectionSouthEast.addDestination(roadSEN);
    BIMRoad roadSENR=new BIMRoad(intersectionSouthEastNorth, intersectionSouthEast, 50.0d);
//    BIMRoad roadSENR=new BIMRoad(intersectionSouthEastNorth, intersectionSouthEast, 5.0d, 50.0d);
    intersectionSouthEastNorth.addDestination(roadSENR);


    for(int i=1;i<9;i++) {
      dblLongitudeIncrement=dblLongitudeStart+dblLongitudeInterval*new Integer(i).doubleValue();

      int intPointX=intWestEdge+i*intWidthInterval;

      for(int ia=1;ia<9;ia++) {
        dblLatitudeIncrement=dblLatitudeStart+dblLatitudeInterval*new Integer(ia).doubleValue();

        int intPointY=intNorthEdge+ia*intHeightInterval;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=new BIMIntersection(String.valueOf(intPointX)+", "+String.valueOf(intPointY), pointNext, dblLatitudeIncrement, dblLongitudeIncrement);

        hshIntersections.put(pointNext, intersectionNext);
      }
    }



    for(int i=1;i<9;i++) {
      for(int ia=1;ia<9;ia++) {
        int intPointX=intWestEdge+i*intWidthInterval;
        int intPointY=intNorthEdge+ia*intHeightInterval;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


        intPointX=intWestEdge+(i-1)*intWidthInterval;
        intPointY=intNorthEdge+ia*intHeightInterval;

        BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


        intPointX=intWestEdge+i*intWidthInterval;
        intPointY=intNorthEdge+(ia-1)*intHeightInterval;

        BIMPoint pointNext3=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext3=(BIMIntersection)hshIntersections.get(pointNext3);


        BIMRoad roadL=new BIMRoad(intersectionNext, intersectionNext2, 20.0d);
//        BIMRoad roadL=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 20.0d);

        intersectionNext.addDestination(roadL);


        BIMRoad roadLR=new BIMRoad(intersectionNext2, intersectionNext, 20.0d);
//        BIMRoad roadLR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 20.0d);

        intersectionNext2.addDestination(roadLR);


        BIMRoad roadU=new BIMRoad(intersectionNext, intersectionNext3, 20.0d);
//        BIMRoad roadU=new BIMRoad(intersectionNext, intersectionNext3, 5.0d, 20.0d);

        intersectionNext.addDestination(roadU);


        BIMRoad roadUR=new BIMRoad(intersectionNext3, intersectionNext, 20.0d);
//        BIMRoad roadUR=new BIMRoad(intersectionNext3, intersectionNext, 5.0d, 20.0d);

        intersectionNext3.addDestination(roadUR);
      }
    }


//East column minus corners

    for(int i=1;i<9;i++) {
      int intPointX=intEastEdge;
      int intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intEastEdge-intWidthInterval;
//      intPointY=intNorthEdge+i*intHeightInterval;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 20.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 20.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 20.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 20.0d);

      intersectionNext2.addDestination(roadR);
    }


//South row minus corners

    for(int i=1;i<9;i++) {
      int intPointX=intWestEdge+i*intWidthInterval;
      int intPointY=intSouthEdge;

      BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);


      intPointX=intWestEdge+i*intWidthInterval;
      intPointY=intSouthEdge-intHeightInterval;

      BIMPoint pointNext2=new BIMPoint(intPointX, intPointY);

      BIMIntersection intersectionNext2=(BIMIntersection)hshIntersections.get(pointNext2);


      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 20.0d);
//      BIMRoad roadF=new BIMRoad(intersectionNext, intersectionNext2, 5.0d, 20.0d);

      intersectionNext.addDestination(roadF);


      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 20.0d);
//      BIMRoad roadR=new BIMRoad(intersectionNext2, intersectionNext, 5.0d, 20.0d);

      intersectionNext2.addDestination(roadR);
    }



    for(int i=0;i<intIntersectionRemoveCount;i++) {
      while(true) {
        double dblX=Math.floor(10.0d*Math.random());
        int intX=new Double(dblX).intValue();
        intX=intWestEdge+intX*intWidthInterval;

        double dblY=Math.floor(10.0d*Math.random());
        int intY=new Double(dblY).intValue();
        intY=intNorthEdge+intY*intHeightInterval;

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(new BIMPoint(intX, intY));

        if(intersectionNext==null)
          continue;

        hshIntersections.remove(new BIMPoint(intX, intY));

        Vector vecDestinations=intersectionNext.getDestinations();

        for(int ia=0;ia<vecDestinations.size();ia++) {
          BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(ia);

          BIMIntersection intersectionNext2=roadNext.getTo();

          Vector vecDestinations2=intersectionNext2.getDestinations();

          for(int iz=0;iz<vecDestinations2.size();iz++) {
            BIMRoad roadNext2=(BIMRoad)vecDestinations2.elementAt(iz);

            BIMIntersection intersectionNext3=roadNext2.getTo();

            if(intersectionNext.getPoint().getX()==intersectionNext3.getPoint().getX() & intersectionNext.getPoint().getY()==intersectionNext3.getPoint().getY()) {
              vecDestinations2.removeElementAt(iz);

              break;
            }
          }
        }

        break;
      }
    }
    
    rFrame.mCanv.hshIntersections=hshIntersections;

    TreeMap hshIntersectionsMilesView=new TreeMap();

    Iterator iterZ=hshIntersections.entrySet().iterator();
    while(iterZ.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iterZ.next();

      BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

      hshIntersectionsMilesView.put(new BIMPointDouble(intersectionNext.getLongitude(), intersectionNext.getLatitude()), intersectionNext);
    }

    rFrame.mCanv.hshIntersectionsMilesView=hshIntersectionsMilesView;

    rFrame.mCanv.repaint();

    try {
//north

      for(int i=0;i<10;i++) {
        int intPointX=intWestEdge+i*intWidthInterval;
        int intPointY=intNorthEdge;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);

        if(intersectionNext==null)
          continue;

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, intersectionNext);
      }

/*
//south

      for(int i=0;i<10;i++) {
        int intPointX=intWestEdge+i*intWidthInterval;
        int intPointY=intSouthEdge;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);

        if(intersectionNext==null)
          continue;

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, intersectionNext);
      }


//west

      for(int i=0;i<10;i++) {
        int intPointX=intWestEdge;
        int intPointY=intNorthEdge+i*intHeightInterval;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);

        if(intersectionNext==null)
          continue;

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, intersectionNext);
      }


//east

      for(int i=0;i<10;i++) {
        int intPointX=intEastEdge;
        int intPointY=intNorthEdge+i*intHeightInterval;

        BIMPoint pointNext=new BIMPoint(intPointX, intPointY);

        BIMIntersection intersectionNext=(BIMIntersection)hshIntersections.get(pointNext);

        if(intersectionNext==null)
          continue;

        BIMIntersection.connectMajorIntersection(hshIntersections, hshIntersectionsMilesView, hshMajorIntersections, intersectionNext);
      }
*/

    }
    catch(Exception ex) {
      ex.printStackTrace();

      System.exit(0);
    }

    rFrame.mCanv.hshMajorIntersections=hshMajorIntersections;

    rFrame.mCanv.repaint();

    rFrame.setInfo();


    Vector vecVehicleObjects=Vehicle.addVehiclesToMap(intVehicleCount, hshIntersections);

    for(int i=0;i<vecVehicleObjects.size();i++)
      rFrame.mCanv.vecVehicles.addElement(vecVehicleObjects.elementAt(i));

    rFrame.mCanv.repaint();
  }
}