package bim.copsAndRobbers.testing;

class PolarDistanceTest {

  public static void main(String args[]) {
    try {
      String strAngle=args[0];
      String strDistance=args[1];

      double dblRadians=Double.valueOf(strAngle).doubleValue();
      double dblDistance=Double.valueOf(strDistance).doubleValue();

      double dblUnit=Math.sqrt(Math.pow(dblDistance*Math.cos(dblRadians), 2.0d)+Math.pow(dblDistance*Math.sin(dblRadians), 2.0d));

      System.out.println(String.valueOf(dblUnit));
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}