package bim.copsAndRobbers.testing;

import java.util.Vector;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Map;

class Vehicle {
  static double SPOTTER_DISTANCE=5.0d;
  static int VEHICLE_TYPE_CIVILIAN=0;
  static int VEHICLE_TYPE_COP=1;
  static int VEHICLE_TYPE_ROBBER=2;

  static double VEHICLE_SPEED_CIVILIAN=1.0d;
  static double VEHICLE_SPEED_COP=1.5d;
  static double VEHICLE_SPEED_ROBBER=1.25d;

  Integer intVehicleType=new Integer(0);

  BIMRoad road=null;
//  BIMIntersection intersectionFrom=null;
//  BIMIntersection intersectionTo=null;

  Double dblRoadLocation=new Double(0.0d); //Distance from intersectionFrom

  Boolean blnSpotter=new Boolean(false);


  Vehicle(int intVehicleType0) {
    this.intVehicleType=new Integer(intVehicleType0);
  }

  public int getVehicleType() {
    return intVehicleType.intValue();
  }

  public void setVehicleType(int intVehicleType0) {
    this.intVehicleType=new Integer(intVehicleType0);
  }

  public BIMIntersection getIntersectionFrom() {
    return road.getFrom();
  }

  public BIMIntersection getIntersectionTo() {
    return road.getTo();
  }

  public BIMRoad getRoad() {
    return road;
  }

  public void setRoad(BIMRoad road) {
    this.road=road;
  }

  public double getRoadLocation() {
    return dblRoadLocation.doubleValue();
  }

  public void setRoadLocation(double dblRoadLocation0) {
    this.dblRoadLocation=new Double(dblRoadLocation0);
  }

  public boolean isSpotter() {
    return blnSpotter.booleanValue();
  }

  public void setIsSpotter(boolean blnSpotter0) {
    this.blnSpotter=new Boolean(blnSpotter0);
  }

  public boolean isSpotted() {
    double dblLocation=dblRoadLocation.doubleValue();

    Vector vecSpotter=road.getSpotters();

    for(int i=0;i<vecSpotter.size();i++) {
      Vehicle vehicleNext=(Vehicle)vecSpotter.elementAt(i);

      double dblLocationNext=vehicleNext.getRoadLocation();

      double dblDifference=dblLocationNext-dblLocation;

      dblDifference=Math.abs(dblDifference);

      if(dblDifference<Vehicle.SPOTTER_DISTANCE) {
        return true;
      }
    }

    return false;
  }

  public void travelTime(double dblHours) {
    double dblDistance=road.getLength();
//    double dblDistance=BIMIntersection.lengthFromHaversine(road.getFrom(), road.getTo());

    double dblDistanceRemaining=dblDistance-dblRoadLocation.doubleValue();

    double dblSpeedLimit=road.getSpeedLimit();

    double dblSpeed=0.0d;

    if(getVehicleType()==Vehicle.VEHICLE_TYPE_CIVILIAN) {
      dblSpeed=Vehicle.VEHICLE_SPEED_CIVILIAN*dblSpeedLimit;
    }
    else if(getVehicleType()==Vehicle.VEHICLE_TYPE_COP) {
      dblSpeed=Vehicle.VEHICLE_SPEED_COP*dblSpeedLimit;
    }
    else if(getVehicleType()==Vehicle.VEHICLE_TYPE_ROBBER) {
      dblSpeed=Vehicle.VEHICLE_SPEED_ROBBER*dblSpeedLimit;
    }

    double dblTime=dblDistanceRemaining/dblSpeed;

    if(dblTime<dblHours) {
//System.out.println("travel0");

      double dblHoursNew=dblHours-dblTime;

      Vector vecDestinations=road.getTo().getDestinations();

      if(vecDestinations.size()==1) {
        BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(0);

        if(isSpotter()) {
          road.removeSpotter(this);

          roadNext.addSpotter(this);
        }

        road=roadNext;
      }
      else {
        while(true) {
          double dblRandom=Math.random()*new Integer(vecDestinations.size()).doubleValue();

          dblRandom=Math.floor(dblRandom);

          int intRandom=new Double(dblRandom).intValue();

          BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(intRandom);

          BIMIntersection intersectionToNext=roadNext.getTo();

          if(intersectionToNext.getLongitude()==road.getFrom().getLongitude() & intersectionToNext.getLatitude()==road.getFrom().getLatitude())
            continue;

          if(isSpotter()) {
            road.removeSpotter(this);

            roadNext.addSpotter(this);
          }

          road=roadNext;

          break;
        }
      }

      setRoadLocation(0.0d);

      travelTime(dblHoursNew);
    }
    else if(dblTime==dblHours) {
//System.out.println("travel1");

      Vector vecDestinations=road.getTo().getDestinations();

      if(vecDestinations.size()==1) {
        BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(0);

        if(isSpotter()) {
          road.removeSpotter(this);

          roadNext.addSpotter(this);
        }

        road=roadNext;
      }
      else {
        while(true) {
          double dblRandom=Math.random()*new Integer(vecDestinations.size()).doubleValue();

          dblRandom=Math.floor(dblRandom);

          int intRandom=new Double(dblRandom).intValue();

          BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(intRandom);

          BIMIntersection intersectionToNext=roadNext.getTo();

          if(intersectionToNext.getLongitude()==road.getFrom().getLongitude() & intersectionToNext.getLatitude()==road.getFrom().getLatitude())
            continue;

          if(isSpotter()) {
            road.removeSpotter(this);

            roadNext.addSpotter(this);
          }

          road=roadNext;

          break;
        }
      }

      setRoadLocation(0.0d);
    }
    else {
//System.out.println("travel2:"+getRoadLocation());

      double dblDistanceTraveled=dblSpeed*dblHours;

      setRoadLocation(getRoadLocation()+dblDistanceTraveled);
    }
  }

  public static Vector addVehiclesToMap(int intVehicleCount, TreeMap hshIntersections) {
    Vector vecVehicle=new Vector();

    int intIntersectionCount=hshIntersections.size();
    double dblIntersectionCount=new Integer(intIntersectionCount).doubleValue();

    for(int i=0;i<intIntersectionCount;i++)
      vecVehicle.addElement(new Integer(0));

    for(int i=0;i<intVehicleCount;i++) {
      double dblNext=Math.random()*dblIntersectionCount;

      dblNext=Math.floor(dblNext);

      int intNext=new Double(dblNext).intValue();

      int intCount=((Integer)vecVehicle.elementAt(intNext)).intValue();

      ++intCount;

      vecVehicle.setElementAt(new Integer(intCount), intNext);
    }


    Vector vecVehicleObjects=new Vector();

    int intZZCount=0;

    Iterator iterZZ=hshIntersections.entrySet().iterator();

    Map.Entry mEntry=(Map.Entry)iterZZ.next();

    BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

    BIMIntersection intersectionFirst=intersectionNext;

    Vector vecDestinations=intersectionNext.getDestinations();

    int intVehicles=((Integer)vecVehicle.elementAt(intZZCount)).intValue();

    for(int i=0;i<intVehicles;i++) {
      double dblRandom=Math.random()*new Integer(vecDestinations.size()).doubleValue();

      dblRandom=Math.floor(dblRandom);

      int intRandom=new Double(dblRandom).intValue();

      BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(intRandom);

      Vehicle vehicleNext=new Vehicle(Vehicle.VEHICLE_TYPE_CIVILIAN);

      vehicleNext.setIsSpotter(true);

      roadNext.addSpotter(vehicleNext);

      vehicleNext.setRoad(roadNext);

      vecVehicleObjects.addElement(vehicleNext);
    }

    ++intZZCount;

    while(iterZZ.hasNext()) {
      mEntry=(Map.Entry)iterZZ.next();

      intersectionNext=(BIMIntersection)mEntry.getValue();

      vecDestinations=intersectionNext.getDestinations();

      intVehicles=((Integer)vecVehicle.elementAt(intZZCount)).intValue();

      for(int i=0;i<intVehicles;i++) {
        double dblRandom=Math.random()*new Integer(vecDestinations.size()).doubleValue();

        dblRandom=Math.floor(dblRandom);

        int intRandom=new Double(dblRandom).intValue();

        BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(intRandom);

        Vehicle vehicleNext=new Vehicle(Vehicle.VEHICLE_TYPE_CIVILIAN);

        vehicleNext.setIsSpotter(true);

        roadNext.addSpotter(vehicleNext);

        vehicleNext.setRoad(roadNext);

        vecVehicleObjects.addElement(vehicleNext);
      }

      ++intZZCount;
    }

/*
    Vehicle vehicleLast=new Vehicle(Vehicle.VEHICLE_TYPE_CIVILIAN);

    vehicleLast.setIsSpotter(false);

    vehicleLast.setRoad((BIMRoad)intersectionFirst.getDestinations().elementAt(0));

    vecVehicleObjects.addElement(vehicleLast);
*/

    return vecVehicleObjects;
  }

  public static void removeAllVehiclesFromMap(Vector vecVehicles) {
    int intVehicleCount=vecVehicles.size();

    for(int i=0;i<intVehicleCount;i++) {
      Vehicle vehicleNext=(Vehicle)vecVehicles.elementAt(0);

      vecVehicles.removeElementAt(0);

      if(vehicleNext.isSpotter()) {
        vehicleNext.road.removeSpotter(vehicleNext);
      }
    }    
  }
}