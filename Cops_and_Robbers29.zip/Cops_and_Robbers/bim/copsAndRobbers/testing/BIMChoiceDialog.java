package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;

class BIMChoiceDialog extends Dialog
implements ActionListener {
  Choice chcChoice=new Choice();
  Button btnChoose=new Button("Choose");
  Button btnCancel=new Button("Cancel");

  int intSelectedChoice=-1;

  BIMChoiceDialog(Frame parent, String strTitle, String strChoices[]) {
    super(parent, strTitle, true);

    for(int i=0;i<strChoices.length;i++)
      chcChoice.add(strChoices[i]);

    setLayout(new BorderLayout());

    add("North", chcChoice);

    add("Center", new Label(""));

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnChoose);
    btnChoose.addActionListener(this);
    pnlTemp.add(btnCancel);
    btnCancel.addActionListener(this);

    add("South", pnlTemp);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(dimScreen.width/3, dimScreen.height/3);
    setSize(dimScreen.width/3, dimScreen.height/3);
  }

  public int getSelectedChoice() {
    return intSelectedChoice;
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnChoose) {
      intSelectedChoice=chcChoice.getSelectedIndex();

      if(intSelectedChoice==-1)
        return;

      dispose();
    }
    else if(evSource==btnCancel) {
      intSelectedChoice=-1;

      dispose();
    }
  }
}