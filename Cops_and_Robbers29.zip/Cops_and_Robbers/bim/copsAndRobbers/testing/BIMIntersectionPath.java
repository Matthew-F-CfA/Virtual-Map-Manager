package bim.copsAndRobbers.testing;

import java.util.Vector;

class BIMIntersectionPath
implements Cloneable {
  BIMIntersection bimIntersectionTo=null;
  Vector vecRoads=new Vector();
  Double dblPathTime=new Double(0.0d);

  BIMIntersectionPath(BIMIntersection bimIntersectionTo, Vector vecRoads, double dblPathTime0) {
    this.bimIntersectionTo=bimIntersectionTo;
    this.vecRoads=vecRoads;
    this.dblPathTime=new Double(dblPathTime0);
  }

  public BIMIntersection getTo() {
    return bimIntersectionTo;
  }

  public void setTo(BIMIntersection bimIntersectionTo) {
    this.bimIntersectionTo=bimIntersectionTo;
  }

  public Vector getRoads() {
    return vecRoads;
  }

  public void setRoads(Vector vecRoads) {
    this.vecRoads=vecRoads;
  }

  public double getPathTime() {
    return dblPathTime.doubleValue();
  }

  public void setPathTime(double dblPathTime0) {
    this.dblPathTime=new Double(dblPathTime0);
  }

  public Object clone() {
    Vector vecRClone=new Vector();
    for(int i=0;i<vecRoads.size();i++) {
      BIMRoad roadNext=(BIMRoad)vecRoads.elementAt(i);

      vecRClone.addElement(roadNext);
//      vecRClone.addElement(roadNext.clone());
    }

    BIMIntersectionPath objClone=new BIMIntersectionPath((BIMIntersection)bimIntersectionTo.clone(), vecRClone, dblPathTime.doubleValue());

    return objClone;
  }
}