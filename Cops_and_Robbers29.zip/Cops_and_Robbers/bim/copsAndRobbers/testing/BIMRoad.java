package bim.copsAndRobbers.testing;

import java.util.Vector;

class BIMRoad
implements Comparable, Cloneable {
  BIMIntersection bimIntersectionFrom=null;
  BIMIntersection bimIntersectionTo=null;
  Double dblLength=new Double(0.0d);
  Double dblSpeedLimit=new Double(0.0d);
  Vector vecSpotter=new Vector();


  BIMRoad(BIMIntersection bimIntersectionFrom, BIMIntersection bimIntersectionTo, double dblSpeedLimit0) {
    this.bimIntersectionFrom=bimIntersectionFrom;
    this.bimIntersectionTo=bimIntersectionTo;
    this.dblLength=new Double(BIMIntersection.lengthFromHaversine(bimIntersectionFrom, bimIntersectionTo));
    this.dblSpeedLimit=new Double(dblSpeedLimit0);
  }

  public BIMIntersection getFrom() {
    return bimIntersectionFrom;
  }

  public BIMIntersection getTo() {
    return bimIntersectionTo;
  }

  public double getLength() {
    return dblLength.doubleValue();
  }

  public void setLength(double dblLength0) {
    this.dblLength=new Double(dblLength0);
  }

  public double getSpeedLimit() {
    return dblSpeedLimit.doubleValue();
  }

  public Vector getSpotters() {
    return vecSpotter;
  }

  public void setSpotters(Vector vecSpotter) {
    this.vecSpotter=vecSpotter;
  }

  public void addSpotter(Vehicle vehicle) {
    vecSpotter.addElement(vehicle);
  }

  public void removeSpotter(Vehicle vehicle) {
    for(int i=0;i<vecSpotter.size();i++) {
      Vehicle vehicleNext=(Vehicle)vecSpotter.elementAt(i);

      if(vehicleNext==vehicle) {
        vecSpotter.removeElementAt(i);

        return;
      }
    }
  }

  public int compareTo(Object obj) {
    BIMRoad objRoad=(BIMRoad)obj;

    BIMPoint pntStart=objRoad.getFrom().getPoint();
    BIMPoint pntEnd=objRoad.getTo().getPoint();

    BIMPoint pntStart2=getFrom().getPoint();
    BIMPoint pntEnd2=getTo().getPoint();

    int intReturn=0;

    if(pntStart.getY()<pntStart2.getY()) {
      intReturn=-1;
    }
    else if(pntStart.getY()==pntStart2.getY()) {
      if(pntStart.getX()<pntStart2.getX()) {
        intReturn=-1;
      }
      else if(pntStart.getX()==pntStart2.getX()) {
        double dblAngle=0.0d;

        if((pntEnd.getX()-pntStart.getX())==0.0d) {
          if(pntEnd.getY()>=pntStart.getY()) {
            dblAngle=Math.PI/2.0d;
          }
          else {
            dblAngle=Math.PI*3.0d/2.0d;
          }
        }
        else {
          dblAngle=Math.atan((pntEnd.getY()-pntStart.getY())/(pntEnd.getX()-pntStart.getX()));

          if(dblAngle<0.0d)
            dblAngle=-dblAngle;

          if(pntEnd.getX()>=pntStart.getX()) {
           if(pntEnd.getY()>=pntStart.getY()) {
//same
            }
            else {
//3rd
              dblAngle=Math.PI*2.0d-dblAngle;
            }
          }
          else {
            if(pntEnd.getY()>=pntStart.getY()) {
//1st
              dblAngle=Math.PI-dblAngle;
            }
            else {
//2nd
              dblAngle=Math.PI+dblAngle;
            }
          }
        }


        double dblAngle2=0.0d;

        if((pntEnd2.getX()-pntStart2.getX())==0.0d) {
          if(pntEnd2.getY()>=pntStart2.getY()) {
            dblAngle2=Math.PI/2.0d;
          }
          else {
            dblAngle2=Math.PI*3.0d/2.0d;
          }
        }
        else {
          dblAngle2=Math.atan((pntEnd2.getY()-pntStart2.getY())/(pntEnd2.getX()-pntStart2.getX()));

          if(dblAngle2<0.0d)
            dblAngle2=-dblAngle2;


          if(pntEnd2.getX()>=pntStart2.getX()) {
            if(pntEnd2.getY()>=pntStart2.getY()) {
//same
            }
            else {
              dblAngle2=Math.PI*2.0d-dblAngle2;
            }
          }
          else {
            if(pntEnd2.getY()>=pntStart2.getY()) {
              dblAngle2=Math.PI-dblAngle2;
            }
            else {
              dblAngle2=Math.PI+dblAngle2;
            }
          }
        }

        if(dblAngle<dblAngle2)
          intReturn=-1;
        else if(dblAngle==dblAngle2)
          intReturn=0;
        else
          intReturn=1;
      }
      else {
        intReturn=1;
      }
    }
    else {
      intReturn=1;
    }

    return intReturn;
  }

  public Object clone() {
    BIMRoad objClone=new BIMRoad((BIMIntersection)bimIntersectionFrom.clone(), (BIMIntersection)bimIntersectionTo.clone(), dblSpeedLimit.doubleValue());

    objClone.setLength(dblLength.doubleValue());

    for(int i=0;i<vecSpotter.size();i++)
      objClone.vecSpotter.addElement(vecSpotter.elementAt(i));

    return objClone;
  }
}