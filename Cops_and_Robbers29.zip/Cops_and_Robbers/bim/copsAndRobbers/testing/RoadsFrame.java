package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map;
import java.util.Iterator;
//import java.util.SortedMap;
import java.util.Arrays;
import java.util.Hashtable;

class RoadsFrame extends Frame
implements ActionListener, MouseListener, MouseMotionListener {
  MyCanvas mCanv=new MyCanvas();
  Button btnScrollWest=new Button("<");
  Button btnScrollEast=new Button(">");
  Button btnScrollNorth=new Button("^");
  Button btnScrollSouth=new Button("v");
  Button btnCalculateRoute=new Button("Calculate Route");
  Button btnAddTraffic=new Button("Add Traffic");
  Button btnRemoveTraffic=new Button("Remove Traffic");
  Button btnAddVehicles=new Button("Add Vehicles");
  Button btnRemoveAllVehicles=new Button("Remove All Vehicles");
  TextArea txtInfo=new TextArea(30, 30);

  Menu mnuView=new Menu("View");
  MenuItem mnuViewLogical=new MenuItem("Logical");
  MenuItem mnuViewReal=new MenuItem("Real");
  MenuItem mnuViewRealScale=new MenuItem("Real Scale Factor");


  public static void main(String args[]) {
    RoadsFrame rFrame=new RoadsFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    rFrame.setSize(dimScreen.width, dimScreen.height-50);
    rFrame.setVisible(true);

    rFrame.setInfo();
  }

  RoadsFrame() {
    super("Roads");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    Panel pnlTempZ=new Panel();
    pnlTempZ.setLayout(new BorderLayout());
    pnlTempZ.add("Center", mCanv);
    mCanv.addMouseListener(this);
    mCanv.addMouseMotionListener(this);
    pnlTempZ.add("West", btnScrollWest);
    btnScrollWest.addActionListener(this);
    pnlTempZ.add("East", btnScrollEast);
    btnScrollEast.addActionListener(this);
    pnlTempZ.add("North", btnScrollNorth);
    btnScrollNorth.addActionListener(this);
    pnlTempZ.add("South", btnScrollSouth);
    btnScrollSouth.addActionListener(this);

    add("Center", pnlTempZ);

    add("East", txtInfo);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnCalculateRoute);
    btnCalculateRoute.addActionListener(this);
    pnlTemp.add(btnAddTraffic);
    btnAddTraffic.addActionListener(this);
    pnlTemp.add(btnRemoveTraffic);
    btnRemoveTraffic.addActionListener(this);
    pnlTemp.add(btnAddVehicles);
    btnAddVehicles.addActionListener(this);
    pnlTemp.add(btnRemoveAllVehicles);
    btnRemoveAllVehicles.addActionListener(this);
    add("South", pnlTemp);


    MenuBar mBar=new MenuBar();

    mnuView.add(mnuViewLogical);
    mnuViewLogical.addActionListener(this);
    mnuView.add(mnuViewReal);
    mnuViewReal.addActionListener(this);
    mnuView.add(mnuViewRealScale);
    mnuViewRealScale.addActionListener(this);

    mBar.add(mnuView);

    setMenuBar(mBar);

    new VehiclesThread().start();
  }

  public void setInfo() {
    txtInfo.setText("");

    txtInfo.append("Initial Real Scale Factor:\n");
    txtInfo.append("0.00029");

    txtInfo.append("\n\n");

    txtInfo.append("Miles Per Latitude/Longitude:\n");
    txtInfo.append("69 Miles");

    txtInfo.append("\n\n");

    txtInfo.append("Logical Relative X: "+String.valueOf(mCanv.intRelativeX));
    txtInfo.append("\n");
    txtInfo.append("Logical Relative Y: "+String.valueOf(mCanv.intRelativeY));
    txtInfo.append("\n\n");

    txtInfo.append("Longitude Relative X: "+String.valueOf(mCanv.dblRelativeX));
    txtInfo.append("\n");
    txtInfo.append("Latitude Relative Y: "+String.valueOf(mCanv.dblRelativeY));
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnScrollWest) {
      if(mCanv.blnMilesView) {
        double dblNewX=mCanv.dblRelativeX-1.0d/69.0d;

        if(dblNewX<0.0d)
          dblNewX=0.0d;

        mCanv.dblRelativeX=dblNewX;
      }
      else {
        int intNewX=mCanv.intRelativeX-100;

        if(intNewX<0)
          intNewX=0;

        mCanv.intRelativeX=intNewX;
      }

      setInfo();

      mCanv.repaint();
    }
    else if(evSource==btnScrollEast) {
      if(mCanv.blnMilesView) {
        double dblNewX=mCanv.dblRelativeX+1.0d/69.0d;

        if(dblNewX>90.0d)
          dblNewX=90.0d;

        mCanv.dblRelativeX=dblNewX;
      }
      else {
        int intNewX=mCanv.intRelativeX+100;

//        if(intNewX<0)
//          intNewX=0;

        mCanv.intRelativeX=intNewX;
      }

      setInfo();

      mCanv.repaint();
    }
    else if(evSource==btnScrollNorth) {
      if(mCanv.blnMilesView) {
        double dblNewY=mCanv.dblRelativeY-1.0d/69.0d;

        if(dblNewY<0.0d)
          dblNewY=0.0d;

        mCanv.dblRelativeY=dblNewY;
      }
      else {
        int intNewY=mCanv.intRelativeY-100;

        if(intNewY<0)
          intNewY=0;

        mCanv.intRelativeY=intNewY;
      }

      setInfo();

      mCanv.repaint();
    }
    else if(evSource==btnScrollSouth) {
      if(mCanv.blnMilesView) {
        double dblNewY=mCanv.dblRelativeY+1.0d/69.0d;

        if(dblNewY>90.0d)
          dblNewY=90.0d;

        mCanv.dblRelativeY=dblNewY;
      }
      else {
        int intNewY=mCanv.intRelativeY+100;

//        if(intNewY<0)
//          intNewY=0;

        mCanv.intRelativeY=intNewY;
      }

      setInfo();

      mCanv.repaint();
    }
    else if(evSource==mnuViewLogical) {
      mCanv.blnMilesView=false;

      mCanv.repaint();
    }
    else if(evSource==mnuViewReal) {
      mCanv.blnMilesView=true;

synchronized(mCanv.objSyncSelectedIntersection) {
      if(mCanv.bimIntersectionSelected!=null)
        mCanv.intersectionSelectedDestination=new BIMIntersection(mCanv.dblRelativeY, mCanv.dblRelativeX);
}

synchronized(mCanv.objSyncCalculateRoute) {
      if(mCanv.bimIntersectionCalculateRoute!=null)
        mCanv.intersectionCalculateRouteDestination=new BIMIntersection(mCanv.dblRelativeY, mCanv.dblRelativeX);
}

      mCanv.repaint();
    }
    else if(evSource==mnuViewRealScale) {
      BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Real Scale Factor", "Real Scale Factor:");
      bTFDialog.show();

      if(bTFDialog.cancelIt)
        return;

      String strFactor=bTFDialog.getText();

      double dblFactor=Double.valueOf(strFactor).doubleValue();

      mCanv.dblMilesViewScale=dblFactor;

      mCanv.repaint();
    }
    else if(evSource==btnAddTraffic) {
      String strChoices[]=new String[mCanv.hshIntersections.size()];

      Iterator iter=mCanv.hshIntersections.entrySet().iterator();

      int intCount=0;

      Hashtable hshIntersections=new Hashtable();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        strChoices[intCount]=intersectionNext.getName();

        hshIntersections.put(strChoices[intCount], intersectionNext);

        ++intCount;
      }

      Arrays.sort(strChoices);

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Add Traffic Dialog: From Intersection", strChoices);
      bDialog.show();

      int intSelectedIndex=bDialog.getSelectedChoice();

      if(intSelectedIndex==-1)
        return;

      BIMIntersection intersectionChosen=(BIMIntersection)hshIntersections.get(strChoices[intSelectedIndex]);

      Vector vecDestinations=intersectionChosen.getDestinations();

      strChoices=new String[vecDestinations.size()];

      for(int i=0;i<vecDestinations.size();i++) {
        BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

        BIMIntersection toNext=roadNext.getTo();

        strChoices[i]=toNext.getName();
      }


      bDialog=new BIMChoiceDialog(this, "Add Traffic Dialog: To Intersection", strChoices);
      bDialog.show();

      intSelectedIndex=bDialog.getSelectedChoice();

      if(intSelectedIndex==-1)
        return;

      BIMRoad roadChosen=(BIMRoad)vecDestinations.elementAt(intSelectedIndex);


      BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Add Traffic Dialog: Traffic Speed", "Traffic Speed in MPH:");
      bTFDialog.show();

      String strSpeed=bTFDialog.getText();

      try {
        double dblSpeed=Double.valueOf(strSpeed).doubleValue();

        if(dblSpeed<=0.0d)
          return;

        BIMIntersection.hshTraffic.put(roadChosen, new Double(dblSpeed));
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnRemoveTraffic) {
      String strChoices[]=new String[BIMIntersection.hshTraffic.size()];

      BIMRoad roadChoices[]=new BIMRoad[strChoices.length];

      Iterator iter=BIMIntersection.hshTraffic.entrySet().iterator();

      int intCount=0;

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMRoad roadNext=(BIMRoad)mEntry.getKey();

        strChoices[intCount]="\""+roadNext.getFrom().getName()+"\" to \""+roadNext.getTo().getName()+"\"";

        roadChoices[intCount]=roadNext;

        ++intCount;
      }

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Remove Traffic Dialog: Road Choice", strChoices);
      bDialog.show();

      int intSelectedIndex=bDialog.getSelectedChoice();

      if(intSelectedIndex==-1)
        return;

      BIMIntersection.hshTraffic.remove(roadChoices[intSelectedIndex]);
    }
    else if(evSource==btnAddVehicles) {
      BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Add Vehicles Dialog", "Number of vehicles:");
      bTFDialog.show();

      if(bTFDialog.cancelIt)
        return;

      String strVehicleCount=bTFDialog.getText();

      int intVehicleCount=-1;
      try {
        intVehicleCount=Integer.parseInt(strVehicleCount);
      }
      catch(Exception ex) {
        return;
      }

synchronized(mCanv.syncVehicles) {
      Vehicle.removeAllVehiclesFromMap(mCanv.vecVehicles);

      Vector vecVehicleObjects=Vehicle.addVehiclesToMap(intVehicleCount, mCanv.hshIntersections);

      for(int i=0;i<vecVehicleObjects.size();i++)
        mCanv.vecVehicles.addElement(vecVehicleObjects.elementAt(i));

      mCanv.repaint();
}

    }
    else if(evSource==btnRemoveAllVehicles) {
synchronized(mCanv.syncVehicles) {
      Vehicle.removeAllVehiclesFromMap(mCanv.vecVehicles);

      mCanv.repaint();
}
    }
    else if(evSource==btnCalculateRoute) {
      Hashtable hshIntersections=new Hashtable();

      String strIntersectionNames[]=new String[mCanv.hshIntersections.size()];

      int intCount=0;

      Iterator iter=mCanv.hshIntersections.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

        strIntersectionNames[intCount]=intersectionNext.getName();

        hshIntersections.put(strIntersectionNames[intCount], intersectionNext);

        ++intCount;
      }

      Arrays.sort(strIntersectionNames);

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Calculate Directions: Intersection From", strIntersectionNames);
      bDialog.show();

      int intSelectedChoice=bDialog.getSelectedChoice();

      if(intSelectedChoice==-1)
        return;

      String strFrom=strIntersectionNames[intSelectedChoice];


      bDialog=new BIMChoiceDialog(this, "Calculate Directions: Intersection To", strIntersectionNames);
      bDialog.show();

      intSelectedChoice=bDialog.getSelectedChoice();

      if(intSelectedChoice==-1)
        return;

      String strTo=strIntersectionNames[intSelectedChoice];

      if(strFrom.equals(strTo)) {
        BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Calculate Directions", "Destination intersection is the same as starting intersections.");
        bLDialog.show();

        return;
      }

      BIMIntersection intersectionFrom=(BIMIntersection)hshIntersections.get(strFrom);

      BIMIntersection intersectionTo=(BIMIntersection)hshIntersections.get(strTo);

      calculateRoute(intersectionFrom, intersectionTo);
    }
  }

  public void calculateRoute(BIMIntersection intersectionFrom, BIMIntersection intersectionTo) {
    BIMDouble dblReturnFastestTime=new BIMDouble(-1.0d);

    try {
      String strRoads[]=BIMIntersection.findFastestPathStrings(mCanv.hshMajorIntersections, intersectionFrom, intersectionTo, dblReturnFastestTime);

      String strDisplay[]=new String[strRoads.length+1];

      strDisplay[0]="Total Time in Hours: "+String.valueOf(dblReturnFastestTime.getDouble());

      for(int i=0;i<strRoads.length;i++)
        strDisplay[i+1]=strRoads[i];

      BIMTextAreaDialog bTDialog=new BIMTextAreaDialog(this, "Directions from \""+intersectionFrom.getName()+"\" to \""+intersectionTo.getName()+"\"", strDisplay);
      bTDialog.show();
    }
    catch(Exception ex) {
      BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Calculate Directions", ex.toString());
      bLDialog.show();
    }
  }

  public void mouseMoved(MouseEvent me) {
synchronized(mCanv.objSyncSelectedIntersection) {
    if(mCanv.bimIntersectionSelected!=null) {
      if(mCanv.blnMilesView) {
        int intMeX=me.getX();
        int intMeY=me.getY();

        double dblLongitudeX=new Integer(intMeX).doubleValue()*mCanv.dblMilesViewScale;
        double dblLatitudeY=new Integer(intMeY).doubleValue()*mCanv.dblMilesViewScale;

        dblLongitudeX=dblLongitudeX+mCanv.dblRelativeX;
        dblLatitudeY=dblLatitudeY+mCanv.dblRelativeY;

        mCanv.intersectionSelectedDestination=new BIMIntersection(dblLatitudeY, dblLongitudeX);

        mCanv.repaint();
      }
    }
}

synchronized(mCanv.objSyncCalculateRoute) {
    if(mCanv.bimIntersectionCalculateRoute!=null) {
      if(mCanv.blnMilesView) {
        int intMeX=me.getX();
        int intMeY=me.getY();

//System.out.println(String.valueOf(intMeX)+", "+String.valueOf(intMeY));

        double dblLongitudeX=new Integer(intMeX).doubleValue()*mCanv.dblMilesViewScale;
        double dblLatitudeY=new Integer(intMeY).doubleValue()*mCanv.dblMilesViewScale;

        dblLongitudeX=dblLongitudeX+mCanv.dblRelativeX;
        dblLatitudeY=dblLatitudeY+mCanv.dblRelativeY;

        mCanv.intersectionCalculateRouteDestination=new BIMIntersection(dblLatitudeY, dblLongitudeX);

        mCanv.repaint();
      }
    }
}
  }

  public void mouseDragged(MouseEvent me) {
  }

  public void mouseEntered(MouseEvent me) {
  }

  public void mouseExited(MouseEvent me) {
  }

  public void mousePressed(MouseEvent me) {
  }

  public void mouseReleased(MouseEvent me) {
  }

  public void mouseClicked(MouseEvent me) {
    int intLogicalX=-1;
    int intLogicalY=-1;

    double dblLongitudeX=-1.0d;
    double dblLatitudeY=-1.0d;

    int intMeX=-1;
    int intMeY=-1;

    if(mCanv.blnMilesView) {
      intMeX=me.getX();
      intMeY=me.getY();

      dblLongitudeX=new Integer(intMeX).doubleValue()*mCanv.dblMilesViewScale;
      dblLatitudeY=new Integer(intMeY).doubleValue()*mCanv.dblMilesViewScale;

      dblLongitudeX=dblLongitudeX+mCanv.dblRelativeX;
      dblLatitudeY=dblLatitudeY+mCanv.dblRelativeY;
    }
    else {
      intMeX=me.getX()+mCanv.intRelativeX;
      intMeY=me.getY()+mCanv.intRelativeY;

      intLogicalX=intMeX;
      intLogicalY=intMeY;
    }

    if(me.getButton()!=MouseEvent.BUTTON1) {
      Vector vecIntersections=new Vector();

      if(mCanv.blnMilesView) {
        double dblLongitudeLeftUpperX=new Integer(intMeX-30).doubleValue()*mCanv.dblMilesViewScale;
        dblLongitudeLeftUpperX=dblLongitudeLeftUpperX+mCanv.dblRelativeX;
        double dblLatitudeLeftUpperY=new Integer(intMeY-30).doubleValue()*mCanv.dblMilesViewScale;
        dblLatitudeLeftUpperY=dblLatitudeLeftUpperY+mCanv.dblRelativeY;

        double dblLongitudeRightLowerX=new Integer(intMeX+30).doubleValue()*mCanv.dblMilesViewScale;
        dblLongitudeRightLowerX=dblLongitudeRightLowerX+mCanv.dblRelativeX;
        double dblLatitudeRightLowerY=new Integer(intMeY+30).doubleValue()*mCanv.dblMilesViewScale;
        dblLatitudeRightLowerY=dblLatitudeRightLowerY+mCanv.dblRelativeY;

        Iterator iter=mCanv.hshIntersectionsMilesView.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();

          BIMPointDouble pntDNext=(BIMPointDouble)mEntry.getKey();

          if(pntDNext.getX()>dblLongitudeLeftUpperX & pntDNext.getX()<dblLongitudeRightLowerX) {
            if(pntDNext.getY()>dblLatitudeLeftUpperY & pntDNext.getY()<dblLatitudeRightLowerY) {
              vecIntersections.addElement(mEntry.getValue());
            }
          }
        }
      }
      else {
        int intLeftUpperX=intMeX-30;
//        intLeftUpperX=intLeftUpperX+mCanv.intRelativeX;
        int intLeftUpperY=intMeY-30;
//        intLeftUpperY=intLeftUpperY+mCanv.intRelativeY;

        int intRightLowerX=intMeX+30;
//        intRightLowerX=intRightLowerX+mCanv.intRelativeX;
        int intRightLowerY=intMeY+30;
//        intRightLowerY=intRightLowerY+mCanv.intRelativeY;

        for(int i=intLeftUpperX;i<=intRightLowerX;i++) {
          for(int ia=intLeftUpperY;ia<=intRightLowerY;ia++) {
            Object objNext=mCanv.hshIntersections.get(new BIMPoint(i, ia));

            if(objNext!=null)
              vecIntersections.addElement(objNext);
          }
        }
      }

      String strChoices[]=new String[vecIntersections.size()+1];

      strChoices[0]="Cancel Calculate Route";

      for(int i=0;i<vecIntersections.size();i++) {
        BIMIntersection intersectionNext=(BIMIntersection)vecIntersections.elementAt(i);

        strChoices[i+1]=String.valueOf(intersectionNext.getPoint().getX())+", "+String.valueOf(intersectionNext.getPoint().getY());
      }


synchronized(mCanv.objSyncCalculateRoute) {
      if(mCanv.bimIntersectionCalculateRoute!=null) {
        BIMChoiceDialog bDialogZ=new BIMChoiceDialog(this, "Calculate Route Choice: Intersection To", strChoices);
        bDialogZ.show();

        int intSelectedChoiceZ=bDialogZ.getSelectedChoice();

        if(intSelectedChoiceZ==-1)
          return;

        if(intSelectedChoiceZ==0) {
          mCanv.bimIntersectionCalculateRoute=null;

          mCanv.repaint();

          return;
        }
        else {
          BIMIntersection intersectionTo=(BIMIntersection)vecIntersections.elementAt(intSelectedChoiceZ-1);

          if(intersectionTo.getPoint().getX()==mCanv.bimIntersectionCalculateRoute.getPoint().getX() & intersectionTo.getPoint().getY()==mCanv.bimIntersectionCalculateRoute.getPoint().getY())
            return;

          calculateRoute(mCanv.bimIntersectionCalculateRoute, intersectionTo);
        }

        mCanv.bimIntersectionCalculateRoute=null;

        mCanv.repaint();

        return;
      }
}

      BIMChoiceDialog bDialogZ=new BIMChoiceDialog(this, "Calculate Route Choice: Intersection From", strChoices);
      bDialogZ.show();

      int intSelectedChoiceZ=bDialogZ.getSelectedChoice();

      if(intSelectedChoiceZ==-1)
        return;

      if(intSelectedChoiceZ==0) {
//        mCanv.bimIntersectionCalculateRoute=null;

        return;
      }
      else {
        mCanv.bimIntersectionCalculateRoute=(BIMIntersection)vecIntersections.elementAt(intSelectedChoiceZ-1);

        mCanv.intersectionCalculateRouteDestination=new BIMIntersection(mCanv.bimIntersectionCalculateRoute.getLatitude(), mCanv.bimIntersectionCalculateRoute.getLongitude());

        mCanv.repaint();
      }

      return;      
    }

synchronized(mCanv.objSyncSelectedIntersection) {
    if(mCanv.bimIntersectionSelected!=null) {
      Vector vecIntersections=new Vector();

      if(mCanv.blnMilesView) {
        double dblLongitudeLeftUpperX=new Integer(intMeX-30).doubleValue()*mCanv.dblMilesViewScale;
        dblLongitudeLeftUpperX=dblLongitudeLeftUpperX+mCanv.dblRelativeX;
        double dblLatitudeLeftUpperY=new Integer(intMeY-30).doubleValue()*mCanv.dblMilesViewScale;
        dblLatitudeLeftUpperY=dblLatitudeLeftUpperY+mCanv.dblRelativeY;

        double dblLongitudeRightLowerX=new Integer(intMeX+30).doubleValue()*mCanv.dblMilesViewScale;
        dblLongitudeRightLowerX=dblLongitudeRightLowerX+mCanv.dblRelativeX;
        double dblLatitudeRightLowerY=new Integer(intMeY+30).doubleValue()*mCanv.dblMilesViewScale;
        dblLatitudeRightLowerY=dblLatitudeRightLowerY+mCanv.dblRelativeY;

        Iterator iter=mCanv.hshIntersectionsMilesView.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();

          BIMPointDouble pntDNext=(BIMPointDouble)mEntry.getKey();

          if(pntDNext.getX()>dblLongitudeLeftUpperX & pntDNext.getX()<dblLongitudeRightLowerX) {
            if(pntDNext.getY()>dblLatitudeLeftUpperY & pntDNext.getY()<dblLatitudeRightLowerY) {
              vecIntersections.addElement(mEntry.getValue());
            }
          }
        }
      }
      else {
        int intLeftUpperX=intMeX-30;
//        intLeftUpperX=intLeftUpperX+mCanv.intRelativeX;
        int intLeftUpperY=intMeY-30;
//        intLeftUpperY=intLeftUpperY+mCanv.intRelativeY;

        int intRightLowerX=intMeX+30;
//        intRightLowerX=intRightLowerX+mCanv.intRelativeX;
        int intRightLowerY=intMeY+30;
//        intRightLowerY=intRightLowerY+mCanv.intRelativeY;

        for(int i=intLeftUpperX;i<=intRightLowerX;i++) {
          for(int ia=intLeftUpperY;ia<=intRightLowerY;ia++) {
            Object objNext=mCanv.hshIntersections.get(new BIMPoint(i, ia));

            if(objNext!=null)
              vecIntersections.addElement(objNext);
          }
        }
      }

//      SortedMap sMap=mCanv.hshIntersections.subMap(new BIMPoint(intLeftUpperX, intLeftUpperY), new BIMPoint(intRightLowerX, intRightLowerY));

      String strChoices2[]=new String[0];

      int intInsertIndex=0;

      boolean blnExactIntersection=false;

      if(mCanv.blnMilesView) {
        if(mCanv.hshIntersectionsMilesView.containsKey(new BIMPointDouble(dblLongitudeX, dblLatitudeY))) {
          strChoices2=new String[vecIntersections.size()];

//        strChoices2=new String[sMap.size()];

          blnExactIntersection=true;
        }
        else {
          strChoices2=new String[vecIntersections.size()+1];

//        strChoices2=new String[sMap.size()+1];

          strChoices2[0]="Create New Intersection";

          ++intInsertIndex;
        }
      }
      else {
        if(mCanv.hshIntersections.containsKey(new BIMPoint(intLogicalX, intLogicalY))) {
          strChoices2=new String[vecIntersections.size()];

//        strChoices2=new String[sMap.size()];

          blnExactIntersection=true;
        }
        else {
          strChoices2=new String[vecIntersections.size()+1];

//        strChoices2=new String[sMap.size()+1];

          strChoices2[0]="Create New Intersection";

          ++intInsertIndex;
        }
      }

      BIMIntersection closeIntersections[]=new BIMIntersection[vecIntersections.size()];

//      BIMIntersection closeIntersections[]=new BIMIntersection[sMap.size()];

//      Iterator iterZ=sMap.entrySet().iterator();

//      int intCountZ=0;

      for(int i=0;i<vecIntersections.size();i++) {
        BIMIntersection bimIntersection=(BIMIntersection)vecIntersections.elementAt(i);        

//      while(iterZ.hasNext()) {
//        Map.Entry mEntry=(Map.Entry)iterZ.next();

//        BIMIntersection bimIntersection=(BIMIntersection)mEntry.getValue();

        strChoices2[intInsertIndex]=bimIntersection.getName();

        ++intInsertIndex;

        closeIntersections[i]=bimIntersection;

//        closeIntersections[intCountZ]=bimIntersection;

//        ++intCountZ;
      }      

//      Object objIntersection=mCanv.hshIntersections.get(new BIMPoint(intMeX, intMeY));

//      if(objIntersection!=null)
//        return;


      BIMChoiceDialog bDialogZ=new BIMChoiceDialog(this, "Intersection Choice", strChoices2);
      bDialogZ.show();

      int intSelectedChoiceZ=bDialogZ.getSelectedChoice();

      if(intSelectedChoiceZ==-1)
        return;

      BIMPoint bimPoint=null;

      BIMPointDouble bimPointD=null;

      BIMIntersection bimIntersection=null;

      boolean blnNewIntersection=false;

      if(blnExactIntersection) {
        bimIntersection=closeIntersections[intSelectedChoiceZ];

        Vector vecDestinations=bimIntersection.getDestinations();

        for(int i=0;i<vecDestinations.size();i++) {
          BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

//          BIMIntersection fromNext=roadNext.getFrom();

          BIMIntersection toNext=roadNext.getTo();

          if(toNext.getPoint().getX()==mCanv.bimIntersectionSelected.getPoint().getX() & toNext.getPoint().getY()==mCanv.bimIntersectionSelected.getPoint().getY())
            return;
        }

        bimPoint=bimIntersection.getPoint();

        bimPointD=new BIMPointDouble(bimIntersection.getLongitude(), bimIntersection.getLatitude());
      }
      else {
        if(intSelectedChoiceZ==0) {
          int intLogicalXNew=-1;
          int intLogicalYNew=-1;

          double dblLongitudeXNew=-1.0d;
          double dblLatitudeYNew=-1.0d;

          if(mCanv.blnMilesView) {
            dblLongitudeXNew=dblLongitudeX;
            dblLatitudeYNew=dblLatitudeY;

            bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


            CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Logical Point", (RoadsFrame.MyCanvas)mCanv.clone());
            cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
            cDialog.show();

            if(cDialog.cancelIt)
              return;

            int intClickX=cDialog.getClickX();
            int intClickY=cDialog.getClickY();

            intClickX=intClickX+cDialog.rFrameCanv.intRelativeX;
            intClickY=intClickY+cDialog.rFrameCanv.intRelativeY;

            intLogicalXNew=intClickX;
            intLogicalYNew=intClickY;

            bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);

/*
            BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical Y", "Logical Y:");
            bTFDialog.show();

            if(bTFDialog.cancelIt)
              return;

            String strLogicalY=bTFDialog.getText();

            intLogicalYNew=Integer.valueOf(strLogicalY).intValue();


            bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical X", "Logical X:");
            bTFDialog.show();

            if(bTFDialog.cancelIt)
              return;

            String strLogicalX=bTFDialog.getText();

            intLogicalXNew=Integer.valueOf(strLogicalX).intValue();

            bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);
*/
          }
          else {
            intLogicalXNew=intLogicalX;
            intLogicalYNew=intLogicalY;

            bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);


            CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Real Point", (RoadsFrame.MyCanvas)mCanv.clone());
            cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
            cDialog.show();

            if(cDialog.cancelIt)
              return;

            int intClickX=cDialog.getClickX();
            int intClickY=cDialog.getClickY();

            dblLongitudeXNew=new Integer(intClickX).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;
            dblLatitudeYNew=new Integer(intClickY).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;

            dblLongitudeXNew=dblLongitudeXNew+cDialog.rFrameCanv.dblRelativeX;
            dblLatitudeYNew=dblLatitudeYNew+cDialog.rFrameCanv.dblRelativeY;

            bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


/*
            BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Latitude", "Latitude:");
            bTFDialog.show();

            if(bTFDialog.cancelIt)
              return;

            String strLatitude=bTFDialog.getText();

            dblLatitudeYNew=Double.valueOf(strLatitude).doubleValue();


            bTFDialog=new BIMTextFieldDialog(this, "Intersection Longitude", "Longitude:");
            bTFDialog.show();

            if(bTFDialog.cancelIt)
              return;

            String strLongitude=bTFDialog.getText();

            dblLongitudeXNew=Double.valueOf(strLongitude).doubleValue();

            bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);
*/
          }


          bimIntersection=new BIMIntersection(bimPoint, dblLatitudeYNew, dblLongitudeXNew);

          blnNewIntersection=true;
        }
        else {
          bimIntersection=closeIntersections[intSelectedChoiceZ-1];

          Vector vecDestinations=bimIntersection.getDestinations();

          for(int i=0;i<vecDestinations.size();i++) {
            BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

//            BIMIntersection fromNext=roadNext.getFrom();

            BIMIntersection toNext=roadNext.getTo();

            if(toNext.getPoint().getX()==mCanv.bimIntersectionSelected.getPoint().getX() & toNext.getPoint().getY()==mCanv.bimIntersectionSelected.getPoint().getY())
              return;
          }

          bimPoint=bimIntersection.getPoint();

          bimPointD=new BIMPointDouble(bimIntersection.getLongitude(), bimIntersection.getLatitude());
        }
      }

      if(mCanv.blnMilesView) {
        if(bimPointD.getX()==mCanv.bimIntersectionSelected.getLongitude() & bimPointD.getY()==mCanv.bimIntersectionSelected.getLatitude())
          return;
      }
      else {
        if(bimPoint.getX()==mCanv.bimIntersectionSelected.getPoint().getX() & bimPoint.getY()==mCanv.bimIntersectionSelected.getPoint().getY())
          return;
      }

      String strChoices[]=new String[3];

      strChoices[0]="Make This Intersection Destination from "+mCanv.bimIntersectionSelected.getName();
      strChoices[1]="Do Nothing";
      strChoices[2]="Cancel Intersection Destination Creation";

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Intersection Choice", strChoices);
      bDialog.show();

      int intSelectedChoice=bDialog.getSelectedChoice();

      if(intSelectedChoice==-1)
        return;

      if(intSelectedChoice==0) {
        if(blnNewIntersection) {
          BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Intersection Name", "Intersection Name:");
          bDialog2.show();

          if(bDialog2.cancelIt)
            return;

          String strName=bDialog2.getText();

          bimIntersection.setName(strName);
        }


/*
        BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Road Length in Miles", "Road Length in Miles:");
        bDialog2.show();

        if(bDialog2.cancelIt)
          return;

        String strLength=bDialog2.getText();

        double dblLength=0.0d;
        try {
          dblLength=Double.valueOf(strLength).doubleValue();
        }
        catch(Exception ex) {
          return;
        }

        if(dblLength<=0.0d)
          return;
*/

        BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Road Speed Limit in MPH", "Road Speed Limit in MPH:");
        bDialog2.show();

        if(bDialog2.cancelIt)
          return;

        String strSpeedLimit=bDialog2.getText();

        double dblSpeedLimit=0.0d;
        try {
          dblSpeedLimit=Double.valueOf(strSpeedLimit).doubleValue();
        }
        catch(Exception ex) {
          return;
        }

        if(dblSpeedLimit<=0.0d)
          return;


//        BIMPoint bimPoint=new BIMPoint(intMeX, intMeY);

//        BIMIntersection bimIntersection=new BIMIntersection(strName, bimPoint);


        if(blnNewIntersection) {
          mCanv.hshIntersections.put(bimPoint, bimIntersection);
          mCanv.hshIntersectionsMilesView.put(bimPointD, bimIntersection);
        }


        bimIntersection.addDestination(new BIMRoad(bimIntersection, mCanv.bimIntersectionSelected, dblSpeedLimit));
        mCanv.bimIntersectionSelected.addDestination(new BIMRoad(mCanv.bimIntersectionSelected, bimIntersection, dblSpeedLimit));

//        bimIntersection.addDestination(new BIMRoad(bimIntersection, mCanv.bimIntersectionSelected, dblLength, dblSpeedLimit));
//        mCanv.bimIntersectionSelected.addDestination(new BIMRoad(mCanv.bimIntersectionSelected, bimIntersection, dblLength, dblSpeedLimit));


        if(!blnNewIntersection) {
          try {
            BIMIntersection.recalculateMajorIntersections(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections);
          }
          catch(Exception ex) {
            BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Connect New Intersection Error: Recalculate Major Intersections", ex.toString());
            bLDialog.show();

            bimIntersection.getDestinations().removeElementAt(bimIntersection.getDestinations().size()-1);
            mCanv.bimIntersectionSelected.getDestinations().removeElementAt(mCanv.bimIntersectionSelected.getDestinations().size()-1);

            return;
          }
        }
      }
      else if(intSelectedChoice==1) {
        return;
      }
      else if(intSelectedChoice==2) {
//        
      }

      mCanv.bimIntersectionSelected=null;

      mCanv.repaint();

      return;
    }
}


    Vector vecIntersections=new Vector();

    if(mCanv.blnMilesView) {
      double dblLongitudeLeftUpperX=new Integer(intMeX-30).doubleValue()*mCanv.dblMilesViewScale;
      dblLongitudeLeftUpperX=dblLongitudeLeftUpperX+mCanv.dblRelativeX;
      double dblLatitudeLeftUpperY=new Integer(intMeY-30).doubleValue()*mCanv.dblMilesViewScale;
      dblLatitudeLeftUpperY=dblLatitudeLeftUpperY+mCanv.dblRelativeY;

      double dblLongitudeRightLowerX=new Integer(intMeX+30).doubleValue()*mCanv.dblMilesViewScale;
      dblLongitudeRightLowerX=dblLongitudeRightLowerX+mCanv.dblRelativeX;
      double dblLatitudeRightLowerY=new Integer(intMeY+30).doubleValue()*mCanv.dblMilesViewScale;
      dblLatitudeRightLowerY=dblLatitudeRightLowerY+mCanv.dblRelativeY;

      Iterator iter=mCanv.hshIntersectionsMilesView.entrySet().iterator();

      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();

        BIMPointDouble pntDNext=(BIMPointDouble)mEntry.getKey();

        if(pntDNext.getX()>dblLongitudeLeftUpperX & pntDNext.getX()<dblLongitudeRightLowerX) {
          if(pntDNext.getY()>dblLatitudeLeftUpperY & pntDNext.getY()<dblLatitudeRightLowerY) {
            vecIntersections.addElement(mEntry.getValue());
          }
        }
      }
    }
    else {
      int intLeftUpperX=intMeX-30;
//      intLeftUpperX=intLeftUpperX+mCanv.intRelativeX;
      int intLeftUpperY=intMeY-30;
//      intLeftUpperY=intLeftUpperY+mCanv.intRelativeY;

      int intRightLowerX=intMeX+30;
//      intRightLowerX=intRightLowerX+mCanv.intRelativeX;
      int intRightLowerY=intMeY+30;
//      intRightLowerY=intRightLowerY+mCanv.intRelativeY;

      for(int i=intLeftUpperX;i<=intRightLowerX;i++) {
        for(int ia=intLeftUpperY;ia<=intRightLowerY;ia++) {
          Object objNext=mCanv.hshIntersections.get(new BIMPoint(i, ia));

          if(objNext!=null)
            vecIntersections.addElement(objNext);
        }
      }
    }

//    SortedMap sMap=mCanv.hshIntersections.subMap(new BIMPoint(intLeftUpperX, intLeftUpperY), new BIMPoint(intRightLowerX, intRightLowerY));

//    Iterator iter=sMap.entrySet().iterator();

    double dblCloseDistance=Double.MAX_VALUE-5.0d;

    BIMIntersection bimCloseIntersection=null;

    if(mCanv.blnMilesView) {
      double dblMeX=dblLongitudeX;
      double dblMeY=dblLatitudeY;

      for(int i=0;i<vecIntersections.size();i++) {
        BIMIntersection bimIntersection=(BIMIntersection)vecIntersections.elementAt(i);

//    while(iter.hasNext()) {
//      Map.Entry mEntry=(Map.Entry)iter.next();

//      BIMIntersection bimIntersection=(BIMIntersection)mEntry.getValue();

        BIMPoint bimPoint=bimIntersection.getPoint();

        double dblXNext=bimIntersection.getLongitude();
        double dblYNext=bimIntersection.getLatitude();

//        int intXNext=bimPoint.getX();
//        int intYNext=bimPoint.getY();

//        double dblXNext=new Integer(intXNext).doubleValue();
//        double dblYNext=new Integer(intYNext).doubleValue();

        double dblDistance=Math.sqrt(Math.pow(dblMeX-dblXNext, 2.0d)+Math.pow(dblMeY-dblYNext, 2.0d));

        if(dblDistance<dblCloseDistance) {
          dblCloseDistance=dblDistance;

          bimCloseIntersection=bimIntersection;
        }
      }
    }
    else {
      double dblMeX=new Integer(intLogicalX).doubleValue();
      double dblMeY=new Integer(intLogicalY).doubleValue();

      for(int i=0;i<vecIntersections.size();i++) {
        BIMIntersection bimIntersection=(BIMIntersection)vecIntersections.elementAt(i);

//    while(iter.hasNext()) {
//      Map.Entry mEntry=(Map.Entry)iter.next();

//      BIMIntersection bimIntersection=(BIMIntersection)mEntry.getValue();

        BIMPoint bimPoint=bimIntersection.getPoint();

        int intXNext=bimPoint.getX();
        int intYNext=bimPoint.getY();

        double dblXNext=new Integer(intXNext).doubleValue();
        double dblYNext=new Integer(intYNext).doubleValue();

        double dblDistance=Math.sqrt(Math.pow(dblMeX-dblXNext, 2.0d)+Math.pow(dblMeY-dblYNext, 2.0d));

        if(dblDistance<dblCloseDistance) {
          dblCloseDistance=dblDistance;

          bimCloseIntersection=bimIntersection;
        }
      }
    }

    if(bimCloseIntersection!=null) {
      BIMPoint bimClosePoint=bimCloseIntersection.getPoint();

      boolean blnExactMatchZ=false;

      if(mCanv.blnMilesView) {
        Object obj=mCanv.hshIntersectionsMilesView.get(new BIMPointDouble(dblLongitudeX, dblLatitudeY));

        if(obj!=null) {
          bimCloseIntersection=(BIMIntersection)obj;

          bimClosePoint=bimCloseIntersection.getPoint();

          blnExactMatchZ=true;
        }
      }
      else {
        Object obj=mCanv.hshIntersections.get(new BIMPoint(intLogicalX, intLogicalY));

        if(obj!=null) {
          bimCloseIntersection=(BIMIntersection)obj;

          bimClosePoint=bimCloseIntersection.getPoint();

          blnExactMatchZ=true;
        }
      }

      if(blnExactMatchZ) {
//      if(intMeX==bimClosePoint.getX() & intMeY==bimClosePoint.getY()) {
        String strChoices[]=new String[7];

        strChoices[0]="Connect To This Intersection: "+bimCloseIntersection.getName();
        strChoices[1]="Make Major Intersection: "+bimCloseIntersection.getName();
        strChoices[2]="Unmake Major Intersection: "+bimCloseIntersection.getName();
        strChoices[3]="Rename Intersection: "+bimCloseIntersection.getName();
        strChoices[4]="Delete Intersection: "+bimCloseIntersection.getName();
        strChoices[5]="Display Destinations: "+bimCloseIntersection.getName();
        strChoices[6]="Do Nothing";

        BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Intersection Choice", strChoices);
        bDialog.show();

        int intSelectedChoice=bDialog.getSelectedChoice();

        if(intSelectedChoice==-1)
          return;

        if(intSelectedChoice==0) {
synchronized(mCanv.objSyncSelectedIntersection) {
          mCanv.bimIntersectionSelected=bimCloseIntersection;

          mCanv.intersectionSelectedDestination=new BIMIntersection(bimCloseIntersection.getLatitude(), bimCloseIntersection.getLongitude());
}

          mCanv.repaint();
        }
        else if(intSelectedChoice==1) {
          try {
            BIMIntersection.connectMajorIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

//            mCanv.hshMajorIntersections.put(bimClosePoint, bimCloseIntersection);

            mCanv.repaint();
          }
          catch(Exception ex) {
            BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Connect Major Intersection Dialog", "Unable to connect major intersection.");
            bDialog.show();

            return;
          }
        }
        else if(intSelectedChoice==2) {
          try {
            BIMIntersection.disconnectMajorIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

//            mCanv.hshMajorIntersections.remove(bimClosePoint);

            mCanv.repaint();
          }
          catch(Exception ex) {
            BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Disconnect Major Intersection Dialog", "Unable to disconnect major intersection.");
            bDialog.show();

            return;
          }
        }
        else if(intSelectedChoice==3) {
          BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Intersection Name", "Intersection Name:");
          bDialog2.show();

          if(bDialog2.cancelIt)
            return;

          String strName=bDialog2.getText();

          bimCloseIntersection.setName(strName);
        }
        else if(intSelectedChoice==4) {
          try {
            BIMIntersection.deleteIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

            mCanv.repaint();
          }
          catch(Exception ex) {
            BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Delete Intersection Dialog", "Unable to delete intersection.");
            bDialog.show();

            return;
          }
        }
        else if(intSelectedChoice==5) {
          Vector vecDestinations=bimCloseIntersection.getDestinations();

          String strDestinations[]=new String[vecDestinations.size()];

          for(int i=0;i<strDestinations.length;i++) {
            BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

            strDestinations[i]=roadNext.getTo().getName()+": Length: "+roadNext.getLength()+" Speed: "+roadNext.getSpeedLimit();
          }

          BIMTextAreaDialog bTADialog=new BIMTextAreaDialog(this, "Destinations for "+bimCloseIntersection.getName(), strDestinations);
          bTADialog.show();
        }
        else if(intSelectedChoice==6) {
          return;
        }

        return;
      }

      String strChoices[]=new String[8];

      strChoices[0]="Create New Intersection";
      strChoices[1]="Connect To This Intersection: "+bimCloseIntersection.getName();
      strChoices[2]="Make Major Intersection: "+bimCloseIntersection.getName();
      strChoices[3]="Unmake Major Intersection: "+bimCloseIntersection.getName();
      strChoices[4]="Rename Intersection: "+bimCloseIntersection.getName();
      strChoices[5]="Delete Intersection: "+bimCloseIntersection.getName();
      strChoices[6]="Display Destinations: "+bimCloseIntersection.getName();
      strChoices[7]="Do Nothing";

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Intersection Choice", strChoices);
      bDialog.show();

      int intSelectedChoice=bDialog.getSelectedChoice();

      if(intSelectedChoice==-1)
        return;

      if(intSelectedChoice==0) {
        BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Intersection Name", "Intersection Name:");
        bDialog2.show();

        if(bDialog2.cancelIt)
          return;

        String strName=bDialog2.getText();

//        BIMPoint bimPoint=new BIMPoint(intMeX, intMeY);


        BIMPoint bimPoint=null;
        BIMPointDouble bimPointD=null;

        int intLogicalXNew=-1;
        int intLogicalYNew=-1;

        double dblLongitudeXNew=-1.0d;
        double dblLatitudeYNew=-1.0d;

        if(mCanv.blnMilesView) {
          dblLongitudeXNew=dblLongitudeX;
          dblLatitudeYNew=dblLatitudeY;

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


          CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Logical Point", (RoadsFrame.MyCanvas)mCanv.clone());
          cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
          cDialog.show();

          if(cDialog.cancelIt)
            return;

          int intClickX=cDialog.getClickX();
          int intClickY=cDialog.getClickY();

          intClickX=intClickX+cDialog.rFrameCanv.intRelativeX;
          intClickY=intClickY+cDialog.rFrameCanv.intRelativeY;

          intLogicalXNew=intClickX;
          intLogicalYNew=intClickY;

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);


/*
          BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical Y", "Logical Y:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLogicalY=bTFDialog.getText();

          intLogicalYNew=Integer.valueOf(strLogicalY).intValue();


          bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical X", "Logical X:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLogicalX=bTFDialog.getText();

          intLogicalXNew=Integer.valueOf(strLogicalX).intValue();

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);
*/
        }
        else {
          intLogicalXNew=intLogicalX;
          intLogicalYNew=intLogicalY;

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);


          CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Real Point", (RoadsFrame.MyCanvas)mCanv.clone());
          cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
          cDialog.show();

          if(cDialog.cancelIt)
            return;

          int intClickX=cDialog.getClickX();
          int intClickY=cDialog.getClickY();

          dblLongitudeXNew=new Integer(intClickX).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;
          dblLatitudeYNew=new Integer(intClickY).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;

          dblLongitudeXNew=dblLongitudeXNew+cDialog.rFrameCanv.dblRelativeX;
          dblLatitudeYNew=dblLatitudeYNew+cDialog.rFrameCanv.dblRelativeY;

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


/*
          BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Latitude", "Latitude:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLatitude=bTFDialog.getText();

          dblLatitudeYNew=Double.valueOf(strLatitude).doubleValue();


          bTFDialog=new BIMTextFieldDialog(this, "Intersection Longitude", "Longitude:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLongitude=bTFDialog.getText();

          dblLongitudeXNew=Double.valueOf(strLongitude).doubleValue();

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);
*/
        }


/*
        BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Latitude", "Latitude:");
        bTFDialog.show();

        if(bTFDialog.cancelIt)
          return;

        String strLatitude=bTFDialog.getText();

        double dblLatitude=Double.valueOf(strLatitude).doubleValue();


        bTFDialog=new BIMTextFieldDialog(this, "Intersection Longitude", "Longitude:");
        bTFDialog.show();

        if(bTFDialog.cancelIt)
          return;

        String strLongitude=bTFDialog.getText();

        double dblLongitude=Double.valueOf(strLongitude).doubleValue();
*/


        BIMIntersection bimIntersection=new BIMIntersection(strName, bimPoint, bimPointD.getY(), bimPointD.getX());

        mCanv.hshIntersections.put(bimPoint, bimIntersection);

        mCanv.hshIntersectionsMilesView.put(bimPointD, bimIntersection);

        mCanv.repaint();
      }
      else if(intSelectedChoice==1) {
synchronized(mCanv.objSyncSelectedIntersection) {
        mCanv.bimIntersectionSelected=bimCloseIntersection;

        mCanv.intersectionSelectedDestination=new BIMIntersection(bimCloseIntersection.getLatitude(), bimCloseIntersection.getLongitude());
}

        mCanv.repaint();
      }
      else if(intSelectedChoice==2) {
        try {
          BIMIntersection.connectMajorIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

//          mCanv.hshMajorIntersections.put(bimClosePoint, bimCloseIntersection);

          mCanv.repaint();
        }
        catch(Exception ex) {
          BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Connect Major Intersection Dialog", "Unable to connect major intersection.");
          bDialog.show();

          return;
        }
      }
      else if(intSelectedChoice==3) {
        try {
          BIMIntersection.disconnectMajorIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

//          mCanv.hshMajorIntersections.remove(bimClosePoint);

          mCanv.repaint();
        }
        catch(Exception ex) {
          BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Disconnect Major Intersection Dialog", "Unable to disconnect major intersection.");
          bDialog.show();

          return;
        }
      }
      else if(intSelectedChoice==4) {
        BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Intersection Name", "Intersection Name:");
        bDialog2.show();

        if(bDialog2.cancelIt)
          return;

        String strName=bDialog2.getText();

        bimCloseIntersection.setName(strName);
      }
      else if(intSelectedChoice==5) {
        try {
          BIMIntersection.deleteIntersection(mCanv.hshIntersections, mCanv.hshIntersectionsMilesView, mCanv.hshMajorIntersections, bimCloseIntersection);

          mCanv.repaint();
        }
        catch(Exception ex) {
          BIMLabelDialog bLDialog=new BIMLabelDialog(this, "Delete Intersection Dialog", "Unable to delete intersection.");
          bDialog.show();

          return;
        }
      }
      else if(intSelectedChoice==6) {
        Vector vecDestinations=bimCloseIntersection.getDestinations();

        String strDestinations[]=new String[vecDestinations.size()];

        for(int i=0;i<strDestinations.length;i++) {
          BIMRoad roadNext=(BIMRoad)vecDestinations.elementAt(i);

          strDestinations[i]=roadNext.getTo().getName()+": Length: "+roadNext.getLength()+" Speed: "+roadNext.getSpeedLimit();
        }

        BIMTextAreaDialog bTADialog=new BIMTextAreaDialog(this, "Destinations for "+bimCloseIntersection.getName(), strDestinations);
        bTADialog.show();
      }
      else if(intSelectedChoice==7) {
        return;
      }
    }
    else {
      String strChoices[]=new String[2];

      strChoices[0]="Create New Intersection";
      strChoices[1]="Do Nothing";

      BIMChoiceDialog bDialog=new BIMChoiceDialog(this, "Intersection Choice", strChoices);
      bDialog.show();

      int intSelectedChoice=bDialog.getSelectedChoice();

      if(intSelectedChoice==-1)
        return;

      if(intSelectedChoice==0) {
        BIMTextFieldDialog bDialog2=new BIMTextFieldDialog(this, "Intersection Name", "Intersection Name:");
        bDialog2.show();

        if(bDialog2.cancelIt)
          return;

//System.out.println("not canceled");

        String strName=bDialog2.getText();

//        BIMPoint bimPoint=new BIMPoint(intMeX, intMeY);


        BIMPoint bimPoint=null;
        BIMPointDouble bimPointD=null;

        int intLogicalXNew=-1;
        int intLogicalYNew=-1;

        double dblLongitudeXNew=-1.0d;
        double dblLatitudeYNew=-1.0d;

        if(mCanv.blnMilesView) {
          dblLongitudeXNew=dblLongitudeX;
          dblLatitudeYNew=dblLatitudeY;

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


          CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Logical Point", (RoadsFrame.MyCanvas)mCanv.clone());
          cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
          cDialog.show();

          if(cDialog.cancelIt)
            return;

          int intClickX=cDialog.getClickX();
          int intClickY=cDialog.getClickY();

          intClickX=intClickX+cDialog.rFrameCanv.intRelativeX;
          intClickY=intClickY+cDialog.rFrameCanv.intRelativeY;

          intLogicalXNew=intClickX;
          intLogicalYNew=intClickY;

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);


/*
          BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical Y", "Logical Y:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLogicalY=bTFDialog.getText();

          intLogicalYNew=Integer.valueOf(strLogicalY).intValue();


          bTFDialog=new BIMTextFieldDialog(this, "Intersection Logical X", "Logical X:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLogicalX=bTFDialog.getText();

          intLogicalXNew=Integer.valueOf(strLogicalX).intValue();

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);
*/
        }
        else {
          intLogicalXNew=intLogicalX;
          intLogicalYNew=intLogicalY;

          bimPoint=new BIMPoint(intLogicalXNew, intLogicalYNew);


          CanvasPointSelectorDialog cDialog=new CanvasPointSelectorDialog(this, "Click Real Point", (RoadsFrame.MyCanvas)mCanv.clone());
          cDialog.rFrameCanv.blnMilesView=!mCanv.blnMilesView;
          cDialog.show();

          if(cDialog.cancelIt)
            return;

          int intClickX=cDialog.getClickX();
          int intClickY=cDialog.getClickY();

          dblLongitudeXNew=new Integer(intClickX).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;
          dblLatitudeYNew=new Integer(intClickY).doubleValue()*cDialog.rFrameCanv.dblMilesViewScale;

          dblLongitudeXNew=dblLongitudeXNew+cDialog.rFrameCanv.dblRelativeX;
          dblLatitudeYNew=dblLatitudeYNew+cDialog.rFrameCanv.dblRelativeY;

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);


/*
          BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Latitude", "Latitude:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLatitude=bTFDialog.getText();

          dblLatitudeYNew=Double.valueOf(strLatitude).doubleValue();


          bTFDialog=new BIMTextFieldDialog(this, "Intersection Longitude", "Longitude:");
          bTFDialog.show();

          if(bTFDialog.cancelIt)
            return;

          String strLongitude=bTFDialog.getText();

          dblLongitudeXNew=Double.valueOf(strLongitude).doubleValue();

          bimPointD=new BIMPointDouble(dblLongitudeXNew, dblLatitudeYNew);
*/
        }


/*
        BIMTextFieldDialog bTFDialog=new BIMTextFieldDialog(this, "Intersection Latitude", "Latitude:");
        bTFDialog.show();

        if(bTFDialog.cancelIt)
          return;

        String strLatitude=bTFDialog.getText();

        double dblLatitude=Double.valueOf(strLatitude).doubleValue();


        bTFDialog=new BIMTextFieldDialog(this, "Intersection Longitude", "Longitude:");
        bTFDialog.show();

        if(bTFDialog.cancelIt)
          return;

        String strLongitude=bTFDialog.getText();

        double dblLongitude=Double.valueOf(strLongitude).doubleValue();
*/


        BIMIntersection bimIntersection=new BIMIntersection(strName, bimPoint, bimPointD.getY(), bimPointD.getX());

        mCanv.hshIntersections.put(bimPoint, bimIntersection);

        mCanv.hshIntersectionsMilesView.put(bimPointD, bimIntersection);

        mCanv.repaint();

//System.out.println("after");
      }
      else if(intSelectedChoice==1) {
        return;
      }
    }
  }

  class MyCanvas extends Canvas
  implements Cloneable {
    TreeMap hshIntersections=new TreeMap();
    TreeMap hshIntersectionsMilesView=new TreeMap();
    TreeMap hshMajorIntersections=new TreeMap();

    Object syncVehicles=new Object();
    Vector vecVehicles=new Vector();

    int intRelativeX=0;
    int intRelativeY=0;

    Object objSyncSelectedIntersection=new Object();
    BIMIntersection bimIntersectionSelected=null;
    BIMIntersection intersectionSelectedDestination=new BIMIntersection(0.0d, 0.0d);

    Object objSyncCalculateRoute=new Object();
    BIMIntersection bimIntersectionCalculateRoute=null;
    BIMIntersection intersectionCalculateRouteDestination=new BIMIntersection(0.0d, 0.0d);

    boolean blnMilesView=false; //value of true means the display shows scaled latitude and longitude view. value of false means the display shows logical view

    double dblRelativeX=0.0d;
    double dblRelativeY=0.0d;
    double dblMilesViewScale=1.0d/690.0d/5.0d;


    MyCanvas() {
      super();
    }

    public void paint(Graphics graph) {
      if(blnMilesView) {
        Iterator iter=hshIntersectionsMilesView.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mValue=(Map.Entry)iter.next();

          BIMPointDouble bimPointD=(BIMPointDouble)mValue.getKey();
          BIMIntersection bimIntersection=(BIMIntersection)mValue.getValue();

          double dblXStart=bimPointD.getX();
          double dblYStart=bimPointD.getY();

          double dblXRelativeStart=dblXStart-dblRelativeX;
          double dblYRelativeStart=dblYStart-dblRelativeY;

          dblXRelativeStart=dblXRelativeStart/dblMilesViewScale;
          dblYRelativeStart=dblYRelativeStart/dblMilesViewScale;

          int intXRelativeStart=(int)Math.rint(dblXRelativeStart);
          int intYRelativeStart=(int)Math.rint(dblYRelativeStart);

          graph.fillOval(intXRelativeStart-2, intYRelativeStart-2, 5, 5);

          Vector vecDestinations=bimIntersection.getDestinations();

          for(int i=0;i<vecDestinations.size();i++) {
            BIMRoad bimRoadNext=(BIMRoad)vecDestinations.elementAt(i);

            BIMIntersection bimIntersectionNext=bimRoadNext.getTo();

            BIMPointDouble bimPointNext=new BIMPointDouble(bimIntersectionNext.getLongitude(), bimIntersectionNext.getLatitude());

            double dblXNext=bimPointNext.getX();
            double dblYNext=bimPointNext.getY();

            double dblXRelativeNext=dblXNext-dblRelativeX;
            double dblYRelativeNext=dblYNext-dblRelativeY;

            dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
            dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

            int intXRelativeNext=(int)Math.rint(dblXRelativeNext);
            int intYRelativeNext=(int)Math.rint(dblYRelativeNext);

            graph.drawLine(intXRelativeStart, intYRelativeStart, intXRelativeNext, intYRelativeNext);

            graph.fillOval(intXRelativeNext-2, intYRelativeNext-2, 5, 5);
          }
        }


        graph.setColor(Color.green);

        iter=hshMajorIntersections.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();

          BIMIntersection intersectionNext=(BIMIntersection)mEntry.getValue();

          BIMPointDouble bimPointNext=new BIMPointDouble(intersectionNext.getLongitude(), intersectionNext.getLatitude());

          double dblXNext=bimPointNext.getX();
          double dblYNext=bimPointNext.getY();

          double dblXRelativeNext=dblXNext-dblRelativeX;
          double dblYRelativeNext=dblYNext-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          int intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          int intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          graph.fillOval(intXRelativeNext-2, intYRelativeNext-2, 5, 5);
        }

        graph.setColor(Color.black);


synchronized(objSyncSelectedIntersection) {
        if(bimIntersectionSelected!=null) {
          graph.setColor(Color.red);

          BIMPointDouble bimPointNext=new BIMPointDouble(bimIntersectionSelected.getLongitude(), bimIntersectionSelected.getLatitude());

          double dblXNext=bimPointNext.getX();
          double dblYNext=bimPointNext.getY();

          double dblXRelativeNext=dblXNext-dblRelativeX;
          double dblYRelativeNext=dblYNext-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          int intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          int intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          graph.fillOval(intXRelativeNext-2, intYRelativeNext-2, 5, 5);


          bimPointNext=new BIMPointDouble(intersectionSelectedDestination.getLongitude(), intersectionSelectedDestination.getLatitude());

          dblXNext=bimPointNext.getX();
          dblYNext=bimPointNext.getY();

          dblXRelativeNext=dblXNext-dblRelativeX;
          dblYRelativeNext=dblYNext-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          double dblLength=BIMIntersection.lengthFromHaversine(bimIntersectionSelected, intersectionSelectedDestination);

          graph.drawString(String.valueOf(dblLength)+" miles", intXRelativeNext, intYRelativeNext);

          graph.setColor(Color.black);
        }
}


synchronized(mCanv.objSyncCalculateRoute) {
        if(bimIntersectionCalculateRoute!=null) {
          graph.setColor(Color.blue);

          BIMPointDouble bimPointNext=new BIMPointDouble(bimIntersectionCalculateRoute.getLongitude(), bimIntersectionCalculateRoute.getLatitude());

          double dblXNext=bimPointNext.getX();
          double dblYNext=bimPointNext.getY();

          double dblXRelativeNext=dblXNext-dblRelativeX;
          double dblYRelativeNext=dblYNext-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          int intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          int intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          graph.fillOval(intXRelativeNext-2, intYRelativeNext-2, 5, 5);


          bimPointNext=new BIMPointDouble(intersectionCalculateRouteDestination.getLongitude(), intersectionCalculateRouteDestination.getLatitude());

          dblXNext=bimPointNext.getX();
          dblYNext=bimPointNext.getY();

          dblXRelativeNext=dblXNext-dblRelativeX;
          dblYRelativeNext=dblYNext-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          double dblLength=BIMIntersection.lengthFromHaversine(bimIntersectionCalculateRoute, intersectionCalculateRouteDestination);

//System.out.println(String.valueOf(intXRelativeNext)+", "+String.valueOf(intYRelativeNext));

          graph.drawString(String.valueOf(dblLength)+" miles", intXRelativeNext, intYRelativeNext);

          graph.setColor(Color.black);
        }
}


synchronized(syncVehicles) {

        graph.setColor(Color.gray);

        for(int i=0;i<vecVehicles.size();i++) {
          Vehicle vehicleNext=(Vehicle)vecVehicles.elementAt(i);

          if(!vehicleNext.isSpotted())
            continue;

          double dblLocationNext=vehicleNext.getRoadLocation();

          BIMRoad roadNext=vehicleNext.getRoad();

          double dblLength=roadNext.getLength();

          double dblRatio=dblLocationNext/dblLength;


          BIMIntersection intersectionFrom=roadNext.getFrom();
          double dblLongitudeFrom=intersectionFrom.getLongitude();
          double dblLatitudeFrom=intersectionFrom.getLatitude();

          BIMIntersection intersectionTo=roadNext.getTo();
          double dblLongitudeTo=intersectionTo.getLongitude();
          double dblLatitudeTo=intersectionTo.getLatitude();
          
          double dblLongitudeLatitudeDistance=Math.sqrt(Math.pow(dblLongitudeFrom-dblLongitudeTo, 2.0d)+Math.pow(dblLatitudeFrom-dblLatitudeTo, 2.0d));


          double dblRadius=dblRatio*dblLongitudeLatitudeDistance;


          int intQuadrant=0;

          double dblTheta=0.0d;

          if((dblLongitudeTo-dblLongitudeFrom)==0.0d) {
            dblTheta=Math.PI/2.0d;

            if((dblLatitudeTo-dblLatitudeFrom)>=0.0d) {
              intQuadrant=0;
//              dblTheta=Math.PI/2.0d;
            }
            else {
              intQuadrant=3;
//              dblTheta=Math.PI*3.0d/2.0d;
            }
          }
          else {
            dblTheta=Math.atan((dblLatitudeTo-dblLatitudeFrom)/(dblLongitudeTo-dblLongitudeFrom));

            dblTheta=Math.abs(dblTheta);

            if((dblLongitudeTo-dblLongitudeFrom)>=0.0d) {
              if((dblLatitudeTo-dblLatitudeFrom)>=0.0d) {
                intQuadrant=0;
              }
              else {
                intQuadrant=3;
//                dblTheta=Math.PI*2.0d-dblTheta;
              }
            }
            else {
              if((dblLatitudeTo-dblLatitudeFrom)>=0.0d) {
                intQuadrant=1;
//                dblTheta=Math.PI-dblTheta;
              }
              else {
                intQuadrant=2;
//                dblTheta=Math.PI+dblTheta;
              }
            }
          }


          double dblLongitudeX=dblRadius*Math.cos(dblTheta);

          if(intQuadrant==1 | intQuadrant==2)
            dblLongitudeX=-dblLongitudeX;

          dblLongitudeX=dblLongitudeFrom+dblLongitudeX;


          double dblLatitudeY=dblRadius*Math.sin(dblTheta);

          if(intQuadrant==2 | intQuadrant==3)
            dblLatitudeY=-dblLatitudeY;

          dblLatitudeY=dblLatitudeFrom+dblLatitudeY;


          double dblXRelativeNext=dblLongitudeX-dblRelativeX;
          double dblYRelativeNext=dblLatitudeY-dblRelativeY;

          dblXRelativeNext=dblXRelativeNext/dblMilesViewScale;
          dblYRelativeNext=dblYRelativeNext/dblMilesViewScale;

          int intXRelativeNext=(int)Math.rint(dblXRelativeNext);
          int intYRelativeNext=(int)Math.rint(dblYRelativeNext);

          graph.fillOval(intXRelativeNext-4, intYRelativeNext-4, 9, 9);
        }

}

        graph.setColor(Color.black);
      }
      else {
        Iterator iter=hshIntersections.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mValue=(Map.Entry)iter.next();

          BIMPoint bimPoint=(BIMPoint)mValue.getKey();
          BIMIntersection bimIntersection=(BIMIntersection)mValue.getValue();

          int intXStart=bimPoint.getX();
          int intYStart=bimPoint.getY();

          int intXRelativeStart=intXStart-intRelativeX;
          int intYRelativeStart=intYStart-intRelativeY;

          graph.fillOval(intXRelativeStart-2, intYRelativeStart-2, 5, 5);

          Vector vecDestinations=bimIntersection.getDestinations();

          for(int i=0;i<vecDestinations.size();i++) {
            BIMRoad bimRoadNext=(BIMRoad)vecDestinations.elementAt(i);

            BIMIntersection bimIntersectionNext=bimRoadNext.getTo();

            BIMPoint bimNext=bimIntersectionNext.getPoint();

            int intXNext=bimNext.getX();
            int intYNext=bimNext.getY();

            int intXRelativeNext=intXNext-intRelativeX;
            int intYRelativeNext=intYNext-intRelativeY;

            graph.drawLine(intXRelativeStart, intYRelativeStart, intXRelativeNext, intYRelativeNext);

            graph.fillOval(intXRelativeNext-2, intYRelativeNext-2, 5, 5);
          }
        }


        graph.setColor(Color.green);

        iter=hshMajorIntersections.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();

          BIMPoint bimPoint=(BIMPoint)mEntry.getKey();

          graph.fillOval(bimPoint.getX()-intRelativeX-2, bimPoint.getY()-intRelativeY-2, 5, 5);
        }

        graph.setColor(Color.black);


synchronized(objSyncSelectedIntersection) {
        if(bimIntersectionSelected!=null) {
          graph.setColor(Color.red);

          graph.fillOval(bimIntersectionSelected.getPoint().getX()-intRelativeX-2, bimIntersectionSelected.getPoint().getY()-intRelativeY-2, 5, 5);        

          graph.setColor(Color.black);
        }
}


synchronized(mCanv.objSyncCalculateRoute) {
        if(bimIntersectionCalculateRoute!=null) {
          graph.setColor(Color.blue);

          graph.fillOval(bimIntersectionCalculateRoute.getPoint().getX()-intRelativeX-2, bimIntersectionCalculateRoute.getPoint().getY()-intRelativeY-2, 5, 5);        

          graph.setColor(Color.black);
        }
}


synchronized(syncVehicles) {
        graph.setColor(Color.gray);

        for(int i=0;i<vecVehicles.size();i++) {
          Vehicle vehicleNext=(Vehicle)vecVehicles.elementAt(i);

          if(!vehicleNext.isSpotted())
            continue;

          double dblLocationNext=vehicleNext.getRoadLocation();

          BIMRoad roadNext=vehicleNext.getRoad();

          double dblLength=roadNext.getLength();

          double dblRatio=dblLocationNext/dblLength;


          BIMIntersection intersectionFrom=roadNext.getFrom();
          double dblXFrom=new Integer(intersectionFrom.getPoint().getX()).doubleValue();
          double dblYFrom=new Integer(intersectionFrom.getPoint().getY()).doubleValue();

          BIMIntersection intersectionTo=roadNext.getTo();
          double dblXTo=new Integer(intersectionTo.getPoint().getX()).doubleValue();
          double dblYTo=new Integer(intersectionTo.getPoint().getY()).doubleValue();

          
          double dblXYDistance=Math.sqrt(Math.pow(dblXFrom-dblXTo, 2.0d)+Math.pow(dblYFrom-dblYTo, 2.0d));


          double dblRadius=dblRatio*dblXYDistance;


          int intQuadrant=0;

          double dblTheta=0.0d;

          if((dblXTo-dblXFrom)==0.0d) {
            dblTheta=Math.PI/2.0d;

            if((dblYTo-dblYFrom)>=0.0d) {
              intQuadrant=0;
//              dblTheta=Math.PI/2.0d;
            }
            else {
              intQuadrant=3;
//              dblTheta=Math.PI*3.0d/2.0d;
            }
          }
          else {
            dblTheta=Math.atan((dblYTo-dblYFrom)/(dblXTo-dblXFrom));

            dblTheta=Math.abs(dblTheta);

            if((dblXTo-dblXFrom)>=0.0d) {
              if((dblYTo-dblYFrom)>=0.0d) {
                intQuadrant=0;
              }
              else {
                intQuadrant=3;
//                dblTheta=Math.PI*2.0d-dblTheta;
              }
            }
            else {
              if((dblYTo-dblYFrom)>=0.0d) {
                intQuadrant=1;
//                dblTheta=Math.PI-dblTheta;
              }
              else {
                intQuadrant=2;
//                dblTheta=Math.PI+dblTheta;
              }
            }
          }


          double dblX=dblRadius*Math.cos(dblTheta);

          if(intQuadrant==1 | intQuadrant==2)
            dblX=-dblX;

          dblX=dblXFrom+dblX;


          double dblY=dblRadius*Math.sin(dblTheta);

          if(intQuadrant==2 | intQuadrant==3)
            dblY=-dblY;

          dblY=dblYFrom+dblY;


          int intXRelativeNext=new Double(Math.rint(dblX)).intValue()-intRelativeX;
          int intYRelativeNext=new Double(Math.rint(dblY)).intValue()-intRelativeY;


          graph.fillOval(intXRelativeNext-4, intYRelativeNext-4, 9, 9);
        }

}

        graph.setColor(Color.black);
      }
    }

    public Object clone() {
      MyCanvas mCanv0=new MyCanvas();

      mCanv0.hshIntersections=hshIntersections;
      mCanv0.hshIntersectionsMilesView=hshIntersectionsMilesView;
      mCanv0.hshMajorIntersections=hshMajorIntersections;

      mCanv0.intRelativeX=intRelativeX;
      mCanv0.intRelativeY=intRelativeY;

      mCanv0.bimIntersectionSelected=bimIntersectionSelected;
      mCanv0.intersectionSelectedDestination=new BIMIntersection(intersectionSelectedDestination.getLatitude(), intersectionSelectedDestination.getLongitude());

      mCanv0.bimIntersectionCalculateRoute=bimIntersectionCalculateRoute;
      mCanv0.intersectionCalculateRouteDestination=new BIMIntersection(intersectionCalculateRouteDestination.getLatitude(), intersectionCalculateRouteDestination.getLongitude());

      mCanv0.blnMilesView=blnMilesView;

      mCanv0.dblRelativeX=dblRelativeX;
      mCanv0.dblRelativeY=dblRelativeY;
      mCanv0.dblMilesViewScale=dblMilesViewScale;

      return mCanv0;
    }
  }

  class CanvasPointSelectorDialog extends Dialog
  implements ActionListener, MouseListener, MouseMotionListener {
    RoadsFrame.MyCanvas rFrameCanv;
    Label lblCloseIntersection=new Label("                                                                           ");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    int intClickX=-1;
    int intClickY=-1;


    CanvasPointSelectorDialog(Frame parent, String strTitle, RoadsFrame.MyCanvas rFrameCanv) {
      super(parent, strTitle, true);

      this.rFrameCanv=rFrameCanv;

      rFrameCanv.bimIntersectionSelected=null;

      rFrameCanv.bimIntersectionCalculateRoute=null;

      setLayout(new BorderLayout());

      add("Center", rFrameCanv);
      rFrameCanv.addMouseListener(this);
      rFrameCanv.addMouseMotionListener(this);

      Panel pnlTempZ=new Panel();
      pnlTempZ.setLayout(new GridLayout(2, 1));

      Panel pnlTempZ1=new Panel();
      pnlTempZ1.setLayout(new BorderLayout());
      pnlTempZ1.add("West", new Label("Close Intersection: "));
      pnlTempZ1.add("Center", lblCloseIntersection);

      pnlTempZ.add(pnlTempZ1);

      Panel pnlTemp=new Panel();
      pnlTemp.add(btnCancel);
      btnCancel.addActionListener(this);

      pnlTempZ.add(pnlTemp);

      add("South", pnlTempZ);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

      setLocation(0, 0);
      setSize(dimScreen.width, dimScreen.height-50);
    }

    public int getClickX() {
      return intClickX;
    }

    public int getClickY() {
      return intClickY;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }

    public void mouseMoved(MouseEvent me) {
      int intMeX=me.getX();
      int intMeY=me.getY();

      double dblCloseDistance=Double.MAX_VALUE;
      BIMIntersection bimCloseIntersection=null;

      if(rFrameCanv.blnMilesView) {
        double dblMeX=new Integer(intMeX).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblMeX=dblMeX+rFrameCanv.dblRelativeX;

        double dblMeY=new Integer(intMeY).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblMeY=dblMeY+rFrameCanv.dblRelativeY;

        double dblLongitudeLeftUpperX=new Integer(intMeX-30).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblLongitudeLeftUpperX=dblLongitudeLeftUpperX+rFrameCanv.dblRelativeX;
        double dblLatitudeLeftUpperY=new Integer(intMeY-30).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblLatitudeLeftUpperY=dblLatitudeLeftUpperY+rFrameCanv.dblRelativeY;

        double dblLongitudeRightLowerX=new Integer(intMeX+30).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblLongitudeRightLowerX=dblLongitudeRightLowerX+rFrameCanv.dblRelativeX;
        double dblLatitudeRightLowerY=new Integer(intMeY+30).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblLatitudeRightLowerY=dblLatitudeRightLowerY+rFrameCanv.dblRelativeY;

        Iterator iter=rFrameCanv.hshIntersectionsMilesView.entrySet().iterator();

        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();

          BIMPointDouble pntDNext=(BIMPointDouble)mEntry.getKey();

          if(pntDNext.getX()>dblLongitudeLeftUpperX & pntDNext.getX()<dblLongitudeRightLowerX) {
            if(pntDNext.getY()>dblLatitudeLeftUpperY & pntDNext.getY()<dblLatitudeRightLowerY) {
              double dblNextDistance=Math.sqrt(Math.pow(dblMeX-pntDNext.getX(), 2.0d)+Math.pow(dblMeY-pntDNext.getY(), 2.0d));

              if(dblNextDistance<dblCloseDistance) {
                dblCloseDistance=dblNextDistance;

                bimCloseIntersection=(BIMIntersection)mEntry.getValue();
              }
            }
          }
        }
      }
      else {
        int intLeftUpperX=intMeX-30;
        intLeftUpperX=intLeftUpperX+rFrameCanv.intRelativeX;
        int intLeftUpperY=intMeY-30;
        intLeftUpperY=intLeftUpperY+rFrameCanv.intRelativeY;

        int intRightLowerX=intMeX+30;
        intRightLowerX=intRightLowerX+rFrameCanv.intRelativeX;
        int intRightLowerY=intMeY+30;
        intRightLowerY=intRightLowerY+rFrameCanv.intRelativeY;

        intMeX=intMeX+rFrameCanv.intRelativeX;
        intMeY=intMeY+rFrameCanv.intRelativeY;

        double dblMeX=new Integer(intMeX).doubleValue();
        double dblMeY=new Integer(intMeY).doubleValue();

        for(int i=intLeftUpperX;i<=intRightLowerX;i++) {
          for(int ia=intLeftUpperY;ia<=intRightLowerY;ia++) {
            Object objNext=rFrameCanv.hshIntersections.get(new BIMPoint(i, ia));

            if(objNext==null)
              continue;

            double dblNextX=new Integer(i).doubleValue();
            double dblNextY=new Integer(ia).doubleValue();

            double dblNextDistance=Math.sqrt(Math.pow(dblMeX-dblNextX, 2.0d)+Math.pow(dblMeY-dblNextY, 2.0d));

            if(dblNextDistance<dblCloseDistance) {
              dblCloseDistance=dblNextDistance;

              bimCloseIntersection=(BIMIntersection)objNext;
            }
          }
        }
      }

      if(bimCloseIntersection!=null) {
        lblCloseIntersection.setText(bimCloseIntersection.getName());
      }
      else {
        lblCloseIntersection.setText("");
      }
    }

    public void mouseDragged(MouseEvent me) {
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      int intLogicalX=-1;
      int intLogicalY=-1;

      double dblLongitudeX=-1.0d;
      double dblLatitudeY=-1.0d;

      int intMeX=me.getX();
      int intMeY=me.getY();

      if(mCanv.blnMilesView) {
        dblLongitudeX=new Integer(intMeX).doubleValue()*rFrameCanv.dblMilesViewScale;
        dblLatitudeY=new Integer(intMeY).doubleValue()*rFrameCanv.dblMilesViewScale;

        dblLongitudeX=dblLongitudeX+rFrameCanv.dblRelativeX;
        dblLatitudeY=dblLatitudeY+rFrameCanv.dblRelativeY;
      }
      else {
        intLogicalX=intMeX+rFrameCanv.intRelativeX;
        intLogicalY=intMeY+rFrameCanv.intRelativeY;
      }


      if(rFrameCanv.blnMilesView) {
        if(rFrameCanv.hshIntersectionsMilesView.containsKey(new BIMPointDouble(dblLongitudeX, dblLatitudeY)))
          return;
      }
      else {
        if(rFrameCanv.hshIntersections.containsKey(new BIMPoint(intLogicalX, intLogicalY)))
          return;
      }


      intClickX=me.getX();

      intClickY=me.getY();

      dispose();
    }
  }

  class VehiclesThread extends Thread {
    double dblTimeIncrement=1.0d/3600.0d;
    long lngSleepInterval=1000l;

    boolean blnKeepAlive=true;


    VehiclesThread() {
      super();
    }

    public void run() {
      Vector vecVehicles=mCanv.vecVehicles;

      try {
        while(blnKeepAlive) {
          Thread.sleep(lngSleepInterval);

synchronized(mCanv.syncVehicles) {
          if(vecVehicles.size()>0) {
            for(int i=0;i<vecVehicles.size();i++) {
              Vehicle vehicleNext=(Vehicle)vecVehicles.elementAt(i);

              vehicleNext.travelTime(dblTimeIncrement);
            }

            mCanv.repaint();
          }
}

        }
      }
      catch(Exception ex) {
      }
    }
  }
}