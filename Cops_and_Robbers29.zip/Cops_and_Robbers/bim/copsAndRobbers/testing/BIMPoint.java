package bim.copsAndRobbers.testing;

class BIMPoint
implements Comparable, Cloneable {
  Integer intX=new Integer(0);
  Integer intY=new Integer(0);

  BIMPoint(int intX0, int intY0) {
    this.intX=new Integer(intX0);
    this.intY=new Integer(intY0);
  }

  public int getX() {
    return intX.intValue();
  }

  public int getY() {
    return intY.intValue();
  }

  public int compareTo(Object obj) {
    BIMPoint objPnt=(BIMPoint)obj;

    if(getX()<objPnt.getX()) {
      return -1;
    }
    else if(getX()>objPnt.getX()) {
      return 1;
    }
    else {
      if(getY()<objPnt.getY()) {
        return -1;
      }
      else if(getY()>objPnt.getY()) {
        return 1;
      }
    }

    return 0;
  }

  public Object clone() {
    BIMPoint objClone=new BIMPoint(intX.intValue(), intY.intValue());

    return objClone;
  }
}