package bim.copsAndRobbers.testing;

import java.awt.*;
import java.awt.event.*;

class BIMTextAreaDialog extends Dialog
implements ActionListener {
  TextArea txtTxt=new TextArea();
  Button btnOkay=new Button("Okay");


  BIMTextAreaDialog(Frame parent, String strTitle, String strText[]) {
    super(parent, strTitle, true);

    setLayout(new BorderLayout());

    for(int i=0;i<strText.length;i++) {
      txtTxt.append(strText[i]);
      txtTxt.append("\n");
    }

    add("Center", txtTxt);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnOkay);
    btnOkay.addActionListener(this);

    add("South", pnlTemp);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(dimScreen.width/4, dimScreen.height/3);
    setSize(dimScreen.width/2, dimScreen.height/3);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnOkay) {
      dispose();
    }
  }
}