package bim.copsAndRobbers.testing;

import java.awt.Rectangle;
import java.util.Vector;

class VectorMovementObject {
    volatile int intWidth=9;
    volatile int intHeight=9;

    volatile int intX=-1;
    volatile int intY=-1;
    volatile double dblSpeed=0.0d;
    volatile double dblReferenceAngle=0.0d;
    volatile int intQuadrant=0;

    volatile int intXDestination=-1;
    volatile int intYDestination=-1;

    volatile boolean blnChooseNewDestination=true;

    VectorMovementObject(int intWidth, int intHeight, int intX, int intY, double dblSpeed) {
      this.intWidth=intWidth;
      this.intHeight=intHeight;
      this.intX=intX;
      this.intY=intY;
      this.dblSpeed=dblSpeed;
    }

    VectorMovementObject(int intWidth, int intHeight, int intX, int intY, double dblSpeed, double dblReferenceAngle, int intQuadrant, int intXDestination, int intYDestination) {
      this.intWidth=intWidth;
      this.intHeight=intHeight;
      this.intX=intX;
      this.intY=intY;
      this.dblSpeed=dblSpeed;
      this.dblReferenceAngle=dblReferenceAngle;
      this.intQuadrant=intQuadrant;
      this.intXDestination=intXDestination;
      this.intYDestination=intYDestination;

      blnChooseNewDestination=false;
    }

    public int getWidth() {
      return intWidth;
    }

    public void setWidth(int intWidth) {
      this.intWidth=intWidth;
    }

    public int getHeight() {
      return intHeight;
    }

    public void setHeight(int intHeight) {
      this.intHeight=intHeight;
    }

    public int getX() {
      return intX;
    }

    public void setX(int intX) {
      this.intX=intX;
    }

    public int getY() {
      return intY;
    }

    public void setY(int intY) {
      this.intY=intY;
    }

    public double getSpeed() {
      return dblSpeed;
    }

    public void setSpeed(double dblSpeed) {
      this.dblSpeed=dblSpeed;
    }

    public double getReferenceAngle() {
      return dblReferenceAngle;
    }

    public void setReferenceAngle(double dblReferenceAngle) {
      this.dblReferenceAngle=dblReferenceAngle;
    }

    public int getQuadrant() {
      return intQuadrant;
    }

    public void setQuadrant(int intQuadrant) {
      this.intQuadrant=intQuadrant;
    }

    public int getXDestination() {
      return intXDestination;
    }

    public void setXDestination(int intXDestination) {
      this.intXDestination=intXDestination;
    }

    public int getYDestination() {
      return intYDestination;
    }

    public void setYDestination(int intYDestination) {
      this.intYDestination=intYDestination;
    }

    public boolean doChooseNewDestination() {
      return blnChooseNewDestination;
    }

    public void setDoChooseNewDestination(boolean blnChooseNewDestination) {
      this.blnChooseNewDestination=blnChooseNewDestination;
    }

    public void move(double dblTime, int intUpperLeftX, int intUpperLeftY, int intLowerRightX, int intLowerRightY, Vector vecReturnMP) {
      if(intX==intXDestination & intY==intYDestination) {
        vecReturnMP.addElement(new MovementPath(intX-1, intY-1, intX+1, intY+1, intWidth, intHeight));

        if(blnChooseNewDestination)
          chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);
        else
          return;
      }

//double dblReferenceAngleZ=dblReferenceAngle;
//double dblReferenceAngle=dblReferenceAngleZ;
//if(dblReferenceAngle==0.0d) {
//dblReferenceAngle=0.0000001d;
//}
//if(dblReferenceAngle==(Math.PI/2.0d)) {
//dblReferenceAngle=Math.PI/2.0d-0.0000001d;
//}

      if(dblSpeed==0.0d)
        return;

//      double dblXNew=0.0d;
//      double dblYNew=0.0d;

      double dblX=new Integer(intX).doubleValue();
      double dblY=new Integer(intY).doubleValue();

//if(dblSpeed==10.0d)
//System.out.println("d2:"+intXDestination+", "+intYDestination);

      double dblXDestination=new Integer(intXDestination).doubleValue();
      double dblYDestination=new Integer(intYDestination).doubleValue();

      double dblXChange=dblTime*dblSpeed*Math.cos(dblReferenceAngle);
      double dblYChange=dblTime*dblSpeed*Math.sin(dblReferenceAngle);

//System.out.println("change: "+dblXChange+", "+dblYChange);


      if(intQuadrant==0) {
        if((dblX+dblXChange)>dblXDestination & (dblY+dblYChange)>dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblXChange=dblXDestination-dblX;

            double dblTrig=Math.cos(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblXChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
/*
        else if((dblY+dblYChange)>dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblYChange=dblYDestination-dblY;

            double dblTrig=Math.sin(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblYChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
*/
        else {
          dblX=dblX+dblXChange;
          dblY=dblY+dblYChange;

          int intX0=(int)Math.rint(dblX);
          int intY0=(int)Math.rint(dblY);

          MovementPath mPath=new MovementPath(intX, intY, intX0, intY0, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intX0;
          intY=intY0;
        }
      }
      else if(intQuadrant==1) {
        if((dblX-dblXChange)<dblXDestination & (dblY+dblYChange)>dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblXChange=dblX-dblXDestination;

            double dblTrig=Math.cos(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblXChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
/*
        else if((dblY+dblYChange)>dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblYChange=dblYDestination-dblY;

            double dblTrig=Math.sin(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblYChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
*/
        else {
          dblX=dblX-dblXChange;
          dblY=dblY+dblYChange;

          int intX0=(int)Math.rint(dblX);
          int intY0=(int)Math.rint(dblY);

          MovementPath mPath=new MovementPath(intX, intY, intX0, intY0, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intX0;
          intY=intY0;
        }
      }
      else if(intQuadrant==2) {
        if((dblX-dblXChange)<dblXDestination & (dblY-dblYChange)<dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblXChange=dblX-dblXDestination;

            double dblTrig=Math.cos(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblXChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
/*
        else if((dblY-dblYChange)<dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblYChange=dblY-dblYDestination;

            double dblTrig=Math.sin(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblYChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
*/
        else {
          dblX=dblX-dblXChange;
          dblY=dblY-dblYChange;

          int intX0=(int)Math.rint(dblX);
          int intY0=(int)Math.rint(dblY);

          MovementPath mPath=new MovementPath(intX, intY, intX0, intY0, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intX0;
          intY=intY0;
        }
      }
      else if(intQuadrant==3) {
        if((dblX+dblXChange)>dblXDestination & (dblY-dblYChange)<dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblXChange=dblXDestination-dblX;

            double dblTrig=Math.cos(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblXChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
/*
        else if((dblY-dblYChange)<dblYDestination) {
          MovementPath mPath=new MovementPath(intX, intY, intXDestination, intYDestination, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intXDestination;
          intY=intYDestination;


//if(dblSpeed==10.0d) {
//System.out.println("change: "+dblXChange+", "+dblYChange);
//System.out.println("destination: "+dblXDestination+", "+dblYDestination);
//System.exit(0);
//}


          if(blnChooseNewDestination) {
            dblYChange=dblY-dblYDestination;

            double dblTrig=Math.sin(dblReferenceAngle);
            if(dblTrig==0.0d)
              dblTrig=0.000000000001d;

            double dblTimeChange=dblYChange/dblSpeed/dblTrig;

            double dblTimeDifference=dblTime-dblTimeChange;

            chooseNewDestination(intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY);

            move(dblTimeDifference, intUpperLeftX, intUpperLeftY, intLowerRightX, intLowerRightY, vecReturnMP);
          }
        }
*/
        else {
          dblX=dblX+dblXChange;
          dblY=dblY-dblYChange;

          int intX0=(int)Math.rint(dblX);
          int intY0=(int)Math.rint(dblY);

          MovementPath mPath=new MovementPath(intX, intY, intX0, intY0, intWidth, intHeight);

          vecReturnMP.addElement(mPath);

          intX=intX0;
          intY=intY0;
        }
      }
    }

    public void chooseNewDestination(int intUpperLeftX, int intUpperLeftY, int intLowerRightX, int intLowerRightY) {
      double dblReferenceAngle0=Math.PI/2.0d*Math.random();

      int intQuadrant0=-1;

      while(true) {
        double dblQuadrant=4.0d*Math.random();

        intQuadrant0=(int)Math.floor(dblQuadrant);

//System.out.println("continue:"+intQuadrant0);

        if(intQuadrant0==0) {
          if(intX>=intLowerRightX || intY>=intLowerRightY) {
            continue;
          }
        }
        else if(intQuadrant0==1) {
          if(intX<=intUpperLeftX || intY>=intLowerRightY) {
            continue;
          }
        }
        else if(intQuadrant0==2) {
          if(intX<=intUpperLeftX || intY<=intUpperLeftY) {
            continue;
          }
        }
        else if(intQuadrant0==3) {
          if(intX>=intLowerRightX || intY<=intUpperLeftY) {
            continue;
          }
        }

//System.out.println("break");
        break;
      }

//System.out.println("Quadrant Before:"+intQuadrant);

      dblReferenceAngle=dblReferenceAngle0;
      intQuadrant=intQuadrant0;

//System.out.println("Quadrant After:"+intQuadrant);

      double dblX=new Integer(intX).doubleValue();
      double dblY=new Integer(intY).doubleValue();

      double dblUpperLeftX=new Integer(intUpperLeftX).doubleValue();
      double dblUpperLeftY=new Integer(intUpperLeftY).doubleValue();
      double dblLowerRightX=new Integer(intLowerRightX).doubleValue();
      double dblLowerRightY=new Integer(intLowerRightY).doubleValue();      

      double dblDestination[]=VectorMovementObject.chooseNewDestination(dblReferenceAngle, intQuadrant, dblX, dblY, dblUpperLeftX, dblUpperLeftY, dblLowerRightX, dblLowerRightY);

      intXDestination=(int)Math.rint(dblDestination[0]);
      intYDestination=(int)Math.rint(dblDestination[1]);

//System.out.println(intXDestination+", "+intYDestination);

//System.out.println(intUpperLeftX+", "+intUpperLeftY+", "+intLowerRightX+", "+intLowerRightY);
    }

    public static double[] chooseNewDestination(double dblReferenceAngle, int intQuadrant, double dblX, double dblY, double dblUpperLeftX, double dblUpperLeftY, double dblLowerRightX, double dblLowerRightY) {
      double dblRet[]=new double[2];

      if(dblReferenceAngle==(Math.PI/2.0d))
        dblReferenceAngle=Math.PI/2.0d-0.000000000001d;

      double dblSlope=Math.tan(dblReferenceAngle);

      if(intQuadrant==1 || intQuadrant==3)
        dblSlope=-dblSlope;

      double dblXNeg=-dblX;

      double dblYIntercept=dblSlope*dblXNeg+dblY;

      if(dblSlope==0.0d) {
        dblRet[1]=dblY;

        if(intQuadrant==0) {
          dblRet[0]=dblLowerRightX;
        }
        else if(intQuadrant==1) {
          dblRet[0]=dblUpperLeftX;
        }
        else if(intQuadrant==2) {
          dblRet[0]=dblUpperLeftX;
        }
        else if(intQuadrant==3) {
          dblRet[0]=dblLowerRightX;
        }
      }
      else {
        if(intQuadrant==0) {
          double dblYBoundary=dblSlope*dblLowerRightX+dblYIntercept;
          if(dblYBoundary<=dblLowerRightY) {
            dblRet[0]=dblLowerRightX;

            dblRet[1]=dblYBoundary;
          }
          else {
            dblYBoundary=dblLowerRightY;

            double dblDiff=dblYBoundary-dblYIntercept;

            double dblXBoundary=dblDiff/dblSlope;

            dblRet[0]=dblXBoundary;

            dblRet[1]=dblLowerRightY;
          }
        }
        else if(intQuadrant==1) {
          double dblYBoundary=dblSlope*dblUpperLeftX+dblYIntercept;
          if(dblYBoundary<=dblLowerRightY) {
            dblRet[0]=dblUpperLeftX;

            dblRet[1]=dblYBoundary;
          }
          else {
            dblYBoundary=dblLowerRightY;

            double dblDiff=dblYBoundary-dblYIntercept;

            double dblXBoundary=dblDiff/dblSlope;

            dblRet[0]=dblXBoundary;

            dblRet[1]=dblLowerRightY;
          }
        }
        else if(intQuadrant==2) {
          double dblYBoundary=dblSlope*dblUpperLeftX+dblYIntercept;
          if(dblYBoundary>=dblUpperLeftY) {
            dblRet[0]=dblUpperLeftX;

            dblRet[1]=dblYBoundary;
          }
          else {
            dblYBoundary=dblUpperLeftY;

            double dblDiff=dblYBoundary-dblYIntercept;

            double dblXBoundary=dblDiff/dblSlope;

            dblRet[0]=dblXBoundary;

            dblRet[1]=dblUpperLeftY;
          }
        }
        else if(intQuadrant==3) {
          double dblYBoundary=dblSlope*dblLowerRightX+dblYIntercept;
          if(dblYBoundary>=dblUpperLeftY) {
            dblRet[0]=dblLowerRightX;

            dblRet[1]=dblYBoundary;
          }
          else {
            dblYBoundary=dblUpperLeftY;

            double dblDiff=dblYBoundary-dblYIntercept;

            double dblXBoundary=dblDiff/dblSlope;

            dblRet[0]=dblXBoundary;

            dblRet[1]=dblUpperLeftY;
          }
        }
      }

      return dblRet;
    }

    public static boolean checkCollision(MovementPath mPath, MovementPath mPath2) {
      double dblStartX1=new Integer(mPath.getStartX()).doubleValue();
      double dblStartY1=new Integer(mPath.getStartY()).doubleValue();
      double dblEndX1=new Integer(mPath.getEndX()).doubleValue();
      double dblEndY1=new Integer(mPath.getEndY()).doubleValue();

      if(dblStartX1>dblEndX1) {
        double dblTemp=dblStartX1;
        dblStartX1=dblEndX1;
        dblEndX1=dblTemp;

        dblTemp=dblStartY1;
        dblStartY1=dblEndY1;
        dblEndY1=dblTemp;
      }

      double dblStartX2=new Integer(mPath2.getStartX()).doubleValue();
      double dblStartY2=new Integer(mPath2.getStartY()).doubleValue();
      double dblEndX2=new Integer(mPath2.getEndX()).doubleValue();
      double dblEndY2=new Integer(mPath2.getEndY()).doubleValue();

      if(dblStartX2>dblEndX2) {
        double dblTemp=dblStartX2;
        dblStartX2=dblEndX2;
        dblEndX2=dblTemp;

        dblTemp=dblStartY2;
        dblStartY2=dblEndY2;
        dblEndY2=dblTemp;
      }

      double dblDenominator1=dblEndX1-dblStartX1;

      double dblDenominator2=dblEndX2-dblStartX2;

      double dblSlope1=0.0d;
      double dblSlope2=0.0d;

      if(dblDenominator1==0.0d) {
        Rectangle rPath1[]=VectorMovementObject.verticalPath(mPath.getStartX(), mPath.getStartY(), mPath.getEndY(), mPath.getWidth(), mPath.getHeight());

        if(dblDenominator2==0.0d) {
          Rectangle rPath2[]=VectorMovementObject.verticalPath(mPath2.getStartX(), mPath2.getStartY(), mPath2.getEndY(), mPath2.getWidth(), mPath2.getHeight());

          for(int i=0;i<rPath1.length;i++) {
            for(int ia=0;ia<rPath2.length;ia++) {
              if(rPath1[i].intersects(rPath2[ia]))
                return true;
            }
          }
        }
        else {
          dblSlope2=(dblEndY2-dblStartY2)/(dblEndX2-dblStartX2);

          double dblYIntercept2=-dblSlope2*dblStartX2+dblStartY2;

          Rectangle rPath2[]=VectorMovementObject.slopePath(dblSlope2, dblYIntercept2, dblStartX2, dblEndX2, dblStartY2, dblEndY2, mPath2.getWidth(), mPath2.getHeight());

          for(int i=0;i<rPath1.length;i++) {
            for(int ia=0;ia<rPath2.length;ia++) {
              if(rPath1[i].intersects(rPath2[ia]))
                return true;
            }
          }

        }
      }
      else {
        dblSlope1=(dblEndY1-dblStartY1)/(dblEndX1-dblStartX1);

        double dblYIntercept1=-dblSlope1*dblStartX1+dblStartY1;

        Rectangle rPath1[]=VectorMovementObject.slopePath(dblSlope1, dblYIntercept1, dblStartX1, dblEndX1, dblStartY1, dblEndY1, mPath.getWidth(), mPath.getHeight());

        if(dblDenominator2==0.0d) {
          Rectangle rPath2[]=VectorMovementObject.verticalPath(mPath2.getStartX(), mPath2.getStartY(), mPath2.getEndY(), mPath2.getWidth(), mPath2.getHeight());

          for(int i=0;i<rPath1.length;i++) {
            for(int ia=0;ia<rPath2.length;ia++) {
              if(rPath1[i].intersects(rPath2[ia]))
                return true;
            }
          }

        }
        else {
          dblSlope2=(dblEndY2-dblStartY2)/(dblEndX2-dblStartX2);

          double dblYIntercept2=-dblSlope2*dblStartX2+dblStartY2;

          Rectangle rPath2[]=VectorMovementObject.slopePath(dblSlope2, dblYIntercept2, dblStartX2, dblEndX2, dblStartY2, dblEndY2, mPath2.getWidth(), mPath2.getHeight());

          for(int i=0;i<rPath1.length;i++) {
            for(int ia=0;ia<rPath2.length;ia++) {
              if(rPath1[i].intersects(rPath2[ia]))
                return true;
            }
          }

        }
      }

/*
      if(dblDenominator1==0.0d) {
        if(dblDenominator2==0.0d) {
          return false;
        }
        else {
          dblSlope1=Double.NaN;

          dblSlope2=(dblEndY2-dblStartY2)/(dblEndX2-dblStartX2);

          double dblYIntercept2=-dblSlope2*dblStartX2+dblStartY2;

          double dblY2=dblSlope2*dblStartX1+dblYIntercept2;

          if(dblStartX1>=dblStartX2 & dblStartX1<=dblEndX2) {
            if(dblY2>=dblStartY1 & dblY2<=dblEndY1)
              return true;
          }
        }
      }
      else {
        if(dblDenominator2==0.0d) {
          dblSlope1=(dblEndY1-dblStartY1)/(dblEndX1-dblStartX1);

          dblSlope2=Double.NaN;

          double dblYIntercept1=-dblSlope1*dblStartX1+dblStartY1;

          double dblY1=dblSlope1*dblStartX2+dblYIntercept1;

          if(dblStartX2>=dblStartX1 & dblStartX2<=dblEndX1) {
            if(dblY1>=dblStartY2 & dblY1<=dblEndY2)
              return true;
          }
        }
        else {
          dblSlope1=(dblEndY1-dblStartY1)/(dblEndX1-dblStartX1);

          dblSlope2=(dblEndY2-dblStartY2)/(dblEndX2-dblStartX2);

          double dblYIntercept1=-dblSlope1*dblStartX1+dblStartY1;
          
          double dblYIntercept2=-dblSlope2*dblStartX2+dblStartY2;

          if(dblSlope1==dblSlope2) {
            if(dblYIntercept1==dblYIntercept2) {
              if(dblStartX1<dblStartX2) {
                if(dblEndX1>=dblStartX2)
                  return true;
              }
              else if(dblStartX1==dblStartX2) {
                return true;
              }
              else {
                if(dblStartX1<=dblEndX2)
                  return true;
              }
            }
            else {
              return false;
            }
          }

          dblSlope2=-dblSlope2;

          dblYIntercept2=-dblYIntercept2;

          double dblSlope3=dblSlope1+dblSlope2;

          double dblYIntercept3=dblYIntercept1+dblYIntercept2;

          double dblX3=-dblYIntercept3/dblSlope3;

//          double dblY3=dblSlope1*dblX3+dblYIntercept1;

          if(dblX3>=dblStartX1 & dblX3<=dblEndX1) {
            if(dblX3>=dblStartX2 & dblX3<=dblEndX2)
              return true;            
          }
        }
      }
*/

      return false;
    }

    public static Rectangle[] verticalPath(int intX, int intStartY, int intEndY, int intWidth, int intHeight) {
      if(intEndY<intStartY) {
        int intTemp=intStartY;
        intStartY=intEndY;
        intEndY=intTemp;
      }

      Rectangle rectangleRet[]=new Rectangle[intEndY-intStartY+1];

      for(int i=intStartY;i<=intEndY;i++) {
        rectangleRet[i-intStartY]=new Rectangle(intX-intWidth/2, i-intHeight/2, intWidth, intHeight);
      }

      return rectangleRet;
    }

    public static Rectangle[] slopePath(double dblSlope, double dblIntercept, double dblStartX, double dblEndX, double dblStartY, double dblEndY, int intWidth, int intHeight) {
      Vector vecRectangle=new Vector();

      double dblDistance=Math.sqrt(Math.pow((dblEndX-dblStartX), 2.0d)+Math.pow((dblEndY-dblStartY), 2.0d));

      double dblXIncrement=(dblEndX-dblStartX)/dblDistance;

      for(double dblX=dblStartX;dblX<=dblEndX;dblX+=dblXIncrement) {
        double dblY=dblSlope*dblX+dblIntercept;

        int intX=(int)Math.rint(dblX);
        int intY=(int)Math.rint(dblY);

        vecRectangle.addElement(new Rectangle(intX-intWidth/2, intY-intHeight/2, intWidth, intHeight));
      }

      double dblYLast=dblSlope*dblEndX+dblIntercept;

      int intXLast=(int)Math.rint(dblEndX);
      int intYLast=(int)Math.rint(dblYLast);

      vecRectangle.addElement(new Rectangle(intXLast-intWidth/2, intYLast-intHeight/2, intWidth, intHeight));

      Rectangle rectangleRet[]=new Rectangle[vecRectangle.size()];
      for(int i=0;i<vecRectangle.size();i++)
        rectangleRet[i]=(Rectangle)vecRectangle.elementAt(i);

      return rectangleRet;
    }
}