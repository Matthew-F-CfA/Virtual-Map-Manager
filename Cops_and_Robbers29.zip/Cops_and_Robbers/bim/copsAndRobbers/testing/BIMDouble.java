package bim.copsAndRobbers.testing;

class BIMDouble {
  Double dblDbl=new Double(0.0d);

  BIMDouble(double dblDbl0) {
    this.dblDbl=new Double(dblDbl0);
  }

  public double getDouble() {
    return dblDbl.doubleValue();
  }

  public void setDouble(double dblDbl0) {
    this.dblDbl=new Double(dblDbl0);
  }
}